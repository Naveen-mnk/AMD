import os
import json
from datetime import datetime, date
from pathlib import Path

import pandas as pd
import streamlit as st
from PIL import Image
from dotenv import load_dotenv

load_dotenv()

from src.config import STAFF_CREDENTIALS, CUSTOMER_CREDENTIALS, DIRS
from src.constants import *
from src.pii_masking import mask_customer_dict
from src.data_loader import (
    load_customers, save_customers, load_kyc_documents, save_kyc_documents,
    load_transactions, load_case_history, save_case_history, load_selfie_verification,
    load_compliance_rules, get_case_details, update_case_status
)
from src.orchestrator import run_master_orchestrator
from src.report_generator import generate_evidence_pack_pdf

st.set_page_config(
    page_title="TrustShield AI",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----------------------------- HDFC-STYLE BANKING CSS -----------------------------
st.markdown(
    """
<style>
:root{
  --bank-red:#b5121b;
  --bank-red-dark:#8a0f16;
  --bank-blue:#003b71;
  --bank-blue-2:#07294d;
  --ink:#172033;
  --muted:#667085;
  --line:#e7eaf0;
  --bg:#f5f7fb;
  --card:#ffffff;
  --success:#0f8a4b;
  --warning:#b7791f;
  --danger:#b42318;
}
html, body, [class*="css"]{font-family: Inter, Segoe UI, Roboto, Arial, sans-serif;}
.stApp{background:linear-gradient(180deg,#f6f8fc 0%,#eef2f7 100%); color:var(--ink);}
.block-container{padding-top:1.3rem; padding-bottom:3rem; max-width:1450px;}
section[data-testid="stSidebar"]{background:linear-gradient(180deg,#061f3f 0%,#092b56 55%,#071a33 100%); border-right:4px solid var(--bank-red);}
section[data-testid="stSidebar"] *{color:#eef5ff !important;}
section[data-testid="stSidebar"] .stRadio label{color:#eef5ff !important;}
section[data-testid="stSidebar"] hr{border-color:rgba(255,255,255,.12)}
.main-title{font-size:44px; font-weight:900; letter-spacing:-1px; color:var(--bank-blue); text-align:center; margin:10px 0 4px;}
.main-subtitle{text-align:center; color:#596579; font-size:18px; font-weight:600; margin-bottom:28px;}
.bank-strip{height:7px; background:linear-gradient(90deg,var(--bank-red) 0%, var(--bank-red) 32%, var(--bank-blue) 32%, var(--bank-blue) 100%); border-radius:99px; margin:0 auto 28px; max-width:820px;}
.portal-card{background:var(--card); border:1px solid #dfe5ef; border-radius:22px; padding:28px; box-shadow:0 14px 35px rgba(0,30,70,.08); min-height:210px; position:relative; overflow:hidden;}
.portal-card:before{content:""; position:absolute; top:0; left:0; width:100%; height:8px; background:linear-gradient(90deg,var(--bank-red),var(--bank-blue));}
.portal-card h3{font-size:24px; color:var(--bank-blue); margin-top:6px;}
.portal-card p{color:#657184; line-height:1.55; font-size:15.5px;}
.bank-card{background:var(--card); border:1px solid var(--line); border-radius:18px; padding:20px; box-shadow:0 10px 28px rgba(2,32,71,.07); margin-bottom:16px;}
.bank-card-title{font-size:15px; text-transform:uppercase; letter-spacing:.7px; color:var(--muted); font-weight:800; margin-bottom:6px;}
.metric-card{background:#fff; border:1px solid #e2e8f0; border-radius:17px; padding:17px 18px; box-shadow:0 9px 24px rgba(2,32,71,.07); border-left:5px solid var(--bank-red); min-height:112px;}
.metric-label{font-size:12px; color:#667085; font-weight:800; text-transform:uppercase; letter-spacing:.5px;}
.metric-value{font-size:31px; font-weight:900; color:var(--bank-blue); margin-top:7px;}
.metric-caption{font-size:12px; color:#7d8797; margin-top:3px;}
.status-chip{display:inline-block; padding:6px 11px; border-radius:999px; font-size:12px; font-weight:900; border:1px solid transparent; white-space:nowrap;}
.chip-low,.chip-approved,.chip-passed{background:#e8f7ef; color:#0a6e3d; border-color:#bfe8d0;}
.chip-medium,.chip-warning,.chip-review,.chip-pending{background:#fff6df; color:#8a5a08; border-color:#f6d98b;}
.chip-high,.chip-escalated{background:#fff1e6; color:#a34904; border-color:#ffc999;}
.chip-critical,.chip-rejected,.chip-failed,.chip-blocked{background:#fff0f0; color:#a11218; border-color:#f2b8bd;}
.chip-info,.chip-allowed{background:#e7f1ff; color:#0b4e91; border-color:#bcd8ff;}
.agent-card{background:#fff; border:1px solid #e3e8f2; border-radius:16px; padding:16px 18px; margin:10px 0; box-shadow:0 8px 22px rgba(2,32,71,.06); border-left:6px solid #0b4e91;}
.agent-card.failed{border-left-color:#b5121b}.agent-card.warning{border-left-color:#c27a00}.agent-card.passed{border-left-color:#0f8a4b}.agent-card.blocked{border-left-color:#8a0f16}
.agent-title{font-size:17px; font-weight:900; color:#092b56; margin-bottom:7px;}
.agent-meta{font-size:12px; color:#6c7585; font-weight:700;}
.agent-evidence{font-size:14px; color:#303b4b; margin-top:8px;}
.timeline{border-left:4px solid #d7deea; padding-left:18px; margin-left:6px;}
.timeline-item{background:#fff; border:1px solid #e5eaf3; border-radius:14px; padding:13px 15px; margin:10px 0; box-shadow:0 6px 18px rgba(2,32,71,.05);}
.timeline-step{font-weight:900; color:#003b71;}
.table-wrap{background:#fff; border:1px solid #e4e9f2; border-radius:18px; padding:12px; box-shadow:0 9px 22px rgba(2,32,71,.06); margin-top:8px;}
.doc-card{background:#fff; border:1px solid #e6eaf2; border-radius:16px; padding:12px; box-shadow:0 8px 22px rgba(2,32,71,.06); min-height:270px;}
.doc-card h4{color:#003b71; margin-bottom:5px;}
.stButton>button{background:linear-gradient(135deg,var(--bank-red) 0%,var(--bank-red-dark) 100%); color:white; border:0; border-radius:10px; font-weight:900; padding:.55rem 1rem; box-shadow:0 8px 18px rgba(181,18,27,.22);}
.stButton>button:hover{background:linear-gradient(135deg,var(--bank-blue) 0%,#002d56 100%); color:#fff; border:0; transform:translateY(-1px);}
.stDownloadButton>button{background:linear-gradient(135deg,var(--bank-blue) 0%,#002d56 100%); color:white; border:0; border-radius:10px; font-weight:900;}
div[data-testid="stDataFrame"]{border-radius:14px; overflow:hidden; border:1px solid #e3e8f2;}
.reason-box{background:#f8fbff; border:1px solid #dce8f8; border-left:5px solid var(--bank-blue); border-radius:14px; padding:16px; white-space:pre-wrap; color:#22304a; font-size:14px;}
.workflow-card{background:#fff; border:1px solid #e3e8f2; border-radius:18px; padding:18px; box-shadow:0 10px 26px rgba(2,32,71,.07); border-left:6px solid var(--bank-blue); margin-bottom:14px;}
.workflow-card.reject{border-left-color:var(--bank-red); background:#fff7f7;}
.workflow-card.review{border-left-color:#b7791f; background:#fffaf0;}
.workflow-title{font-size:19px; font-weight:900; color:#092b56;}
.small-muted{color:#6c7585; font-size:13px;}
</style>
""",
    unsafe_allow_html=True,
)

# ----------------------------- SESSION STATE -----------------------------
def ss_default(key, value):
    if key not in st.session_state:
        st.session_state[key] = value

ss_default("portal_view", "Landing")
ss_default("logged_in", False)
ss_default("username", "")
ss_default("user_role", "")
ss_default("customer_id", "")
ss_default("current_case_id", "")
ss_default("orchestrator_result", None)
ss_default("reasoning_mode", "Gemini Assisted" if os.getenv("GOOGLE_API_KEY") else "Rule-based Fallback")
ss_default("last_notification", {})

# ----------------------------- HELPERS -----------------------------
def logout():
    for key in ["logged_in", "username", "user_role", "customer_id", "current_case_id", "orchestrator_result", "last_notification"]:
        st.session_state[key] = {} if key == "last_notification" else "" if key != "logged_in" else False
    st.session_state["portal_view"] = "Landing"
    st.rerun()


def chip(text, kind="info"):
    key = str(text).lower().replace(" ", "-").replace("/", "-")
    if kind == "auto":
        if any(x in key for x in ["critical", "failed", "rejected", "blocked"]): kind = "critical"
        elif any(x in key for x in ["high", "escalated"]): kind = "high"
        elif any(x in key for x in ["medium", "warning", "manual", "pending"]): kind = "medium"
        elif any(x in key for x in ["low", "approved", "passed", "allowed"]): kind = "low"
        else: kind = "info"
    return f'<span class="status-chip chip-{kind}">{text}</span>'


def card(title, value, caption=""):
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{title}</div><div class="metric-value">{value}</div><div class="metric-caption">{caption}</div></div>',
        unsafe_allow_html=True,
    )


def section_card(title, html):
    st.markdown(f'<div class="bank-card"><div class="bank-card-title">{title}</div>{html}</div>', unsafe_allow_html=True)


def masked_case_df(df, limit=200):
    out = df.copy().head(limit)
    if "full_name" in out.columns:
        out["full_name"] = out["full_name"].astype(str).str.split().str[0] + " *****"
    if "email" in out.columns:
        out["email"] = out["email"].astype(str).apply(lambda x: x[:1] + "*****@" + x.split("@")[-1] if "@" in x else "*****")
    if "mobile" in out.columns:
        out["mobile"] = out["mobile"].astype(str).apply(lambda x: "******" + x[-4:])
    return out


def get_customer_by_id(customer_id):
    df = load_customers()
    row = df[df["customer_id"] == customer_id]
    return row.iloc[0].to_dict() if not row.empty else {}


def get_case_options():
    df = load_customers()
    demo_ids = ["CUST00001","CUST00002","CUST02500","CUST02501","CUST02502","CUST04999","CUST04998","CUST05000","CUST05001","CUST05002"]
    demo = df[df["customer_id"].isin(demo_ids)].copy()
    rest = df[~df["customer_id"].isin(demo_ids)].head(80)
    show = pd.concat([demo, rest], ignore_index=True)
    show["label"] = show.apply(lambda r: f"{r['case_id']} | {r['customer_id']} | {r['synthetic_risk_profile']} | {r['case_status']}", axis=1)
    return dict(zip(show["label"], show["case_id"])), show


def image_path(customer_id, file_name):
    return DIRS["uploads"] / customer_id / file_name


def show_img(path, caption=None, height=None):
    if Path(path).exists():
        st.image(Image.open(path), caption=caption, use_container_width=True)
    else:
        st.info(f"Missing synthetic file: {Path(path).name}")


def document_grid(customer_id, docs_df=None):
    docs = [
        ("Customer Photo", "customer_photo.png"), ("Selfie", "selfie.png"), ("PAN", "pan_card.png"),
        ("Aadhaar", "aadhaar_card.png"), ("Bank Statement", "bank_statement.png"),
        ("Salary Slip", "salary_slip.png"), ("Address Proof", "address_proof.png"),
    ]
    cols = st.columns(3)
    for i, (label, fname) in enumerate(docs):
        with cols[i % 3]:
            st.markdown('<div class="doc-card">', unsafe_allow_html=True)
            st.markdown(f"#### {label}")
            show_img(image_path(customer_id, fname))
            if docs_df is not None and label not in ["Customer Photo", "Selfie"]:
                rec = docs_df[docs_df["document_type"] == label]
                if not rec.empty:
                    r = rec.iloc[0]
                    st.markdown(
                        f"{chip(r['document_status'], 'auto')} &nbsp; {chip(r['quality_status'], 'auto')}<br>"
                        f"<span class='small-muted'>Confidence: <b>{float(r['confidence_score'])*100:.0f}%</b> | Tamper: <b>{r['tampering_indicator']}</b></span>",
                        unsafe_allow_html=True,
                    )
            st.markdown('</div>', unsafe_allow_html=True)


def agent_status_kind(status):
    s = str(status).lower()
    if "fail" in s: return "failed"
    if "block" in s: return "blocked"
    if "warn" in s: return "warning"
    return "passed"


def show_agent_cards(findings):
    for idx, f in enumerate(findings, start=1):
        kind = agent_status_kind(f.get("status", ""))
        st.markdown(
            f"""
            <div class="agent-card {kind}">
              <div class="agent-title">{idx:02d}. {f.get('agent_name','Agent')}</div>
              <div>{chip(f.get('status','Completed'), 'auto')} &nbsp; <span class="agent-meta">Confidence: {float(f.get('confidence',0))*100:.0f}% | Risk Impact: +{f.get('risk_impact',0)} | {f.get('timestamp','')}</span></div>
              <div class="agent-evidence"><b>Finding:</b> {f.get('finding','')}</div>
              <div class="agent-evidence"><b>Evidence:</b> {f.get('evidence','')}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def show_timeline(res):
    timeline = [
        ("Case context loaded", f"Secure masked context prepared for {res['case_id']} / {res['customer_id']}"),
        ("Documents validated", "Document Intelligence Agent checked mandatory documents, quality, confidence and tamper indicators"),
        ("Identity verified", "Selfie, liveness and demographic matching completed"),
        ("Compliance policy checked", "Local KYC policy and JSON rules matched through Compliance RAG Agent"),
        ("AML/Sanctions/PEP screened", "Watchlists, adverse media and fraud signals reviewed"),
        ("Risk score calculated", f"Final score: {res['risk_result']['risk_score']}/100 | {res['risk_result']['risk_level']}"),
        ("Guardrails applied", f"Guardrail status: {res['guardrail_result']['status']}"),
        ("Human review required", res['guardrail_result']['required_human_action']),
        ("Audit evidence prepared", "Trace JSON, decision log, notification draft and PDF-ready evidence pack created"),
    ]
    st.markdown('<div class="timeline">', unsafe_allow_html=True)
    for i, (title, detail) in enumerate(timeline, 1):
        st.markdown(f'<div class="timeline-item"><span class="timeline-step">Step {i}: {title}</span><br><span class="small-muted">{detail}</span></div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)


def show_workflow_decision(res):
    wf = res.get("decision_workflow", {}) if res else {}
    if not wf:
        return
    kind = "reject" if wf.get("auto_reject") else "review" if wf.get("manual_review") else ""
    st.markdown(
        f"""
        <div class="workflow-card {kind}">
          <div class="workflow-title">AI Agent Workflow Decision</div>
          <br>
          {chip('Discrepancy Level: ' + str(wf.get('discrepancy_level','')), 'auto')}
          &nbsp; {chip('Action: ' + str(wf.get('system_action','')), 'auto')}
          &nbsp; {chip('Case Status: ' + str(wf.get('final_case_status','')), 'auto')}
          <br><br>
          <b>Decision Reason:</b> {wf.get('decision_reason','')}<br>
          <b>Required Staff Action:</b> {wf.get('staff_required_action','')}<br>
          <b>Customer Message:</b> {wf.get('customer_message','')}
        </div>
        """,
        unsafe_allow_html=True,
    )
    triggers = wf.get("high_discrepancy_triggers") or wf.get("manual_review_triggers") or wf.get("all_discrepancies") or []
    if triggers:
        st.markdown("#### Discrepancies / Incorrect Findings Detected")
        for t in triggers[:10]:
            st.markdown(f"- {t}")
    st.info("Email drafts are generated for both staff and customer. No real email is sent in demo mode.")


def run_agents_for_case(case_id):
    key = os.getenv("GOOGLE_API_KEY")
    st.session_state["reasoning_mode"] = "Gemini Assisted" if key else "Rule-based Fallback"
    res = run_master_orchestrator(case_id, key)
    # Apply the business workflow after customer upload + AI agent review:
    # low/medium discrepancy -> manual review, high discrepancy -> auto reject.
    if res and res.get("success"):
        wf = res.get("decision_workflow", {})
        final_status = wf.get("final_case_status")
        if final_status:
            update_case_status(case_id, final_status, "TrustShield Orchestrator", wf.get("decision_reason", "Agentic KYC decision workflow applied"))
    return res


def get_active_result(case_id=None):
    res = st.session_state.get("orchestrator_result")
    if res and (case_id is None or res.get("case_id") == case_id):
        return res
    return None


def save_notification_file(case_id, draft_type, draft):
    path = DIRS["notifications"] / f"{case_id}_{draft_type}.txt"
    text = f"Subject: {draft.get('subject','')}\n\n{draft.get('body','')}"
    path.write_text(text, encoding="utf-8")
    return path, text

# ----------------------------- LANDING -----------------------------
if st.session_state["portal_view"] == "Landing":
    st.markdown('<div class="main-title">TrustShield AI</div>', unsafe_allow_html=True)
    st.markdown('<div class="main-subtitle">Agentic KYC, AML Risk & Compliance Review Platform</div>', unsafe_allow_html=True)
    st.markdown('<div class="bank-strip"></div>', unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown(
            """
            <div class="portal-card">
              <h3>🏦 Staff / Admin Portal</h3>
              <p>Run agentic KYC review, AML checks, PEP/sanctions screening, guardrails, human review, email drafts and audit evidence packs.</p>
              <p><b>Designed for:</b> Compliance, Fraud, Operations, Audit and Admin users.</p>
            </div>
            """, unsafe_allow_html=True)
        if st.button("Enter Staff / Admin Portal", use_container_width=True):
            st.session_state["portal_view"] = "Staff"; st.rerun()
    with c2:
        st.markdown(
            """
            <div class="portal-card">
              <h3>👤 Customer Portal</h3>
              <p>View KYC status, selfie verification, document checklist, customer notifications and final onboarding status safely.</p>
              <p><b>Privacy-first:</b> no internal risk, fraud, PEP, sanctions or audit details are exposed.</p>
            </div>
            """, unsafe_allow_html=True)
        if st.button("Enter Customer Portal", use_container_width=True):
            st.session_state["portal_view"] = "Customer"; st.rerun()

    st.markdown("<br>", unsafe_allow_html=True)
    section_card("Hackathon Value", "<b>Technical scoring focus:</b> dataset-driven multi-agent pipeline, risk engine, guardrails, human review, notification and evidence PDF — not just UI.")

# ----------------------------- LOGIN -----------------------------
elif not st.session_state["logged_in"]:
    if st.sidebar.button("← Back to Landing"):
        st.session_state["portal_view"] = "Landing"; st.rerun()

    st.markdown(f'<div class="main-title">{st.session_state["portal_view"]} Login</div>', unsafe_allow_html=True)
    st.markdown('<div class="bank-strip"></div>', unsafe_allow_html=True)
    left, right = st.columns([1, 1.2])
    with left:
        section_card("Secure Sign In", "Enter the demo credentials below. Authentication is role-based.")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.session_state["portal_view"] == "Staff":
            if st.button("Login to Staff Portal", use_container_width=True):
                if username in STAFF_CREDENTIALS and STAFF_CREDENTIALS[username]["password"] == password:
                    st.session_state.update({"logged_in": True, "username": username, "user_role": STAFF_CREDENTIALS[username]["role"], "customer_id": ""})
                    st.rerun()
                st.error("Invalid staff credentials")
        else:
            if st.button("Login to Customer Portal", use_container_width=True):
                if username in CUSTOMER_CREDENTIALS and CUSTOMER_CREDENTIALS[username]["password"] == password:
                    st.session_state.update({"logged_in": True, "username": username, "user_role": "Customer", "customer_id": CUSTOMER_CREDENTIALS[username]["customer_id"]})
                    st.rerun()
                st.error("Invalid customer credentials")
    with right:
        if st.session_state["portal_view"] == "Staff":
            st.markdown("""
            <div class="bank-card"><div class="bank-card-title">Demo Staff Credentials</div>
            <b>admin</b> / Trust@123 → Admin<br>
            <b>compliance</b> / Trust@123 → Compliance Reviewer<br>
            <b>fraud</b> / Trust@123 → Fraud Analyst<br>
            <b>auditor</b> / Trust@123 → Auditor<br>
            <b>ops</b> / Trust@123 → Operations User</div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div class="bank-card"><div class="bank-card-title">Demo Customer Credentials</div>
            <b>demo.low1</b> / Trust@123 → CUST00001<br>
            <b>demo.medium1</b> / Trust@123 → CUST02500<br>
            <b>demo.high1</b> / Trust@123 → CUST04999<br>
            <b>demo.critical1</b> / Trust@123 → CUST05000</div>
            """, unsafe_allow_html=True)

# ----------------------------- CUSTOMER PORTAL -----------------------------
elif st.session_state["portal_view"] == "Customer":
    cust_id = st.session_state["customer_id"]
    cust = get_customer_by_id(cust_id)
    if not cust:
        st.error("Customer profile not found"); st.stop()
    masked = mask_customer_dict(cust)
    docs = load_kyc_documents()
    cust_docs = docs[docs["customer_id"] == cust_id]
    selfie_df = load_selfie_verification()
    selfie = selfie_df[selfie_df["customer_id"] == cust_id]

    st.sidebar.markdown("### Customer Portal")
    st.sidebar.markdown(f"**User:** {st.session_state['username']}")
    st.sidebar.markdown(f"**Customer ID:** {cust_id}")
    st.sidebar.markdown(f"**Status:** {cust.get('case_status')}")
    cust_page = st.sidebar.radio("Navigation", [
        "Dashboard", "Profile Summary", "Photo & Selfie", "KYC Status", "Document Checklist", "Document Upload / Simulation", "Additional Document Request", "Notifications", "Final Status"
    ])
    if st.sidebar.button("Logout"):
        logout()

    st.markdown(f"## Customer KYC Portal — {cust_id}")
    st.markdown(f"{chip(cust.get('case_status','Pending'), 'auto')} &nbsp; {chip(cust.get('synthetic_risk_profile',''), 'auto')}", unsafe_allow_html=True)

    if cust_page == "Dashboard":
        a,b,c = st.columns([1.1,1.1,1])
        with a: card("KYC Case", cust["case_id"], "Masked customer view")
        with b: card("Current Status", cust["case_status"], "Customer friendly status")
        with c: card("Documents", f"{len(cust_docs)}/5", "Checklist records")
        col1, col2 = st.columns([1,2])
        with col1:
            show_img(image_path(cust_id,"customer_photo.png"), "Customer photo")
        with col2:
            section_card("Latest Message", "Your KYC application is being handled through secure identity verification. Any additional document request will appear in this portal.")
            st.markdown("#### Document Checklist")
            show = cust_docs[["document_type","document_status","confidence_score","quality_status"]].copy()
            show["confidence_score"] = (show["confidence_score"]*100).round(0).astype(int).astype(str)+"%"
            st.dataframe(show, use_container_width=True, hide_index=True)

    elif cust_page == "Profile Summary":
        st.markdown("### Profile Summary — PII Masked")
        profile = pd.DataFrame({"Field":["Name","DOB","Gender","Email","Mobile","Address","City","State","Nationality","Occupation","Income Range"],
                                "Value":[masked.get("full_name"),masked.get("dob"),masked.get("gender"),masked.get("email"),masked.get("mobile"),masked.get("address"),masked.get("city"),masked.get("state"),masked.get("nationality"),masked.get("occupation"),masked.get("income_range")]})
        st.markdown('<div class="table-wrap">', unsafe_allow_html=True); st.dataframe(profile, use_container_width=True, hide_index=True); st.markdown('</div>', unsafe_allow_html=True)

    elif cust_page == "Photo & Selfie":
        c1,c2 = st.columns(2)
        with c1: show_img(image_path(cust_id,"customer_photo.png"), "Customer synthetic photo")
        with c2: show_img(image_path(cust_id,"selfie.png"), "Onboarding selfie")
        if not selfie.empty:
            s = selfie.iloc[0]
            a,b,c = st.columns(3)
            with a: card("Selfie Quality", s["selfie_quality"], "Visible to customer")
            with b: card("Liveness", s["liveness_check"], "Secure face check")
            with c: card("Match Status", s["face_match_status"], "Customer-safe result")

    elif cust_page == "KYC Status":
        st.markdown("### KYC Timeline")
        phases = ["Document Pending", "Document Uploaded", "Validation In Progress", "Manual Review Required", "Approved"]
        current = cust.get("case_status", "Document Pending")
        for i,p in enumerate(phases,1):
            icon = "✅" if p == current or (current in ["Approved","Closed"] and p != "Manual Review Required") else "🔵" if p == current else "⚪"
            st.markdown(f"<div class='timeline-item'><b>{icon} {p}</b><br><span class='small-muted'>Step {i} in customer onboarding flow</span></div>", unsafe_allow_html=True)

    elif cust_page == "Document Checklist":
        st.markdown("### Mandatory Document Checklist")
        show = cust_docs[["document_type","document_status","confidence_score","quality_status","tampering_indicator"]].copy()
        show["confidence_score"] = (show["confidence_score"]*100).round(0).astype(int).astype(str)+"%"
        st.dataframe(show, use_container_width=True, hide_index=True)

    elif cust_page == "Document Upload / Simulation":
        st.markdown("### Document Upload / Simulation")
        st.info("For demo environment, upload is simulated and updates document validation status.")
        doc_type = st.selectbox("Document Type", ["PAN","Aadhaar","Bank Statement","Salary Slip","Address Proof"])
        st.file_uploader("Choose file", type=["png","jpg","jpeg","pdf"])
        if st.button("Simulate Upload & Re-validate"):
            all_docs = load_kyc_documents(); mask = (all_docs["customer_id"]==cust_id)&(all_docs["document_type"]==doc_type)
            all_docs.loc[mask,["document_status","quality_status","tampering_indicator","confidence_score"]] = ["Passed","Passed","Not Detected",0.95]
            save_kyc_documents(all_docs)
            update_case_status(cust["case_id"], "Document Uploaded", "Customer Portal", f"Simulated upload for {doc_type}")
            st.success(f"{doc_type} upload simulated and validation passed")

    elif cust_page == "Additional Document Request":
        if cust.get("case_status") == "More Documents Required":
            st.warning("Additional document is required. Please upload recent address proof or bank statement.")
        else:
            st.info("No additional document request is active for your case.")

    elif cust_page == "Notifications":
        st.markdown("### Customer Notifications")
        status = cust.get("case_status")
        if status == "Approved": msg = "Your KYC has been approved. Your onboarding is complete."
        elif status == "Rejected": msg = "Your KYC could not be approved. Please contact support for next steps."
        elif status == "More Documents Required": msg = "Additional documents are required to continue KYC processing."
        else: msg = "Your KYC application is currently under review."
        section_card("Latest Notification", msg)

    elif cust_page == "Final Status":
        status = cust.get("case_status")
        if status == "Approved": st.success("✅ Approved — KYC completed")
        elif status == "Rejected": st.error("❌ Rejected — Please contact support")
        elif status == "Closed": st.success("✅ Case closed")
        else: st.info("⏳ Final decision is pending")

# ----------------------------- STAFF PORTAL -----------------------------
elif st.session_state["portal_view"] == "Staff":
    role = st.session_state["user_role"]
    username = st.session_state["username"]
    reasoning_mode = "Gemini Assisted" if os.getenv("GOOGLE_API_KEY") else "Rule-based Fallback"
    st.session_state["reasoning_mode"] = reasoning_mode

    st.sidebar.markdown("### Staff Portal")
    st.sidebar.markdown(f"**User:** {username}")
    st.sidebar.markdown(f"**Role:** {role}")
    st.sidebar.markdown(f"**Reasoning:** {reasoning_mode}")
    st.sidebar.markdown("---")
    pages = ["Executive Dashboard", "Customer Registration", "Document Upload & Checklist", "Customer Photo & Document Preview", "KYC Case Queue", "Multi-Agent Review", "Risk & Guardrail Intelligence", "Human Review Workflow", "Notification & Email Center", "Audit Evidence Pack", "Case Closure"]
    page = st.sidebar.radio("Navigation", pages)
    if st.sidebar.button("Logout"):
        logout()

    allowed = {
        "Admin": pages,
        "Operations User": ["Executive Dashboard","Customer Registration","Document Upload & Checklist","Customer Photo & Document Preview"],
        "Compliance Reviewer": ["Executive Dashboard","Document Upload & Checklist","Customer Photo & Document Preview","KYC Case Queue","Multi-Agent Review","Risk & Guardrail Intelligence","Human Review Workflow","Notification & Email Center","Audit Evidence Pack"],
        "Fraud Analyst": ["Executive Dashboard","KYC Case Queue","Multi-Agent Review","Risk & Guardrail Intelligence","Human Review Workflow","Notification & Email Center"],
        "Auditor": ["Executive Dashboard","Customer Photo & Document Preview","Audit Evidence Pack","Case Closure"],
    }
    if page not in allowed.get(role, []):
        st.error(f"Access denied for role {role}"); st.stop()

    # common case selector helper
    def case_selector(label="Select KYC Case", key="case_select"):
        mapping, _ = get_case_options()
        default_label = next(iter(mapping))
        if st.session_state.get("current_case_id"):
            for lab,cid in mapping.items():
                if cid == st.session_state["current_case_id"]:
                    default_label = lab; break
        labels = list(mapping.keys()); idx = labels.index(default_label) if default_label in labels else 0
        lab = st.selectbox(label, labels, index=idx, key=key)
        st.session_state["current_case_id"] = mapping[lab]
        return mapping[lab]

    if page == "Executive Dashboard":
        st.markdown("## Executive Dashboard")
        df = load_customers()
        risk_score_map = {"Low":15,"Medium":45,"High":70,"Critical":90}
        c = st.columns(5)
        metrics = [
            ("Total Cases", len(df), "All KYC records"),
            ("Pending Review", len(df[df["case_status"].isin(["Manual Review Required","Agent Review In Progress","Validation In Progress"])]), "Compliance workload"),
            ("Approved", len(df[df["case_status"]=="Approved"]), "Completed good cases"),
            ("Escalated", len(df[df["case_status"].str.contains("Escalated", na=False)]), "Fraud/Compliance queue"),
            ("Critical Risk", len(df[df["synthetic_risk_profile"]=="Critical"]), "Needs strong guardrail"),
        ]
        for col, m in zip(c, metrics):
            with col: card(*m)
        c = st.columns(5)
        metrics2 = [
            ("Rejected", len(df[df["case_status"]=="Rejected"]), "Non-compliant"),
            ("Document Pending", len(df[df["case_status"]=="Document Pending"]), "Waiting customer action"),
            ("High Risk", len(df[df["synthetic_risk_profile"]=="High"]), "Enhanced review"),
            ("SLA Breach", len(df[(df["synthetic_risk_profile"].isin(["High","Critical"])) & (~df["case_status"].isin(["Approved","Rejected","Closed"]))]), "Priority queue"),
            ("Avg Risk", int(df["synthetic_risk_profile"].map(risk_score_map).mean()), "Synthetic score proxy"),
        ]
        for col, m in zip(c, metrics2):
            with col: card(*m)

        st.markdown("### Priority Case Queue")
        priority = df[df["synthetic_risk_profile"].isin(["High","Critical"])].head(12)
        display = masked_case_df(priority)[["case_id","customer_id","full_name","synthetic_risk_profile","case_status","assigned_queue","sla_hours"]]
        st.dataframe(display, use_container_width=True, hide_index=True)
        a,b = st.columns(2)
        with a:
            st.markdown("### Risk Distribution")
            st.bar_chart(df["synthetic_risk_profile"].value_counts())
        with b:
            st.markdown("### Case Status Distribution")
            st.bar_chart(df["case_status"].value_counts().head(8))

    elif page == "Customer Registration":
        st.markdown("## Customer Registration")
        st.info("Creates a new synthetic onboarding case and records an audit event.")
        with st.form("reg_form"):
            c1,c2,c3 = st.columns(3)
            with c1:
                full_name = st.text_input("Full Name", "Demo Applicant")
                dob = st.date_input("DOB", value=date(1995,1,1))
                gender = st.selectbox("Gender", ["Female","Male","Other"])
                email = st.text_input("Email", "demo.applicant@example.com")
            with c2:
                mobile = st.text_input("Mobile", "9876543210")
                address = st.text_area("Address", "Demo Street, Demo City")
                city = st.text_input("City", "Chennai")
                state = st.text_input("State", "Tamil Nadu")
            with c3:
                nationality = st.text_input("Nationality", "Indian")
                occupation = st.text_input("Occupation", "Salaried")
                income = st.selectbox("Income Range", ["<5L","5L-10L","10L-25L","25L+"])
                cust_type = st.selectbox("Customer Type", ["Retail","Business","NRI"])
                channel = st.selectbox("Application Channel", ["Branch","Mobile App","Web Portal"])
            submitted = st.form_submit_button("Create KYC Case")
        if submitted:
            df = load_customers()
            next_id = f"CUST{len(df)+1:05d}"; case_id = f"CASE{len(df)+1:05d}"
            new = {"case_id":case_id,"customer_id":next_id,"login_username":"","full_name":full_name,"dob":dob.strftime("%Y-%m-%d"),"gender":gender,"email":email,"mobile":mobile,"address":address,"city":city,"state":state,"country":"India","nationality":nationality,"occupation":occupation,"income_range":income,"customer_type":cust_type,"application_channel":channel,"application_date":datetime.now().strftime("%Y-%m-%d"),"case_status":"Document Pending","assigned_queue":"Compliance Queue","sla_hours":24,"synthetic_risk_profile":"Medium","profile_image_path":""}
            save_customers(pd.concat([df, pd.DataFrame([new])], ignore_index=True))
            update_case_status(case_id, "Document Pending", username, "New customer registered")
            st.success(f"Created {next_id} / {case_id}")

    elif page == "Document Upload & Checklist":
        st.markdown("## Document Upload & Checklist")
        case_id = case_selector(key="doc_case")
        details = get_case_details(case_id); cust = details["customer"]; docs = pd.DataFrame(details["documents"])
        st.markdown(f"**Customer:** {cust['customer_id']} &nbsp; {chip(cust['synthetic_risk_profile'],'auto')} &nbsp; {chip(cust['case_status'],'auto')}", unsafe_allow_html=True)
        show = docs[["document_type","document_status","confidence_score","quality_status","tampering_indicator","document_age_days"]].copy()
        show["confidence_score"] = (show["confidence_score"]*100).round(0).astype(int).astype(str)+"%"
        st.dataframe(show, use_container_width=True, hide_index=True)
        doc_type = st.selectbox("Simulate Upload/Re-validation", ["PAN","Aadhaar","Bank Statement","Salary Slip","Address Proof"])
        if st.button("Reset Selected Document to Passed"):
            all_docs = load_kyc_documents(); mask = (all_docs["case_id"]==case_id)&(all_docs["document_type"]==doc_type)
            all_docs.loc[mask,["document_status","quality_status","tampering_indicator","confidence_score"]] = ["Passed","Passed","Not Detected",0.96]
            save_kyc_documents(all_docs); update_case_status(case_id,"Document Uploaded",username,f"Document {doc_type} simulated as passed")
            st.success(f"{doc_type} updated to Passed")

    elif page == "Customer Photo & Document Preview":
        st.markdown("## Customer Photo & Document Preview")
        case_id = case_selector(key="preview_case")
        details = get_case_details(case_id); cust_id = details["customer"]["customer_id"]; docs = pd.DataFrame(details["documents"])
        section_card("Selected Customer", f"<b>{cust_id}</b> &nbsp; {chip(details['customer']['synthetic_risk_profile'],'auto')} &nbsp; {chip(details['customer']['case_status'],'auto')}")
        document_grid(cust_id, docs)

    elif page == "KYC Case Queue":
        st.markdown("## KYC Case Queue")
        df = load_customers()
        queue = st.selectbox("Queue", ["All Queues"] + sorted(df["assigned_queue"].dropna().unique().tolist()))
        risk = st.selectbox("Risk Filter", ["All","Low","Medium","High","Critical"], index=0)
        work = df.copy()
        if queue != "All Queues": work = work[work["assigned_queue"]==queue]
        if risk != "All": work = work[work["synthetic_risk_profile"]==risk]
        display = masked_case_df(work)[["case_id","customer_id","full_name","synthetic_risk_profile","case_status","assigned_queue","sla_hours"]].head(200)
        st.dataframe(display, use_container_width=True, hide_index=True)
        mapping = {f"{r.case_id} | {r.customer_id} | {r.synthetic_risk_profile} | {r.case_status}": r.case_id for r in work.head(200).itertuples()}
        if mapping:
            selected = st.selectbox("Set active case", list(mapping.keys()))
            if st.button("Set Active Case for Agent Review"):
                st.session_state["current_case_id"] = mapping[selected]
                st.success(f"Active case set to {mapping[selected]}")

    elif page == "Multi-Agent Review":
        st.markdown("## Multi-Agent Review Center")
        case_id = case_selector("Select case for agentic review", "agent_case")
        details = get_case_details(case_id); cust = details["customer"]
        a,b,c,d = st.columns(4)
        with a: card("Case", case_id, cust["customer_id"])
        with b: card("Risk Profile", cust["synthetic_risk_profile"], "Dataset scenario")
        with c: card("Status", cust["case_status"], "Current workflow")
        with d: card("Reasoning Mode", reasoning_mode, "No API key shown in UI")
        c1,c2 = st.columns([1,2])
        with c1: show_img(image_path(cust["customer_id"],"customer_photo.png"), "Customer photo")
        with c2:
            st.markdown("### Agent Execution Timeline")
            pending = get_active_result(case_id)
            if pending: show_timeline(pending)
            else: st.info("Click the button below to run the complete multi-agent pipeline.")
        if st.button("Run Agentic KYC Review", use_container_width=True):
            with st.spinner("Running Document, Identity, Compliance RAG, AML, PEP, Fraud, Risk, Guardrail and Audit agents..."):
                res = run_agents_for_case(case_id)
                st.session_state["orchestrator_result"] = res
            st.success("Agentic KYC Review completed")
            st.rerun()
        res = get_active_result(case_id)
        if res:
            st.markdown("### Agent Decision Summary")
            risk_res = res["risk_result"]; guard = res["guardrail_result"]; wf = res.get("decision_workflow", {})
            x1,x2,x3,x4 = st.columns(4)
            with x1: card("Risk Score", f"{risk_res['risk_score']}/100", risk_res["risk_level"])
            with x2: card("AI Recommendation", risk_res["recommended_decision"], "System recommendation")
            with x3: card("Workflow Action", wf.get("system_action", guard["status"]), wf.get("final_case_status", guard["required_human_action"]))
            with x4: card("Reasoning", "Fallback" if res.get("is_fallback") else "Gemini", "No key entered in UI")
            show_workflow_decision(res)
            st.markdown("#### Top Risk Drivers")
            for d in risk_res.get("risk_drivers", [])[:6]: st.markdown(f"- {d}")
            st.markdown("### Specialist Agent Findings")
            show_agent_cards(res["agent_findings"])
            with st.expander("Show secure masked context JSON"):
                st.json(res["secure_context"])

    elif page == "Risk & Guardrail Intelligence":
        st.markdown("## Risk & Guardrail Intelligence")
        case_id = st.session_state.get("current_case_id") or case_selector(key="risk_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("Run Agentic KYC Review first."); st.stop()
        risk_res = res["risk_result"]; guard = res["guardrail_result"]
        c1,c2 = st.columns([1,1])
        with c1:
            section_card("Risk Scorecard", f"<div style='font-size:54px;font-weight:900;color:#b5121b'>{risk_res['risk_score']} / 100</div>{chip(risk_res['risk_level'],'auto')}<br><br><b>Decision:</b> {risk_res['recommended_decision']}")
            st.markdown("#### Risk Drivers")
            for d in risk_res["risk_drivers"]: st.markdown(f"- {d}")
        with c2:
            section_card("Guardrail Result", f"{chip(guard['status'],'auto')}<br><br><b>Policy:</b> {guard['policy_reference']}<br><br><b>Required Action:</b> {guard['required_human_action']}")
            st.markdown("#### Blocked Triggers")
            for b in guard.get("blocked_reasons", []): st.markdown(f"- {b}")
        st.markdown("### Business Workflow Decision")
        show_workflow_decision(res)
        st.markdown("### Compliance Reasoning")
        st.markdown(f"<div class='reason-box'>{res['gemini_reasoning']}</div>", unsafe_allow_html=True)

    elif page == "Human Review Workflow":
        st.markdown("## Human Review Workflow")
        case_id = st.session_state.get("current_case_id") or case_selector(key="review_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("Run Agentic KYC Review first."); st.stop()
        details = get_case_details(case_id); cust = details["customer"]
        c1,c2,c3 = st.columns(3)
        with c1: card("Customer", cust["customer_id"], cust["synthetic_risk_profile"])
        with c2: card("Risk Score", f"{res['risk_result']['risk_score']}/100", res['risk_result']['risk_level'])
        with c3: card("Guardrail", res['guardrail_result']['status'], res['guardrail_result']['required_human_action'])
        show_workflow_decision(res)
        show_agent_cards(res["agent_findings"][:5])
        st.markdown("### Reviewer Action")
        options = ["Approve", "Reject", "Escalate to Compliance", "Escalate to Fraud Team", "Request More Documents", "Senior Approval Required", "Close Case"]
        wf_action = res.get("decision_workflow", {}).get("system_action", "")
        default_idx = 1 if wf_action == "Auto Reject" else 2 if "Manual Review" in wf_action else 0
        action = st.selectbox("Action", options, index=default_idx)
        comment = st.text_area("Reviewer Comment (Mandatory)")
        override = st.text_area("Override Reason (Mandatory if approving blocked/high/critical case)")
        if st.button("Submit Human Review"):
            if not comment.strip(): st.error("Reviewer comment is mandatory."); st.stop()
            if action == "Approve" and (res['guardrail_result']['status']=="Blocked" or res['risk_result']['risk_level'] in ["High","Critical"]) and not override.strip():
                st.error("Override reason is mandatory for approving blocked/high/critical cases."); st.stop()
            mapping = {"Approve":"Approved","Reject":"Rejected","Escalate to Compliance":"Escalated to Compliance","Escalate to Fraud Team":"Escalated to Fraud Team","Request More Documents":"More Documents Required","Senior Approval Required":"Senior Approval Required","Close Case":"Closed"}
            final_status = mapping[action]
            update_case_status(case_id, final_status, f"{username} ({role})", f"{comment} | Override: {override}")
            pdf = generate_evidence_pack_pdf(res)
            st.success(f"Human review submitted. Case status updated to {final_status}. Evidence pack generated: {pdf}")

    elif page == "Notification & Email Center":
        st.markdown("## Notification & Email Center")
        case_id = st.session_state.get("current_case_id") or case_selector(key="notif_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("Run Agentic KYC Review first."); st.stop()
        drafts = res.get("notification_drafts", {})
        st.info("After AI agent review, drafts are generated for both customer and staff. Demo mode creates downloadable drafts only; no real email is sent.")
        draft_type = st.selectbox("Email Draft Type", list(drafts.keys()))
        draft = drafts[draft_type]
        c1,c2 = st.columns([1,2])
        with c1:
            card("Draft Type", draft_type.replace("_"," ").title(), "No real email sending")
            st.markdown(f"**Evidence reference:** reports/evidence_packs/{case_id}_evidence_pack.pdf")
        with c2:
            st.text_input("Subject", value=draft.get("subject",""), disabled=True)
            st.text_area("Email Body Preview", value=draft.get("body",""), height=260)
            path, text = save_notification_file(case_id, draft_type, draft)
            st.download_button("Download Email Draft as .txt", text, file_name=path.name, mime="text/plain")

    elif page == "Audit Evidence Pack":
        st.markdown("## Audit Evidence Pack")
        case_id = st.session_state.get("current_case_id") or case_selector(key="pdf_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("Run Agentic KYC Review first."); st.stop()
        st.markdown("### Evidence Preview")
        show_workflow_decision(res)
        st.dataframe(pd.DataFrame(res["agent_findings"])[["agent_name","status","finding","evidence","confidence","risk_impact"]], use_container_width=True, hide_index=True)
        if st.button("Generate Audit PDF"):
            path = generate_evidence_pack_pdf(res)
            st.success(f"Generated: {path}")
        pdf_path = DIRS["evidence_packs"] / f"{case_id}_evidence_pack.pdf"
        if pdf_path.exists():
            st.download_button("Download Evidence Pack PDF", pdf_path.read_bytes(), file_name=pdf_path.name, mime="application/pdf")

    elif page == "Case Closure":
        st.markdown("## Case Closure & Audit Logs")
        df = load_customers(); hist = load_case_history()
        closed = df[df["case_status"].isin(["Approved","Rejected","Closed"])]
        card("Closed / Finalized Cases", len(closed), "Approved, rejected or closed")
        st.dataframe(masked_case_df(closed)[["case_id","customer_id","full_name","synthetic_risk_profile","case_status","assigned_queue"]].head(200), use_container_width=True, hide_index=True)
        st.markdown("### Latest Audit Events")
        st.dataframe(hist.sort_values("created_at", ascending=False).head(100), use_container_width=True, hide_index=True)
        audit_path = DIRS["audit_logs"] / "audit_trail.json"
        if audit_path.exists():
            with st.expander("Agent audit trail JSON"):
                try: st.json(json.loads(audit_path.read_text()))
                except Exception: st.info("Audit JSON not available")
