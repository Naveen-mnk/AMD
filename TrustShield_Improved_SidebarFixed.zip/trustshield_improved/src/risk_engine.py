"""
Risk Engine — calculates a weighted 0-100 risk score with detailed breakdown.
Improvements:
  • Velocity-risk transaction scoring (multiple flags, not just binary)
  • Income-to-transaction-volume plausibility check
  • Age-based risk (minor / senior) flag
  • Score capping with early-exit on sanctions hit
  • Returns normalised confidence per driver
"""
from __future__ import annotations
from typing import Any
import logging

logger = logging.getLogger(__name__)


def _safe_float(val: Any, default: float = 0.0) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _safe_int(val: Any, default: int = 0) -> int:
    try:
        return int(val)
    except (TypeError, ValueError):
        return default


def calculate_case_risk(case_details: dict, rules: dict) -> dict:
    """
    Calculates the aggregate risk score (0-100) and risk level for a case.
    Returns a breakdown of risk drivers and a recommended decision.
    """
    weights = rules.get("risk_weights", {})
    score = 0
    drivers: list[str] = []

    # ── 1. SANCTIONS EARLY-EXIT ──────────────────────────────────────
    sanctions = case_details.get("sanctions_watchlist", {}) or {}
    if sanctions.get("sanctions_match", 0):
        impact = weights.get("sanctions_match", 45)
        score += impact
        drivers.append(f"Watchlist Match: India AML / OFAC Sanctions (+{impact}) — CRITICAL")
        # Sanctions is auto-critical; still compute other drivers for audit trail
        # but cap final score at 100 immediately if we hit sanctions
        score = min(score, 100)

    # ── 2. DOCUMENT CHECKS ───────────────────────────────────────────
    docs = case_details.get("documents", [])
    cust = case_details.get("customer", {})
    doc_types_present = [d.get("document_type") for d in docs]
    mandatory_docs = rules.get(
        "mandatory_documents",
        ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof", "Selfie"],
    )

    for m_doc in mandatory_docs:
        if m_doc == "Selfie":
            continue
        if m_doc not in doc_types_present:
            impact = weights.get("missing_document", 15)
            score += impact
            drivers.append(f"Missing mandatory document: {m_doc} (+{impact})")

    for doc in docs:
        dtype = doc.get("document_type", "Document")
        status = doc.get("document_status", "")
        tamper = str(doc.get("tampering_indicator", "")).lower()
        confidence = _safe_float(doc.get("confidence_score", 1.0))
        quality = doc.get("quality_status", "")

        if tamper not in ("not detected", "none", "0", "false", "nan", ""):
            impact = weights.get("tampering_suspected", 30)
            score += impact
            drivers.append(f"Suspected document tampering — {dtype} (+{impact})")

        if status == "Expired":
            impact = weights.get("expired_document", 20)
            score += impact
            drivers.append(f"Expired document: {dtype} (+{impact})")
        elif status in ("Failed", "Rejected", "Invalid"):
            impact = weights.get("invalid_document", 15)
            score += impact
            drivers.append(f"Document validation failed: {dtype} (+{impact})")
        elif confidence < rules.get("min_document_confidence", 0.60):
            impact = weights.get("low_confidence_doc", 10)
            score += impact
            drivers.append(f"Low OCR confidence {confidence*100:.0f}% on {dtype} (+{impact})")
        elif quality in ("Blurred", "Incomplete"):
            impact = weights.get("poor_selfie_quality", 10)
            score += impact
            drivers.append(f"Poor image quality ({quality}) on {dtype} (+{impact})")

        # Name mismatch
        doc_name = str(doc.get("document_name_value", "")).strip().lower()
        prof_name = str(cust.get("full_name", "")).strip().lower()
        if doc_name and prof_name:
            d_tok = set(doc_name.split())
            p_tok = set(prof_name.split())
            if not d_tok.intersection(p_tok):
                impact = weights.get("name_mismatch", 15)
                score += impact
                drivers.append(f"Name mismatch on {dtype} (+{impact})")
            elif d_tok != p_tok:
                score += 5
                drivers.append(f"Partial name discrepancy on {dtype} (+5)")

        # DOB mismatch
        doc_dob = str(doc.get("document_dob_value", "")).strip()
        prof_dob = str(cust.get("dob", "")).strip()
        if doc_dob and prof_dob and doc_dob != prof_dob:
            impact = weights.get("dob_mismatch", 15)
            score += impact
            drivers.append(f"Date-of-birth mismatch on {dtype} (+{impact})")

    # ── 3. AGE PLAUSIBILITY ──────────────────────────────────────────
    try:
        from datetime import date
        dob_str = str(cust.get("dob", ""))
        if dob_str:
            dob = date.fromisoformat(dob_str[:10])
            age = (date.today() - dob).days // 365
            if age < 18:
                score += 20
                drivers.append("Customer appears to be a minor (age < 18) (+20)")
            elif age > 80:
                score += 5
                drivers.append("Senior customer — enhanced due diligence recommended (+5)")
    except Exception:
        pass

    # ── 4. SELFIE / LIVENESS ─────────────────────────────────────────
    selfie = case_details.get("selfie_verification", {}) or {}
    if not selfie or not selfie.get("selfie_available", 0):
        impact = weights.get("missing_document", 15)
        score += impact
        drivers.append(f"Missing customer selfie upload (+{impact})")
    else:
        liveness = selfie.get("liveness_check", "Passed")
        match_score = _safe_float(selfie.get("selfie_match_score", 1.0))
        quality = selfie.get("selfie_quality", "Passed")

        if liveness == "Failed":
            impact = weights.get("liveness_failed", 25)
            score += impact
            drivers.append(f"Selfie liveness check failed — anti-spoofing flag (+{impact})")
        if match_score < 0.50:
            impact = weights.get("selfie_match_failed", 25)
            score += impact
            drivers.append(f"Selfie face-match failed ({match_score*100:.0f}% similarity) (+{impact})")
        elif match_score < 0.75:
            score += 10
            drivers.append(f"Selfie face-match borderline ({match_score*100:.0f}%) — manual review (+10)")
        elif quality == "Poor":
            impact = weights.get("poor_selfie_quality", 10)
            score += impact
            drivers.append(f"Poor selfie image quality (+{impact})")

    # ── 5. FRAUD WATCHLIST ───────────────────────────────────────────
    fraud = case_details.get("fraud_watchlist", {}) or {}
    if fraud:
        if fraud.get("duplicate_pan", 0):
            impact = weights.get("duplicate_pan", 30)
            score += impact
            drivers.append(f"Duplicate PAN — matches existing account (+{impact})")
        if fraud.get("duplicate_mobile", 0):
            impact = weights.get("duplicate_mobile", 15)
            score += impact
            drivers.append(f"Duplicate mobile number — matches existing account (+{impact})")
        if fraud.get("duplicate_bank_account", 0):
            impact = weights.get("duplicate_bank_account", 15)
            score += impact
            drivers.append(f"Duplicate bank account — matches existing record (+{impact})")
        if fraud.get("synthetic_identity_signal", 0):
            impact = weights.get("synthetic_identity", 25)
            score += impact
            drivers.append(f"Synthetic identity pattern detected (+{impact})")
        if fraud.get("repeated_kyc_attempt", 0):
            impact = weights.get("repeated_kyc", 10)
            score += impact
            drivers.append(f"Repeated KYC registration attempts (+{impact})")

    # ── 6. HIGH-RISK GEOGRAPHY ────────────────────────────────────────
    if sanctions.get("high_risk_country", 0):
        impact = weights.get("high_risk_country", 20)
        score += impact
        drivers.append(f"High-risk geography — enhanced due diligence required (+{impact})")

    # ── 7. PEP SCREENING ─────────────────────────────────────────────
    pep = case_details.get("pep_watchlist", {}) or {}
    if pep and pep.get("pep_match", 0):
        impact = weights.get("pep_match", 25)
        score += impact
        drivers.append(f"PEP match — {pep.get('pep_category', 'Category-1')} (+{impact})")

    # ── 8. ADVERSE MEDIA ─────────────────────────────────────────────
    adverse = case_details.get("adverse_media", {}) or {}
    if adverse and adverse.get("adverse_media_match", 0):
        impact = weights.get("adverse_media_match", 20)
        score += impact
        drivers.append(f"Adverse media hit — regulatory / scrutiny concern (+{impact})")

    # ── 9. TRANSACTION RISK ──────────────────────────────────────────
    txns = case_details.get("transactions", []) or []
    suspicious_count = sum(1 for t in txns if t.get("suspicious_txn_flag", 0))
    high_val_count = sum(1 for t in txns if t.get("high_value_flag", 0))
    velocity_count = sum(1 for t in txns if t.get("velocity_risk", 0))

    if suspicious_count > 0:
        impact = weights.get("suspicious_txn", 15)
        score += impact
        drivers.append(f"Suspicious transaction pattern ({suspicious_count} flag(s)) (+{impact})")
    if high_val_count > 0:
        impact = weights.get("high_value_txn", 10)
        score += impact
        drivers.append(f"High-value cash/transfer transactions ({high_val_count}) (+{impact})")
    if velocity_count > 2:
        score += 10
        drivers.append(f"Elevated transaction velocity — {velocity_count} velocity-risk events (+10)")

    # Income plausibility check
    total_txn_amount = sum(_safe_float(t.get("amount", 0)) for t in txns)
    income_map = {"Below 5L": 500_000, "5L-10L": 1_000_000, "10L-25L": 2_500_000, "25L+": 5_000_000,
                  "<5L": 500_000, "5L-10L": 1_000_000, "10L-25L": 2_500_000, "25L-50L": 5_000_000, "50L+": 10_000_000}
    income_ceiling = income_map.get(cust.get("income_range", ""), 0)
    if income_ceiling and total_txn_amount > income_ceiling * 2:
        score += 8
        drivers.append(
            f"Transaction volume (₹{total_txn_amount:,.0f}) exceeds 2× declared income ceiling (+8)"
        )

    # ── 10. FINAL BAND ───────────────────────────────────────────────
    score = min(max(score, 0), 100)

    if score <= rules.get("manual_review_score", 30):
        risk_level = "Low"
        recommended_decision = "Eligible for Approval"
    elif score <= rules.get("escalate_score", 60):
        risk_level = "Medium"
        recommended_decision = "Manual Review Required"
    elif score <= rules.get("reject_score", 80):
        risk_level = "High"
        recommended_decision = "Escalated to Compliance / Fraud Team"
    else:
        risk_level = "Critical"
        recommended_decision = "Reject or Senior Approval Required"

    return {
        "risk_score": int(score),
        "risk_level": risk_level,
        "risk_drivers": drivers if drivers else ["No notable risk drivers detected (Standard Profile)"],
        "recommended_decision": recommended_decision,
    }
