"""
Lightweight in-process cache for expensive data loads.
Reduces redundant CSV reads during a single Streamlit session.
"""
import time
import threading
from typing import Any, Optional

_cache: dict = {}
_lock = threading.Lock()
DEFAULT_TTL = 60  # seconds


def get(key: str) -> Optional[Any]:
    with _lock:
        entry = _cache.get(key)
        if entry and (time.time() - entry["ts"]) < entry["ttl"]:
            return entry["value"]
        _cache.pop(key, None)
    return None


def set(key: str, value: Any, ttl: int = DEFAULT_TTL):
    with _lock:
        _cache[key] = {"value": value, "ts": time.time(), "ttl": ttl}


def invalidate(key: str):
    with _lock:
        _cache.pop(key, None)


def invalidate_prefix(prefix: str):
    with _lock:
        to_del = [k for k in _cache if k.startswith(prefix)]
        for k in to_del:
            del _cache[k]
