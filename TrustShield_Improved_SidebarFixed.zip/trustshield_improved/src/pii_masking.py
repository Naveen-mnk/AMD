"""
PII Masking Utilities — comprehensive masking for all sensitive fields.
Improvements:
  • Consistent masking across all field types
  • Email local-part masking (not just prefix)
  • Address partial masking (keeps city/state visible for AML geography checks)
  • Aadhaar format-compliant masking: XXXX-XXXX-1234
  • PAN format-compliant masking: XXXXX1234X
  • Bank account masking: last 4 visible
  • Mobile masking: last 4 visible
"""
import re
from typing import Optional


def mask_pan(pan: str) -> str:
    """XXXXX1234X  (first 5 + last masked, 5 masked + last digit)"""
    if not pan or len(str(pan).strip()) < 6:
        return "XXXXXXXXXX"
    pan = str(pan).strip().upper()
    return "XXXXX" + pan[5:]  # expose only last 5 chars as per RBI guidance


def mask_aadhaar(aadhaar: str) -> str:
    """XXXX-XXXX-1234"""
    cleaned = re.sub(r"[^0-9]", "", str(aadhaar or ""))
    if len(cleaned) < 4:
        return "XXXX-XXXX-XXXX"
    return f"XXXX-XXXX-{cleaned[-4:]}"


def mask_mobile(mobile: str) -> str:
    """XXXXXX4321"""
    cleaned = re.sub(r"[^0-9+]", "", str(mobile or ""))
    if len(cleaned) < 4:
        return "XXXXXXXXXX"
    return "XXXXXX" + cleaned[-4:]


def mask_bank_account(account: str) -> str:
    """XXXXXXXXXXXX1234"""
    cleaned = re.sub(r"[^0-9A-Za-z]", "", str(account or ""))
    if len(cleaned) < 4:
        return "XXXXXXXXXXXXXXXX"
    return "X" * max(len(cleaned) - 4, 4) + cleaned[-4:]


def mask_email(email: str) -> str:
    """ab****@domain.com"""
    email = str(email or "").strip()
    if "@" not in email:
        return "*****@***"
    local, domain = email.split("@", 1)
    if len(local) <= 2:
        return f"**@{domain}"
    return f"{local[:2]}{'*' * min(len(local)-2, 4)}@{domain}"


def mask_address(address: str) -> str:
    """Masks street/house number, keeps city/state portion visible."""
    if not address:
        return "***"
    parts = str(address).split(",")
    if len(parts) <= 2:
        return "*** (masked)"
    # Keep last 2 parts (usually city, state/PIN)
    masked_parts = ["*** (masked)"] * (len(parts) - 2) + parts[-2:]
    return ", ".join(masked_parts)


def mask_name(full_name: str) -> str:
    """First name + *****"""
    parts = str(full_name or "").split()
    if not parts:
        return "*****"
    return parts[0] + " *****"


def mask_customer_dict(cust: dict) -> dict:
    """Returns a copy of the customer dict with all PII fields masked."""
    masked = cust.copy()
    # Name
    masked["full_name"] = mask_name(cust.get("full_name", ""))
    # Contact
    masked["email"] = mask_email(cust.get("email", ""))
    masked["mobile"] = mask_mobile(cust.get("mobile", ""))
    # Address — keep city/state
    masked["address"] = mask_address(cust.get("address", ""))
    # DOB — mask year and day, keep month for partial display
    dob = str(cust.get("dob", ""))
    if len(dob) >= 7:
        masked["dob"] = f"**-{dob[5:7]}-****"
    # Financial identifiers
    masked["pan"] = mask_pan(cust.get("pan", ""))
    masked["aadhaar"] = mask_aadhaar(cust.get("aadhaar", ""))
    masked["bank_account"] = mask_bank_account(cust.get("bank_account", ""))
    return masked
