"""
Gemini Reasoning Agent — invokes Gemini API for compliance reasoning.
Improvements:
  • Timeout guard (no hanging on slow API)
  • Model fallback chain: gemini-1.5-flash → gemini-1.0-pro
  • Prompt size truncation to avoid context overflow
  • Better structured fallback report (mirrors Gemini output format)
  • Temperature=0 for deterministic compliance outputs
"""
import os
import threading
from typing import Optional

try:
    import google.generativeai as genai
except Exception:
    genai = None

from dotenv import load_dotenv

load_dotenv()

_GEMINI_TIMEOUT_SEC = 25  # max wait time


def _timestamp() -> str:
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def generate_fallback_reasoning(
    case_details: dict,
    agent_findings: list,
    risk_result: dict,
    guardrail_result: dict,
) -> str:
    """
    High-quality deterministic compliance report when Gemini is unavailable.
    Mirrors the structure of the Gemini output so the UI renders identically.
    """
    cust = case_details.get("customer", {})
    case_id = cust.get("case_id", "CASE00000")
    cust_id = cust.get("customer_id", "CUST00000")
    risk_score = risk_result.get("risk_score", 0)
    risk_level = risk_result.get("risk_level", "Low")
    guard_status = guardrail_result.get("status", "Allowed")
    decision = risk_result.get("recommended_decision", "Standard Processing")

    blocked_reasons = guardrail_result.get("blocked_reasons", [])
    warning_reasons = guardrail_result.get("warning_reasons", [])
    drivers = risk_result.get("risk_drivers", [])

    failed_agents = [f for f in agent_findings if f.get("status") in ("Failed", "Warning")]
    passed_agents = [f for f in agent_findings if f.get("status") == "Passed"]

    lines = [
        "=" * 72,
        "TRUSTSHIELD AI — COMPLIANCE INTELLIGENCE REPORT",
        f"Case: {case_id}  |  Customer: {cust_id}  |  Generated: {_timestamp()}",
        f"Engine: Rule-Based Compliance Engine (Gemini API unavailable)",
        "=" * 72,
        "",
        "━━━  1. EXECUTIVE SUMMARY  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        f"Composite Risk Score:  {risk_score}/100  [{risk_level.upper()} RISK]",
        f"Guardrail Status:      {guard_status.upper()}",
        f"System Recommendation: {decision}",
        "",
    ]

    if guard_status == "Blocked":
        lines.append("⛔  POLICY BLOCK — Onboarding CANNOT proceed without Compliance Manager override.")
        for r in blocked_reasons:
            lines.append(f"   ✗ {r}")
    elif guard_status == "Warning":
        lines.append("⚠️  POLICY WARNING — Enhanced Due Diligence required before approval.")
        for w in warning_reasons:
            lines.append(f"   ⚠ {w}")
    else:
        lines.append("✅  No hard policy blocks detected. Standard review workflow applicable.")

    lines += [
        "",
        "━━━  2. RISK DRIVER ANALYSIS  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
    ]
    if drivers:
        for d in drivers:
            lines.append(f"   → {d}")
    else:
        lines.append("   No notable risk drivers identified. Customer meets standard profile.")

    lines += [
        "",
        "━━━  3. SPECIALIST AGENT FINDINGS  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
    ]
    if failed_agents:
        lines.append("Issues requiring attention:")
        for f in failed_agents:
            lines.append(f"   [{f.get('status','?')}] {f.get('agent_name','')}:")
            lines.append(f"        Finding:  {f.get('finding','')}")
            lines.append(f"        Evidence: {f.get('evidence','')}")
    if passed_agents:
        lines.append(f"\n{len(passed_agents)} agent(s) returned PASSED — no issues detected.")

    lines += [
        "",
        "━━━  4. COMPLIANCE RECOMMENDATION  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        guardrail_result.get("required_human_action", "Follow standard KYC approval workflow."),
        "",
        "━━━  5. REGULATORY REFERENCES  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        f"Policy: {guardrail_result.get('policy_reference', 'RBI KYC Master Directions 2016 (Amended 2023)')}",
        "Additional: PMLA 2002, FATF Recommendations, Prevention of Money Laundering Rules 2005",
        "",
        "─" * 72,
        "END OF AUTOMATED COMPLIANCE REPORT — TrustShield AI Audit Engine",
        "─" * 72,
    ]
    return "\n".join(lines)


def run_gemini_reasoning(
    api_key: Optional[str],
    case_context_str: str,
    agent_findings_str: str,
    risk_summary_str: str,
    guardrail_summary_str: str,
) -> str:
    """
    Invokes Gemini API. Returns empty string on any failure so the orchestrator
    falls back gracefully to the rule-based report.
    """
    key = api_key or os.environ.get("GOOGLE_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key or genai is None:
        return ""

    # Truncate context to avoid token overflow (~60k chars max)
    MAX_CONTEXT = 18_000
    if len(case_context_str) > MAX_CONTEXT:
        case_context_str = case_context_str[:MAX_CONTEXT] + "\n... [truncated for token limit]"

    prompt = f"""You are the Gemini Reasoning Agent inside TrustShield AI, an enterprise-grade
KYC compliance platform used by Indian financial institutions.

STRICT RULES:
1. Produce ONLY a structured compliance reasoning report. Do not add disclaimers or
   introductory filler.
2. NEVER reproduce unmasked PII (Aadhaar, PAN, Bank Account, Mobile, Full Email).
3. Do NOT make final approve/reject decisions; only provide recommendations backed
   by evidence and policy references.
4. Be concise, professional, and audit-ready.

--- MASKED CASE CONTEXT ---
{case_context_str}

--- SPECIALIST AGENT FINDINGS ---
{agent_findings_str}

--- RISK SCORING ---
{risk_summary_str}

--- POLICY GUARDRAILS ---
{guardrail_summary_str}

Generate the report with these sections:
1. EXECUTIVE SUMMARY
2. DETAILED EVIDENCE ANALYSIS (documents, identity, watchlists, transactions)
3. RISK DRIVER NARRATIVE
4. REGULATORY COMPLIANCE DETERMINATION (cite RBI / PMLA / FATF rules)
5. RECOMMENDED COMPLIANCE ACTION
"""

    result_holder = {"text": "", "error": None}

    def _call():
        try:
            genai.configure(api_key=key)
            models_to_try = ["gemini-1.5-flash", "gemini-1.0-pro"]
            for model_name in models_to_try:
                try:
                    model = genai.GenerativeModel(model_name)
                    resp = model.generate_content(
                        prompt,
                        generation_config={"temperature": 0, "max_output_tokens": 1500},
                    )
                    if resp and resp.text:
                        result_holder["text"] = resp.text.strip()
                        return
                except Exception:
                    continue
        except Exception as e:
            result_holder["error"] = str(e)

    t = threading.Thread(target=_call, daemon=True)
    t.start()
    t.join(timeout=_GEMINI_TIMEOUT_SEC)

    return result_holder.get("text", "")
