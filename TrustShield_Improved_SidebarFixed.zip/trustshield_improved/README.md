# TrustShield AI – Agentic Compliance Intelligence for KYC, AML Risk & Audit Automation

Enterprise-style Streamlit demo for KYC onboarding, AML/fraud screening, multi-agent review, risk scoring, guardrails, human review, notification drafts and audit evidence packs.

## Key improvements in this reshaped version

- HDFC-style professional banking UI feel using deep navy, red accents, premium cards, badges, styled tables and strong buttons.
- Removed API key entry from UI. Gemini is read only from `GOOGLE_API_KEY` environment variable. If missing, the app silently uses rule-based fallback reasoning.
- Clear Multi-Agent Review Center with step-by-step agent execution timeline and evidence-based agent cards.
- 10 demo customers with synthetic customer photos and document images under `uploads/demo_customer_docs/`.
- Customer portal is privacy-safe and does not expose internal fraud, risk breakdown, sanctions/PEP, guardrails, audit logs or reviewer comments.
- Staff portal includes dashboard, case queue, document preview, agent review, risk/guardrail view, human review, email drafts, evidence PDF and closure logs.

## AMD run command

```bash
cd /workspace/shared/KYC_APP
pip install streamlit --ignore-installed blinker
pip install pandas numpy reportlab pillow pydantic python-dotenv google-generativeai
streamlit run app.py --server.port 8501 --server.headless true --server.enableCORS false --server.enableXsrfProtection false
```

Open using AMD proxy:

```text
https://notebooks.amd.com/<pod-name>/proxy/8501/
```

Do not use localhost.

## Staff demo logins

- `admin` / `Trust@123` → Admin
- `compliance` / `Trust@123` → Compliance Reviewer
- `fraud` / `Trust@123` → Fraud Analyst
- `auditor` / `Trust@123` → Auditor
- `ops` / `Trust@123` → Operations User

## Customer demo logins

- `demo.low1` / `Trust@123` → CUST00001
- `demo.low2` / `Trust@123` → CUST00002
- `demo.medium1` / `Trust@123` → CUST02500
- `demo.medium2` / `Trust@123` → CUST02501
- `demo.medium3` / `Trust@123` → CUST02502
- `demo.high1` / `Trust@123` → CUST04999
- `demo.high2` / `Trust@123` → CUST04998
- `demo.critical1` / `Trust@123` → CUST05000
- `demo.critical2` / `Trust@123` → CUST05001
- `demo.critical3` / `Trust@123` → CUST05002

## Demo flow

1. Open TrustShield AI landing page.
2. Login as `demo.low1` and show the safe customer portal.
3. Logout and login as `compliance`.
4. Open Executive Dashboard.
5. Go to Multi-Agent Review and select CUST05000 / CASE05000.
6. Click **Run Agentic KYC Review**.
7. Show agent execution timeline, agent findings, risk score and guardrail result.
8. Open Human Review Workflow and submit action/comment.
9. Open Notification & Email Center and download email draft.
10. Open Audit Evidence Pack and generate/download PDF.
11. Login as `demo.critical1` and show updated customer-safe status.

## Gemini reasoning

Gemini is optional. The UI does not ask for API key. Set the key in environment only:

```bash
export GOOGLE_API_KEY="your_key_here"
```

Without this, the app uses rule-based fallback reasoning and still works.

## New AI discrepancy workflow

After customer document upload/simulation, staff can open **Multi-Agent Review Center** and click **Run Agentic KYC Review**.

The system now applies this business workflow:

- Clean case → ready for staff approval review.
- Low or medium discrepancy → case is routed to **Manual Review Required**.
- High discrepancy, critical risk, or guardrail block → case is automatically marked **Rejected** for the demo workflow.
- Customer and staff email drafts are generated automatically in **Notification & Email Center**.
- The Evidence PDF includes the AI workflow decision, discrepancy level, triggers, staff action, customer message, agent findings, risk score, and audit evidence.

No real email is sent. The app generates downloadable email drafts for demo safety.


DATASET UPDATE: All customer country/nationality/address data is India-only. Demo names are generic to avoid community/caste/religion indication.


## Demo Flow Update - Simplified Login

### Staff Login
Use only one staff login for the complete staff workflow:

- `staff` / `Trust@123` → KYC Staff

This single staff user can view queues, run AI review, perform human review, generate email drafts, create audit PDFs, and close cases.

### Customer Flow
- Existing customers can login using demo customer credentials to check KYC status.
- Fresh customers can use the Customer Portal registration form to create a new KYC case, upload/simulate documents, and receive an acknowledgement email preview.

