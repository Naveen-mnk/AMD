def validate_guardrails(case_details: dict, risk_result: dict, rules: dict) -> dict:
    """
    Evaluates policy guardrails for a case context and risk findings.
    If a guardrail is violated, it overrides auto-approval and marks the case as Blocked.
    """
    guardrail_config = rules.get("guardrails", {})
    
    status = "Allowed"
    blocked_reasons = []
    required_action = "Standard Review Queue"
    policy_ref = "General Compliance Standard"
    
    # 1. Sanctions watchlist check
    sanctions = case_details.get("sanctions_watchlist", {})
    if guardrail_config.get("block_sanctions", True) and sanctions.get("sanctions_match", 0):
        status = "Blocked"
        blocked_reasons.append("Sanctions watchlist match detected")
        required_action = "Immediate Rejection & Regulatory Reporting"
        policy_ref = "Compliance Policy Section 4: Sanctions and Watchlist Policy"

    # 2. Duplicate PAN check
    fraud = case_details.get("fraud_watchlist", {})
    if guardrail_config.get("block_duplicate_pan", True) and fraud.get("duplicate_pan", 0):
        status = "Blocked"
        blocked_reasons.append("Duplicate PAN card usage detected")
        required_action = "Fraud Team Review for Synthetic Identity"
        policy_ref = "Compliance Policy Section 7: Fraud and Duplication Rules"

    # 3. Missing mandatory documents check
    docs = case_details.get("documents", [])
    doc_types = [d.get("document_type") for d in docs]
    mandatory_docs = rules.get("mandatory_documents", ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof", "Selfie"])
    
    missing_docs = []
    for m_doc in mandatory_docs:
        if m_doc == "Selfie":
            selfie = case_details.get("selfie_verification", {})
            if not selfie or not selfie.get("selfie_available", 0):
                missing_docs.append("Selfie")
        elif m_doc not in doc_types:
            missing_docs.append(m_doc)
            
    if guardrail_config.get("block_missing_mandatory", True) and missing_docs:
        status = "Blocked"
        blocked_reasons.append(f"Missing mandatory documents: {', '.join(missing_docs)}")
        required_action = "Request More Documents from Customer"
        policy_ref = "Compliance Policy Section 1: Mandatory KYC Documents"

    # 4. Failed selfie/liveness check
    selfie = case_details.get("selfie_verification", {})
    liveness_failed = selfie.get("liveness_check") == "Failed"
    match_failed = selfie.get("selfie_match_score", 1.0) < 0.50
    if guardrail_config.get("block_failed_liveness", True) and (liveness_failed or match_failed):
        status = "Blocked"
        reasons = []
        if liveness_failed: reasons.append("Selfie liveness check failed")
        if match_failed: reasons.append("Selfie facial match similarity failed")
        blocked_reasons.append(f"Identity spoofing warning: {', '.join(reasons)}")
        required_action = "Fraud Analyst Verification & Liveness Audit"
        policy_ref = "Compliance Policy Section 8: Selfie Verification and Liveness"

    # 5. Critical risk customer check
    score = risk_result.get("risk_score", 0)
    if guardrail_config.get("block_critical_risk", True) and score > rules.get("reject_score", 80):
        status = "Blocked"
        blocked_reasons.append(f"Aggregate risk score is Critical: {score}/100")
        required_action = "Senior Compliance Officer Sign-off Required"
        policy_ref = "Compliance Policy Section 5: Politically Exposed Persons / EDD"

    # 6. Unmasked PII Exposure Control
    # Ensure there is a policy rule that prevents showing raw numbers
    # We will enforce this programmatically in our UI and report rendering layers.

    return {
        "status": status,
        "blocked_reasons": blocked_reasons if blocked_reasons else ["None"],
        "policy_reference": policy_ref,
        "required_human_action": required_action
    }
