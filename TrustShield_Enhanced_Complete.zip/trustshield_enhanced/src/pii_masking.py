import re

def mask_pan(pan: str) -> str:
    """Masks a PAN card number: ABCDE1234F -> ABCDE****F"""
    if not pan:
        return ""
    pan = str(pan).strip().upper()
    if len(pan) == 10:
        return f"{pan[:5]}****{pan[9]}"
    return f"{pan[:3]}****" if len(pan) > 4 else "****"

def mask_aadhaar(aadhaar: str) -> str:
    """Masks an Aadhaar card number: 1234-5678-9012 -> XXXX-XXXX-9012"""
    if not aadhaar:
        return ""
    # Remove spacing and hyphens to normalize
    aadhaar_clean = re.sub(r'[\s-]', '', str(aadhaar).strip())
    if len(aadhaar_clean) == 12:
        return f"XXXX-XXXX-{aadhaar_clean[-4:]}"
    # If formatting is already hyphenated
    if len(aadhaar) >= 12:
        return f"XXXX-XXXX-{aadhaar[-4:]}"
    return "XXXX-XXXX-XXXX"

def mask_mobile(mobile: str) -> str:
    """Masks a mobile number: 9876543210 -> ******3210"""
    if not mobile:
        return ""
    mobile_str = re.sub(r'\D', '', str(mobile).strip())
    if len(mobile_str) >= 10:
        return f"******{mobile_str[-4:]}"
    if len(mobile_str) > 4:
        return "*" * (len(mobile_str) - 4) + mobile_str[-4:]
    return "******"

def mask_email(email: str) -> str:
    """Masks an email address: name@gmail.com -> n*****@gmail.com"""
    if not email:
        return ""
    email = str(email).strip()
    if "@" in email:
        parts = email.split("@", 1)
        name, domain = parts[0], parts[1]
        if len(name) > 1:
            return f"{name[0]}*****@{domain}"
        return f"*@{domain}"
    return "*****"

def mask_bank_account(account: str) -> str:
    """Masks a bank account number: 1234567890 -> XXXX7890"""
    if not account:
        return ""
    acc_str = re.sub(r'\D', '', str(account).strip())
    if len(acc_str) >= 4:
        return f"XXXX{acc_str[-4:]}"
    return "XXXX"

def mask_address(address: str) -> str:
    """Masks partial address to protect identity."""
    if not address:
        return ""
    addr_str = str(address).strip()
    # Mask all numbers in the address except zipcodes if needed, or simply mask the middle portion of the text
    # Let's replace any digits in street names with *
    masked = re.sub(r'\b\d+\b', '***', addr_str)
    # Also mask the middle words if it is long
    words = masked.split()
    if len(words) > 3:
        # Keep first word and last two words, mask others
        middle = " ".join(["***" for _ in words[1:-2]])
        return f"{words[0]} {middle} {' '.join(words[-2:])}"
    return masked

def mask_customer_dict(cust: dict) -> dict:
    """Returns a copy of the customer dictionary with masked PII."""
    masked = cust.copy()
    if "pan" in masked:
        masked["pan"] = mask_pan(masked["pan"])
    if "aadhaar" in masked:
        masked["aadhaar"] = mask_aadhaar(masked["aadhaar"])
    if "mobile" in masked:
        masked["mobile"] = mask_mobile(masked["mobile"])
    if "email" in masked:
        masked["email"] = mask_email(masked["email"])
    if "bank_account" in masked:
        masked["bank_account"] = mask_bank_account(masked["bank_account"])
    if "address" in masked:
        masked["address"] = mask_address(masked["address"])
    
    # Check general fields from customers.csv
    for k in ["mobile", "email", "address"]:
        if k in masked and masked[k]:
            if k == "mobile":
                masked[k] = mask_mobile(masked[k])
            elif k == "email":
                masked[k] = mask_email(masked[k])
            elif k == "address":
                masked[k] = mask_address(masked[k])
    return masked
