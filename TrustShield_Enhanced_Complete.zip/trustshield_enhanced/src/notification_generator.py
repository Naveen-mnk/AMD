import os
from pathlib import Path
from src.config import DIRS
from src.pii_masking import mask_customer_dict

def generate_all_notification_drafts(case_details: dict, risk_result: dict, guardrail_result: dict, reasoning: str, decision_workflow: dict = None) -> dict:
    """
    Generates a suite of communication and email templates for the case context.
    """
    cust = case_details.get("customer", {})
    masked_cust = mask_customer_dict(cust)
    full_name = masked_cust.get("full_name", "Valued Customer")
    email = masked_cust.get("email", "n*****@example.com")
    case_id = masked_cust.get("case_id", "CASE00000")
    
    risk_level = risk_result.get("risk_level", "Low")
    risk_score = risk_result.get("risk_score", 0)
    guard_status = guardrail_result.get("status", "Allowed")
    decision_workflow = decision_workflow or {}
    system_action = decision_workflow.get("system_action", "Manual Review Required")
    discrepancy_level = decision_workflow.get("discrepancy_level", risk_level)
    customer_message = decision_workflow.get("customer_message", "Your KYC application is currently under review.")
    staff_required_action = decision_workflow.get("staff_required_action", "Review the AI-generated findings and take final action.")
    decision_reason = decision_workflow.get("decision_reason", "Agentic KYC review completed.")
    
    drafts = {}
    
    # 1. Customer Document Request
    drafts["document_request"] = {
        "subject": f"ACTION REQUIRED: Complete Your TrustShield Verification - Case {case_id}",
        "body": f"""Dear {full_name},

Thank you for choosing Metro Credit Bank. We are currently processing your account onboarding request under Case Reference: {case_id}.

To proceed with our regulatory verification checks, we require you to upload updated or missing KYC documents. 
Specifically, please ensure that:
- You have uploaded a clear selfie portrait.
- Your address proof is within the past 90 days.
- All documents are fully legible and unblurred.

Please log in to your Customer Portal to submit these documents.

Sincerely,
TrustShield Compliance Operations Team
Metro Credit Bank
"""
    }

    # 2. Customer KYC Approved
    drafts["kyc_approved"] = {
        "subject": f"Onboarding Successful: Your Verification is Approved - Case {case_id}",
        "body": f"""Dear {full_name},

We are pleased to inform you that your compliance onboarding check under Case Reference: {case_id} has been successfully verified and approved.

Your bank account registration is now complete, and all onboarding holds have been removed. You can now access full digital banking services.

Thank you for your cooperation during this check.

Sincerely,
Onboarding Operations
Metro Credit Bank
"""
    }

    # 3. Customer KYC Rejected
    drafts["kyc_rejected"] = {
        "subject": f"Update Regarding Your Account Onboarding Status - Case {case_id}",
        "body": f"""Dear {full_name},

Thank you for your interest in Metro Credit Bank. 

We regret to inform you that we are unable to approve your account onboarding application (Reference: {case_id}) at this time because it does not meet our minimum compliance verification policy thresholds.

If you believe there has been a demographic indexing error, please contact our relationship center.

Sincerely,
Compliance Review Board
Metro Credit Bank
"""
    }

    # 4. Compliance Escalation
    drafts["compliance_escalation"] = {
        "subject": f"URGENT: Compliance Case Escalation Required - {case_id} ({risk_level} Risk)",
        "body": f"""Dear Compliance Team,

A KYC Onboarding Case requires immediate enhanced due diligence (EDD) review.

CASE SUMMARY:
- Case Reference: {case_id}
- Customer Name: {full_name} (Masked)
- Risk Score: {risk_score}/100 ({risk_level} Risk Category)
- Guardrail Trigger: {guard_status}
- Reasons: {', '.join(guardrail_result.get('blocked_reasons', []))}

AI REASONING EXCERPT:
{reasoning[:600]}...

Please access the Staff Portal compliance review queue to examine the document checks, watchlist findings, and make a final determination.

Sincerely,
TrustShield Orchestrator Bot
"""
    }

    # 5. Fraud Team Escalation
    drafts["fraud_escalation"] = {
        "subject": f"CRITICAL: Fraud Alert & Case Escalation - {case_id} (Score: {risk_score})",
        "body": f"""Dear Fraud Intelligence Team,

The TrustShield risk engine has triggered a high-severity fraud/synthetic identity warning on Case {case_id}.

ALERT DETAILS:
- Case Reference: {case_id}
- Customer Name: {full_name} (Masked)
- Primary Risk Score: {risk_score}/100
- Guardrail Flags: {', '.join(guardrail_result.get('blocked_reasons', []))}
- Required Action: {guardrail_result.get('required_human_action')}

Please conduct a forensic audit of the duplicate identity indexes or liveness logs in the Fraud Analyst queue.

Sincerely,
TrustShield Fraud Monitoring Agent
"""
    }

    # 6. Senior Approval Request
    drafts["senior_approval"] = {
        "subject": f"REQUEST FOR SENIOR SIGN-OFF: High-Risk Case Override - {case_id}",
        "body": f"""Dear Senior Compliance Director,

A request has been initiated to override or approve Onboarding Case {case_id} which was marked as {risk_level} Risk.

CASE DETAILS:
- Case Reference: {case_id}
- Customer: {full_name} (Masked)
- Risk Score: {risk_score}/100
- Block Status: {guard_status}

An executive supervisor override comment is required to allow approval for this case in accordance with Section 5 of the compliance directive.

Sincerely,
Compliance Operations Queue
"""
    }

    # 7. Case Closure
    drafts["case_closure"] = {
        "subject": f"Case Closure Audit Notification: Onboarding Review Complete - {case_id}",
        "body": f"""Dear Operations Desk,

This email confirms that compliance review case {case_id} has been officially Closed.

Audit Status: Completed
Final Decision: Action recorded by Reviewer.
Audit Trail compiled and uploaded to file server.

This record is now archived.

Sincerely,
Compliance Audit & Governance Agent
"""
    }

    # 8. Evidence Pack Share
    drafts["evidence_pack_share"] = {
        "subject": f"KYC Onboarding Compliance Audit Evidence Pack - {case_id}",
        "body": f"""Dear Compliance Auditor,

Please find attached the compliance audit evidence pack for customer onboarding Case {case_id} (Customer ID: {masked_cust.get('customer_id')}).

The PDF evidence pack contains:
- Masked demographic details
- Specialist agent traces
- Compliance rules matches
- Guardrail outcomes
- Reviewer signature log

Archive Hash Reference: {case_id}_evidence.pdf

Sincerely,
Audit Operations
Metro Credit Bank
"""
    }

    # 9. Customer Decision Update - generated after agent review
    drafts["customer_decision_update"] = {
        "subject": f"KYC Verification Update - Case {case_id}",
        "body": f"""Dear {full_name},

This is an update regarding your KYC verification request under Case Reference: {case_id}.

Current Status: {decision_workflow.get('customer_visible_status', 'Under Review')}

{customer_message}

For your security, internal compliance signals and risk checks are not shared in this customer notification.

Sincerely,
TrustShield Onboarding Team
Metro Credit Bank
"""
    }

    # 10. Staff Decision Alert - internal compliance/fraud/ops notification
    triggers = decision_workflow.get("high_discrepancy_triggers") or decision_workflow.get("manual_review_triggers") or decision_workflow.get("all_discrepancies") or ["No critical trigger captured"]
    drafts["staff_decision_alert"] = {
        "subject": f"STAFF ACTION REQUIRED: {system_action} - {case_id} ({discrepancy_level} Discrepancy)",
        "body": f"""Dear Staff Team,

The TrustShield Agentic KYC pipeline has completed review for Case {case_id}.

AI WORKFLOW DECISION:
- System Action: {system_action}
- Discrepancy Level: {discrepancy_level}
- Risk Score: {risk_score}/100 ({risk_level})
- Guardrail Status: {guard_status}

DECISION REASON:
{decision_reason}

TOP TRIGGERS:
- """ + "\n- ".join([str(t) for t in triggers[:8]]) + f"""

REQUIRED STAFF ACTION:
{staff_required_action}

Please open the Staff Portal to view document previews, agent findings, guardrail result, and evidence pack.

Sincerely,
TrustShield Orchestrator Agent
"""
    }

    # Save to disk
    case_notif_dir = DIRS["notifications"] / case_id
    case_notif_dir.mkdir(parents=True, exist_ok=True)
    
    for dtype, email_obj in drafts.items():
        notif_file = case_notif_dir / f"{dtype}.txt"
        try:
            with open(notif_file, "w") as f:
                f.write(f"Subject: {email_obj['subject']}\n\n{email_obj['body']}")
        except Exception:
            pass
            
    return drafts
