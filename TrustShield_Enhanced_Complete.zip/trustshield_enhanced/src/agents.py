from pydantic import BaseModel, Field
from datetime import datetime
from typing import List, Dict, Any, Optional
from src.constants import *
from src.pii_masking import mask_customer_dict, mask_pan, mask_aadhaar, mask_mobile, mask_bank_account

# Pydantic Schemas for Structured Data
class AgentFinding(BaseModel):
    agent_name: str
    status: str  # Passed, Warning, Failed
    finding: str
    evidence: str
    confidence: float
    risk_impact: int
    timestamp: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

class RiskResult(BaseModel):
    risk_score: int
    risk_level: str
    risk_drivers: List[str]
    recommended_decision: str

class GuardrailResult(BaseModel):
    status: str  # Allowed, Blocked
    blocked_reasons: List[str]
    policy_reference: str
    required_human_action: str

class HumanReviewAction(BaseModel):
    action: str  # Approve, Reject, Escalate, etc.
    comments: str
    override_reason: Optional[str] = None
    reviewer_name: str
    reviewer_role: str
    timestamp: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

class AuditEvent(BaseModel):
    timestamp: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    event_type: str
    actor: str
    case_id: str
    details: str
    ip_address: str = "192.168.1.1"

# Specialist Agent Logic Functions

def run_document_intelligence_agent(case_details: dict, rules: dict) -> AgentFinding:
    docs = case_details.get("documents", [])
    doc_types = [d.get("document_type") for d in docs]
    mandatory = rules.get("mandatory_documents", ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"])
    
    missing = [m for m in mandatory if m != "Selfie" and m not in doc_types]
    
    tamper_flag = False
    expired_flag = False
    blurred_flag = False
    
    for doc in docs:
        if doc.get("tampering_indicator") == "Detected":
            tamper_flag = True
        if doc.get("document_status") == "Expired":
            expired_flag = True
        if doc.get("quality_status") == "Blurred":
            blurred_flag = True
            
    # Calculate status & weight
    if tamper_flag:
        status = "Failed"
        finding = "Tampering / Forgery Indicators Detected"
        evidence = "A document failed the tamper-detection quality checks."
        impact = 30
    elif missing:
        status = "Failed"
        finding = f"Missing Mandatory Documents: {', '.join(missing)}"
        evidence = f"Onboarding checklist incomplete. Required files: {', '.join(mandatory)}"
        impact = len(missing) * 15
    elif expired_flag:
        status = "Failed"
        finding = "Expired Address Proof or Bank Statement"
        evidence = "A document age exceeded the maximum allowed utility recency threshold (90 days)."
        impact = 20
    elif blurred_flag:
        status = "Warning"
        finding = "Low Resolution Document Uploaded"
        evidence = "The bank statement or salary slip image is blurry, reducing OCR confidence."
        impact = 10
    else:
        status = "Passed"
        finding = "All mandatory documents present and verified"
        evidence = f"Successfully validated {len(docs)} documents."
        impact = 0
        
    return AgentFinding(
        agent_name=AGENT_DOC_INTEL,
        status=status,
        finding=finding,
        evidence=evidence,
        confidence=0.95,
        risk_impact=impact
    )

def run_identity_verification_agent(case_details: dict, rules: dict) -> AgentFinding:
    selfie = case_details.get("selfie_verification", {})
    cust = case_details.get("customer", {})
    docs = case_details.get("documents", [])
    
    if not selfie or not selfie.get("selfie_available", 0):
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding="Selfie Photo Missing",
            evidence="Onboarding selfie image was not uploaded.",
            confidence=1.0,
            risk_impact=15
        )
        
    match_score = selfie.get("selfie_match_score", 1.0)
    liveness = selfie.get("liveness_check", "Passed")
    
    # Check if there is any name or DOB mismatch in documents
    mismatch_findings = []
    for doc in docs:
        dtype = doc.get("document_type")
        doc_name = doc.get("document_name_value", "")
        prof_name = cust.get("full_name", "")
        doc_dob = doc.get("document_dob_value", "")
        prof_dob = cust.get("dob", "")
        
        if doc_name and prof_name and doc_name != prof_name:
            mismatch_findings.append(f"Name mismatch on {dtype}: '{doc_name}' vs profile '{prof_name}'")
        if doc_dob and prof_dob and doc_dob != prof_dob:
            mismatch_findings.append(f"DOB mismatch on {dtype}: '{doc_dob}' vs profile '{prof_dob}'")
            
    if liveness == "Failed":
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding="Identity spoofing / Liveness Check Failed",
            evidence="The selfie did not pass live-capture face verification requirements.",
            confidence=0.98,
            risk_impact=25
        )
    elif match_score < 0.50:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Failed",
            finding=f"Facial Match Failed: Similarity {match_score*100:.0f}%",
            evidence="The facial comparison between onboarding selfie and Aadhaar/PAN photo failed to meet the matching threshold.",
            confidence=0.93,
            risk_impact=25
        )
    elif mismatch_findings:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Warning",
            finding="Demographic Profile Discrepancies Found",
            evidence="; ".join(mismatch_findings),
            confidence=0.90,
            risk_impact=15
        )
    else:
        return AgentFinding(
            agent_name=AGENT_IDENTITY_VER,
            status="Passed",
            finding="Facial verification and demographics aligned",
            evidence=f"Match score: {match_score*100:.0f}%. Liveness: Passed.",
            confidence=0.96,
            risk_impact=0
        )

def run_compliance_rag_agent(case_details: dict, rules: dict) -> AgentFinding:
    cust = case_details.get("customer", {})
    dob = cust.get("dob", "")
    min_age = rules.get("minimum_age", 18)
    
    # Calculate age
    try:
        birth = datetime.strptime(dob, "%Y-%m-%d")
        age = (datetime.now() - birth).days // 365
    except Exception:
        age = min_age
        
    if age < min_age:
        return AgentFinding(
            agent_name=AGENT_COMPLIANCE_RAG,
            status="Failed",
            finding="Minimum Age Violation",
            evidence=f"Customer is {age} years old (Policy Rule: minimum age is {min_age}).",
            confidence=1.0,
            risk_impact=30
        )
        
    # Check if address proof is expired
    expired_addr = False
    for doc in case_details.get("documents", []):
        if doc.get("document_type") == "Address Proof" and doc.get("document_status") == "Expired":
            expired_addr = True
            
    if expired_addr:
        return AgentFinding(
            agent_name=AGENT_COMPLIANCE_RAG,
            status="Failed",
            finding="Address Proof Age Violation",
            evidence=f"Proof of address is older than the policy threshold of {rules.get('address_proof_max_age_days', 90)} days.",
            confidence=0.99,
            risk_impact=20
        )
        
    # Standard compliance checked
    return AgentFinding(
        agent_name=AGENT_COMPLIANCE_RAG,
        status="Passed",
        finding="Basic policy criteria aligned",
        evidence=f"Customer meets age ({age}) and document recency requirements.",
        confidence=0.95,
        risk_impact=0
    )

def run_aml_sanctions_agent(case_details: dict, rules: dict) -> AgentFinding:
    sanctions = case_details.get("sanctions_watchlist", {})
    match = sanctions.get("sanctions_match", 0)
    high_risk_country = sanctions.get("high_risk_country", 0)
    remarks = sanctions.get("remarks", "Clear")
    
    if match:
        return AgentFinding(
            agent_name=AGENT_AML_SANCTIONS,
            status="Failed",
            finding="Sanctions List Match Detected",
            evidence=remarks,
            confidence=0.99,
            risk_impact=45
        )
    elif high_risk_country:
        return AgentFinding(
            agent_name=AGENT_AML_SANCTIONS,
            status="Warning",
            finding="High-Risk Country Connection",
            evidence=remarks,
            confidence=0.90,
            risk_impact=20
        )
    else:
        return AgentFinding(
            agent_name=AGENT_AML_SANCTIONS,
            status="Passed",
            finding="Clear of Sanctions List Matches",
            evidence="No records matching name or nationality found on UN/OFAC watchlist registries.",
            confidence=0.95,
            risk_impact=0
        )

def run_pep_screening_agent(case_details: dict, rules: dict) -> AgentFinding:
    pep = case_details.get("pep_watchlist", {})
    match = pep.get("pep_match", 0)
    category = pep.get("pep_category", "None")
    remarks = pep.get("remarks", "Clear")
    
    if match:
        return AgentFinding(
            agent_name=AGENT_PEP_SCREENING,
            status="Warning",
            finding=f"Politically Exposed Person (PEP) Flag: {category}",
            evidence=remarks,
            confidence=0.97,
            risk_impact=25
        )
    else:
        return AgentFinding(
            agent_name=AGENT_PEP_SCREENING,
            status="Passed",
            finding="No PEP Status matches",
            evidence="Customer is not listed as a public official or politically exposed associate.",
            confidence=0.95,
            risk_impact=0
        )

def run_adverse_media_agent(case_details: dict, rules: dict) -> AgentFinding:
    adverse = case_details.get("adverse_media", {})
    match = adverse.get("adverse_media_match", 0)
    remarks = adverse.get("remarks", "Clear")
    
    if match:
        return AgentFinding(
            agent_name=AGENT_ADVERSE_MEDIA,
            status="Warning",
            finding="Negative Media Scrutiny Hit",
            evidence=remarks,
            confidence=0.88,
            risk_impact=20
        )
    else:
        return AgentFinding(
            agent_name=AGENT_ADVERSE_MEDIA,
            status="Passed",
            finding="No Negative Media Scrutiny",
            evidence="No negative public news or regulatory litigation reports found matching the customer name.",
            confidence=0.92,
            risk_impact=0
        )

def run_financial_profiling_agent(case_details: dict, rules: dict) -> AgentFinding:
    cust = case_details.get("customer", {})
    income = cust.get("income_range", "< 5 LPA")
    occupation = cust.get("occupation", "Unemployed")
    
    # Financial profiling check
    status = "Passed"
    finding = "Financial profile consistent with occupation"
    evidence = f"Occupation: {occupation} | Income Band: {income}."
    
    if occupation in ["Retired", "Student"] and income in ["25 - 50 LPA", "50 LPA+"]:
        status = "Warning"
        finding = "Income Discrepancy for Occupation Profile"
        evidence = f"Unexpected high income band ({income}) for occupation status '{occupation}'."
        
    return AgentFinding(
        agent_name=AGENT_FINANCIAL_PROFILE,
        status=status,
        finding=finding,
        evidence=evidence,
        confidence=0.85,
        risk_impact=10 if status == "Warning" else 0
    )

def run_fraud_intelligence_agent(case_details: dict, rules: dict) -> AgentFinding:
    fraud = case_details.get("fraud_watchlist", {})
    if not fraud:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Passed",
            finding="Clear of fraud watchlists",
            evidence="No matching duplicate mobile, PAN, or synthetic identity patterns.",
            confidence=0.95,
            risk_impact=0
        )
        
    dup_pan = fraud.get("duplicate_pan", 0)
    dup_mob = fraud.get("duplicate_mobile", 0)
    dup_bank = fraud.get("duplicate_bank_account", 0)
    synth = fraud.get("synthetic_identity_signal", 0)
    pattern = fraud.get("fraud_pattern", "None")
    
    if dup_pan:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Failed",
            finding="Duplicate PAN Flag",
            evidence=f"Matches PAN registered on another active customer profile. Signature: {pattern}",
            confidence=0.99,
            risk_impact=30
        )
    elif synth:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Failed",
            finding="Synthetic Identity Risk Detected",
            evidence=f"Demographics align with known shell-corporate identity markers. Signature: {pattern}",
            confidence=0.92,
            risk_impact=25
        )
    elif dup_mob or dup_bank:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Warning",
            finding="Shared Contact/Bank Details Flag",
            evidence=f"Mobile number or bank account matched in shared-network registries. Signature: {pattern}",
            confidence=0.88,
            risk_impact=15
        )
    else:
        return AgentFinding(
            agent_name=AGENT_FRAUD_INTEL,
            status="Passed",
            finding="Clear of fraud watchlists",
            evidence="No matching duplicate mobile, PAN, or synthetic identity patterns.",
            confidence=0.95,
            risk_impact=0
        )

def run_transaction_risk_agent(case_details: dict, rules: dict) -> AgentFinding:
    txns = case_details.get("transactions", [])
    suspicious = sum(1 for t in txns if t.get("suspicious_txn_flag", 0))
    high_val = sum(1 for t in txns if t.get("high_value_flag", 0))
    velocity = sum(1 for t in txns if t.get("velocity_risk", 0))
    
    if suspicious > 0:
        return AgentFinding(
            agent_name=AGENT_TX_RISK,
            status="Failed",
            finding="Suspicious Transaction Pattern Flagged",
            evidence=f"Detected {suspicious} transactions flagged for suspicious velocity or structural laundering markers.",
            confidence=0.91,
            risk_impact=15
        )
    elif high_val > 0 or velocity > 0:
        return AgentFinding(
            agent_name=AGENT_TX_RISK,
            status="Warning",
            finding="High transaction velocity or large volumes",
            evidence=f"Detected {high_val} high-value transactions and {velocity} velocity alerts during audit period.",
            confidence=0.88,
            risk_impact=10
        )
    else:
        return AgentFinding(
            agent_name=AGENT_TX_RISK,
            status="Passed",
            finding="Transaction velocity and amounts clear",
            evidence=f"Analyzed {len(txns)} transactions. All limits are within standard retail thresholds.",
            confidence=0.94,
            risk_impact=0
        )

def run_risk_intelligence_agent(case_details: dict, risk_result: dict) -> AgentFinding:
    score = risk_result.get("risk_score", 0)
    level = risk_result.get("risk_level", "Low")
    drivers = ", ".join(risk_result.get("risk_drivers", []))
    
    status = "Passed" if level == "Low" else "Warning" if level == "Medium" else "Failed"
    
    return AgentFinding(
        agent_name=AGENT_RISK_INTEL,
        status=status,
        finding=f"Total Score: {score}/100 | Category: {level} Risk",
        evidence=f"Drivers: {drivers}",
        confidence=0.98,
        risk_impact=0
    )

def run_guardrail_agent(case_details: dict, guardrail_result: dict) -> AgentFinding:
    status = guardrail_result.get("status", "Allowed")
    reasons = ", ".join(guardrail_result.get("blocked_reasons", []))
    action = guardrail_result.get("required_human_action", "")
    
    agent_status = "Passed" if status == "Allowed" else "Failed"
    finding = "Guardrail Compliance Approved" if status == "Allowed" else f"Guardrail Compliance Blocked: {reasons}"
    
    return AgentFinding(
        agent_name=AGENT_GUARDRAIL,
        status=agent_status,
        finding=finding,
        evidence=f"Required action: {action}. Rule ref: {guardrail_result.get('policy_reference')}",
        confidence=1.0,
        risk_impact=0
    )

def run_gemini_reasoning_agent(case_details: dict, gemini_output: str) -> AgentFinding:
    is_fallback = "FALLBACK" in gemini_output
    status = "Passed"
    
    return AgentFinding(
        agent_name=AGENT_GEMINI,
        status=status,
        finding="Natural Language Reasoning Compiled",
        evidence=f"Output Mode: {'Deterministic Fallback' if is_fallback else 'AI Model Reasoning'}",
        confidence=0.90,
        risk_impact=0
    )

def run_decision_reasoning_agent(case_details: dict, decision_desc: str) -> AgentFinding:
    return AgentFinding(
        agent_name=AGENT_DECISION,
        status="Passed",
        finding="Final compliance recommendation finalized",
        evidence=decision_desc,
        confidence=0.95,
        risk_impact=0
    )

def run_notification_agent(case_details: dict, drafts: dict) -> AgentFinding:
    return AgentFinding(
        agent_name=AGENT_NOTIFICATION,
        status="Passed",
        finding="Communication drafts compiled",
        evidence=f"Generated {len(drafts)} email/notice drafts for user review.",
        confidence=0.90,
        risk_impact=0
    )

def run_human_review_agent(case_details: dict, human_action: dict) -> AgentFinding:
    action = human_action.get("action", "None")
    reviewer = human_action.get("reviewer_name", "System")
    role = human_action.get("reviewer_role", "Orchestrator")
    comments = human_action.get("comments", "Pending Review")
    
    return AgentFinding(
        agent_name=AGENT_HUMAN_REVIEW,
        status="Passed" if action != "Reject" else "Failed",
        finding=f"Review Action: {action} by {reviewer} ({role})",
        evidence=f"Reviewer comments: '{comments}'",
        confidence=1.0,
        risk_impact=0
    )

def run_audit_agent(case_details: dict, audit_trail_summary: str) -> AgentFinding:
    return AgentFinding(
        agent_name=AGENT_AUDIT,
        status="Passed",
        finding="Case history audit event appended",
        evidence=audit_trail_summary,
        confidence=1.0,
        risk_impact=0
    )
