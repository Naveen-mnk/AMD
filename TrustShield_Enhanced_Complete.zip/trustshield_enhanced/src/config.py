import os
from pathlib import Path

# Project root resolution
SRC_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SRC_DIR.parent

# Folder configuration
DIRS = {
    "data": PROJECT_ROOT / "data",
    "uploads": PROJECT_ROOT / "uploads" / "demo_customer_docs",
    "agent_traces": PROJECT_ROOT / "outputs" / "agent_traces",
    "decision_logs": PROJECT_ROOT / "outputs" / "decision_logs",
    "notifications": PROJECT_ROOT / "outputs" / "notifications",
    "audit_logs": PROJECT_ROOT / "outputs" / "audit_logs",
    "audit_reports": PROJECT_ROOT / "reports" / "audit_reports",
    "evidence_packs": PROJECT_ROOT / "reports" / "evidence_packs",
    "assets_images": PROJECT_ROOT / "assets" / "images",
    "assets_styles": PROJECT_ROOT / "assets" / "styles",
}

def ensure_directories():
    """Ensure all required folders exist."""
    for name, path in DIRS.items():
        path.mkdir(parents=True, exist_ok=True)

# Call on import to prepare folder structure
ensure_directories()

# Staff users and credentials
STAFF_CREDENTIALS = {
    "admin": {"password": "Trust@123", "role": "Admin", "name": "System Administrator"},
    "compliance": {"password": "Trust@123", "role": "Compliance Reviewer", "name": "Sarah Jenkins (Compliance)"},
    "fraud": {"password": "Trust@123", "role": "Fraud Analyst", "name": "Marcus Vance (Fraud)"},
    "auditor": {"password": "Trust@123", "role": "Auditor", "name": "Audit Inspector"},
    "ops": {"password": "Trust@123", "role": "Operations User", "name": "Operations Clerk"},
}

# Customer portal logins mapping username -> customer_id
CUSTOMER_CREDENTIALS = {
    "demo.low1": {"password": "Trust@123", "customer_id": "CUST00001", "risk": "Low"},
    "demo.low2": {"password": "Trust@123", "customer_id": "CUST00002", "risk": "Low"},
    "demo.medium1": {"password": "Trust@123", "customer_id": "CUST02500", "risk": "Medium"},
    "demo.medium2": {"password": "Trust@123", "customer_id": "CUST02501", "risk": "Medium"},
    "demo.medium3": {"password": "Trust@123", "customer_id": "CUST02502", "risk": "Medium"},
    "demo.high1": {"password": "Trust@123", "customer_id": "CUST04999", "risk": "High"},
    "demo.high2": {"password": "Trust@123", "customer_id": "CUST04998", "risk": "High"},
    "demo.critical1": {"password": "Trust@123", "customer_id": "CUST05000", "risk": "Critical"},
    "demo.critical2": {"password": "Trust@123", "customer_id": "CUST05001", "risk": "Critical"},
    "demo.critical3": {"password": "Trust@123", "customer_id": "CUST05002", "risk": "Critical"},
}

# File names inside DIRS["data"]
FILES = {
    "customers": DIRS["data"] / "customers.csv",
    "kyc_documents": DIRS["data"] / "kyc_documents.csv",
    "transactions": DIRS["data"] / "transactions.csv",
    "fraud_watchlist": DIRS["data"] / "fraud_watchlist.csv",
    "sanctions_watchlist": DIRS["data"] / "sanctions_watchlist.csv",
    "pep_watchlist": DIRS["data"] / "pep_watchlist.csv",
    "adverse_media": DIRS["data"] / "adverse_media.csv",
    "case_history": DIRS["data"] / "case_history.csv",
    "selfie_verification": DIRS["data"] / "selfie_verification.csv",
    "document_file_registry": DIRS["data"] / "document_file_registry.csv",
    "compliance_rules": DIRS["data"] / "compliance_rules.json",
    "kyc_policy_knowledge": DIRS["data"] / "kyc_policy_knowledge.txt",
}
