import os
import json
from datetime import datetime
from src.config import FILES, DIRS
from src.constants import *
from src.pii_masking import mask_customer_dict, mask_pan, mask_aadhaar, mask_mobile, mask_bank_account, mask_address
from src.data_loader import get_case_details, load_compliance_rules, load_kyc_policy
from src.document_checks import run_simulated_ocr_checks
from src.risk_engine import calculate_case_risk
from src.guardrails import validate_guardrails
from src.gemini_reasoning import run_gemini_reasoning, generate_fallback_reasoning
from src.notification_generator import generate_all_notification_drafts
from src.agents import *


def build_discrepancy_decision(case_details: dict, ocr_results: list, risk_res: dict, guardrail_res: dict) -> dict:
    """
    Converts raw AI-agent/risk outputs into a business workflow decision.

    Business rule for the demo:
    - Any HIGH discrepancy or hard compliance block -> auto reject and generate staff + customer notifications.
    - LOW/MEDIUM discrepancy -> manual review queue.
    - Clean case -> staff approval review, not direct customer-visible auto approval.
    """
    discrepancies = []
    high_triggers = []
    manual_review_triggers = []

    # Document/OCR discrepancies
    for r in ocr_results or []:
        doc_type = r.get("document_type", "Document")
        status = str(r.get("overall_status", r.get("status", "")))
        issues = r.get("issues", []) or r.get("findings", []) or []
        if isinstance(issues, str):
            issues = [issues]
        for issue in issues:
            discrepancies.append(f"{doc_type}: {issue}")
            text = str(issue).lower()
            if any(k in text for k in ["tamper", "mismatch", "expired", "failed", "sanction", "duplicate", "liveness"]):
                manual_review_triggers.append(f"{doc_type}: {issue}")
        if "fail" in status.lower():
            manual_review_triggers.append(f"{doc_type}: validation failed")

    # Document hard failures
    for d in case_details.get("documents", []):
        doc_type = d.get("document_type", "Document")
        if str(d.get("tampering_indicator", "")).lower() not in ["not detected", "none", "0", "false", "nan"]:
            high_triggers.append(f"{doc_type}: tampering suspected")
        if str(d.get("document_status", "")).lower() in ["failed", "rejected", "invalid"]:
            manual_review_triggers.append(f"{doc_type}: document status {d.get('document_status')}")
        try:
            if float(d.get("confidence_score", 1)) < 0.75:
                manual_review_triggers.append(f"{doc_type}: low OCR confidence")
        except Exception:
            pass

    # Identity hard failures
    selfie = case_details.get("selfie_verification", {}) or {}
    if selfie.get("liveness_check") == "Failed":
        high_triggers.append("Selfie liveness check failed")
    try:
        if float(selfie.get("selfie_match_score", 1)) < 0.50:
            high_triggers.append("Selfie face match score below threshold")
        elif float(selfie.get("selfie_match_score", 1)) < 0.75:
            manual_review_triggers.append("Selfie match score requires manual review")
    except Exception:
        pass

    # Watchlist/fraud hard failures
    fraud = case_details.get("fraud_watchlist", {}) or {}
    sanctions = case_details.get("sanctions_watchlist", {}) or {}
    pep = case_details.get("pep_watchlist", {}) or {}
    adverse = case_details.get("adverse_media", {}) or {}
    if fraud.get("duplicate_pan", 0):
        high_triggers.append("Duplicate PAN detected")
    if fraud.get("synthetic_identity_signal", 0):
        high_triggers.append("Synthetic identity signal detected")
    if sanctions.get("sanctions_match", 0):
        high_triggers.append("Sanctions watchlist match detected")
    if pep.get("pep_match", 0):
        manual_review_triggers.append("PEP match requires enhanced due diligence")
    if adverse.get("adverse_media_match", 0):
        manual_review_triggers.append("Adverse media match requires review")

    # Risk and guardrail final decision
    risk_level = risk_res.get("risk_level", "Low")
    score = int(risk_res.get("risk_score", 0))
    blocked = guardrail_res.get("status") == "Blocked"

    if risk_level in ["High", "Critical"] or blocked or high_triggers:
        severity = "High"
        system_action = "Auto Reject"
        final_case_status = "Rejected"
        customer_visible_status = "Rejected"
        staff_action = "Staff must review the evidence pack and confirm closure. Customer and staff rejection notifications are generated."
        customer_message = "Your KYC verification could not be approved because the submitted details did not meet our verification policy. Please contact support for next steps."
        decision_reason = "High discrepancy or policy guardrail detected. Auto-rejection workflow triggered for demo."
    elif risk_level == "Medium" or manual_review_triggers or discrepancies:
        severity = "Low"
        system_action = "Manual Review Required"
        final_case_status = "Manual Review Required"
        customer_visible_status = "Under Review"
        staff_action = "Compliance staff must review discrepancies and take final action."
        customer_message = "Your KYC application is under manual review. We will notify you if additional documents are required."
        decision_reason = "Low/medium discrepancy detected. Case routed to manual review instead of auto-decision."
    else:
        severity = "None"
        system_action = "Ready for Staff Approval"
        final_case_status = "Manual Review Required"
        customer_visible_status = "Under Review"
        staff_action = "No major discrepancy found. Staff can approve after final review."
        customer_message = "Your KYC application is being reviewed by our onboarding team."
        decision_reason = "No major discrepancy detected. Case is ready for staff approval review."

    return {
        "discrepancy_level": severity,
        "system_action": system_action,
        "final_case_status": final_case_status,
        "customer_visible_status": customer_visible_status,
        "customer_message": customer_message,
        "staff_required_action": staff_action,
        "decision_reason": decision_reason,
        "high_discrepancy_triggers": high_triggers,
        "manual_review_triggers": manual_review_triggers,
        "all_discrepancies": discrepancies,
        "auto_reject": system_action == "Auto Reject",
        "manual_review": system_action == "Manual Review Required",
        "risk_score": score,
        "risk_level": risk_level,
    }

def run_master_orchestrator(case_id: str, api_key: str = None) -> dict:
    """
    Executes the entire KYC multi-agent compliance pipeline for a given case_id.
    """
    # 1. Load data
    case_details = get_case_details(case_id)
    if not case_details:
        return {"success": False, "message": f"Case ID {case_id} not found."}
        
    rules = load_compliance_rules()
    policy_text = load_kyc_policy()
    
    cust = case_details["customer"]
    cust_id = cust["customer_id"]
    
    # 2. Perform OCR Verification on documents
    ocr_results = []
    for doc in case_details["documents"]:
        ocr_res = run_simulated_ocr_checks(doc, cust, rules)
        ocr_results.append(ocr_res)
        
    # 3. Create secure masked context
    masked_cust = mask_customer_dict(cust)
    
    masked_docs = []
    for d in case_details["documents"]:
        md = d.copy()
        md["id_number"] = mask_pan(d["id_number"]) if d["document_type"] == "PAN" else mask_aadhaar(d["id_number"]) if d["document_type"] == "Aadhaar" else d["id_number"]
        md["document_name_value"] = md["document_name_value"] # names are already partial or full, but mask address and dob if necessary
        md["document_dob_value"] = md["document_dob_value"]
        md["document_address_value"] = mask_address(md["document_address_value"])
        masked_docs.append(md)
        
    masked_selfie = case_details["selfie_verification"].copy()
    
    masked_fraud = case_details["fraud_watchlist"].copy()
    
    masked_sanctions = case_details["sanctions_watchlist"].copy()
    
    masked_pep = case_details["pep_watchlist"].copy()
    
    masked_adverse = case_details["adverse_media"].copy()
    
    # Trans summary (mask bank details if any)
    txns = case_details["transactions"]
    masked_txns = []
    for t in txns:
        mt = t.copy()
        masked_txns.append(mt)
        
    secure_context = {
        "case_id": case_id,
        "customer_id": cust_id,
        "customer_profile": masked_cust,
        "documents": masked_docs,
        "selfie_verification": masked_selfie,
        "transactions": masked_txns,
        "fraud_watchlist": masked_fraud,
        "sanctions_watchlist": masked_sanctions,
        "pep_watchlist": masked_pep,
        "adverse_media": masked_adverse,
        "ocr_sim_results": ocr_results,
        "policy_rules": rules,
        "case_history": case_details.get("case_history", []),
        "policy_knowledge_snippet": policy_text[:1200]  # First chunk for context
    }
    
    # 4. Run Quantitative Risk Scoring
    risk_res = calculate_case_risk(case_details, rules)
    risk_result_model = RiskResult(**risk_res)
    
    # 5. Run Guardrails Policy checks
    guardrail_res = validate_guardrails(case_details, risk_res, rules)
    guardrail_result_model = GuardrailResult(**guardrail_res)
    
    # 6. Business workflow decision: discrepancy severity -> manual review or auto rejection
    decision_workflow = build_discrepancy_decision(case_details, ocr_results, risk_res, guardrail_res)
    
    # 7. Execute Specialist Agents in sequence
    agent_findings = []
    
    # Agent 2: Document Intelligence Agent
    doc_finding = run_document_intelligence_agent(case_details, rules)
    agent_findings.append(doc_finding)
    
    # Agent 3: Identity Verification Agent
    id_finding = run_identity_verification_agent(case_details, rules)
    agent_findings.append(id_finding)
    
    # Agent 4: Compliance RAG Agent
    rag_finding = run_compliance_rag_agent(case_details, rules)
    agent_findings.append(rag_finding)
    
    # Agent 5: AML & Sanctions Screening Agent
    aml_finding = run_aml_sanctions_agent(case_details, rules)
    agent_findings.append(aml_finding)
    
    # Agent 6: PEP Screening Agent
    pep_finding = run_pep_screening_agent(case_details, rules)
    agent_findings.append(pep_finding)
    
    # Agent 7: Adverse Media Agent
    adverse_finding = run_adverse_media_agent(case_details, rules)
    agent_findings.append(adverse_finding)
    
    # Agent 8: Financial Profiling Agent
    fin_finding = run_financial_profiling_agent(case_details, rules)
    agent_findings.append(fin_finding)
    
    # Agent 9: Fraud Intelligence Agent
    fraud_finding = run_fraud_intelligence_agent(case_details, rules)
    agent_findings.append(fraud_finding)
    
    # Agent 10: Transaction Risk Agent
    tx_finding = run_transaction_risk_agent(case_details, rules)
    agent_findings.append(tx_finding)
    
    # Agent 11: Risk Intelligence Agent
    risk_agent_finding = run_risk_intelligence_agent(case_details, risk_res)
    agent_findings.append(risk_agent_finding)
    
    # Agent 12: Guardrail Agent
    guardrail_agent_finding = run_guardrail_agent(case_details, guardrail_res)
    agent_findings.append(guardrail_agent_finding)
    
    # Serialized summaries for Gemini
    secure_context_str = json.dumps(secure_context, indent=2, default=str)
    agent_findings_str = "\n".join([f"- {f.agent_name} Status: {f.status} | Finding: {f.finding} | Evidence: {f.evidence}" for f in agent_findings])
    risk_summary_str = f"Risk Score: {risk_res['risk_score']}/100 | Risk Level: {risk_res['risk_level']} | Decision: {risk_res['recommended_decision']}"
    guardrail_summary_str = f"Status: {guardrail_res['status']} | Reasons: {', '.join(guardrail_res['blocked_reasons'])} | Action: {guardrail_res['required_human_action']}"
    
    # Agent 13: Gemini Reasoning Agent (Calls API, fallbacks if key is missing or call fails)
    gemini_reasoning = run_gemini_reasoning(
        api_key, 
        secure_context_str, 
        agent_findings_str, 
        risk_summary_str, 
        guardrail_summary_str
    )
    
    is_fallback = False
    if not gemini_reasoning:
        is_fallback = True
        gemini_reasoning = generate_fallback_reasoning(case_details, [f.model_dump() for f in agent_findings], risk_res, guardrail_res)
        
    gemini_agent_finding = run_gemini_reasoning_agent(case_details, gemini_reasoning)
    agent_findings.append(gemini_agent_finding)
    
    # Agent 14: Decision Reasoning Agent
    rec_decision = f"System Recommendation: {risk_res['recommended_decision']} | Policy Guardrails: {guardrail_res['status']}"
    decision_finding = run_decision_reasoning_agent(case_details, rec_decision)
    agent_findings.append(decision_finding)
    
    # Agent 15: Notification & Email Agent
    drafts = generate_all_notification_drafts(case_details, risk_res, guardrail_res, gemini_reasoning, decision_workflow)
    notif_finding = run_notification_agent(case_details, drafts)
    agent_findings.append(notif_finding)
    
    # Agent 16: Human Review Agent
    # For now, setup empty placeholder, populated during final action.
    human_finding = run_human_review_agent(case_details, {"action": "Pending Review", "comments": "Case has been analyzed. Awaiting Compliance Manager decision."})
    agent_findings.append(human_finding)
    
    # Agent 17: Audit & Governance Agent
    audit_summary = f"Case analyzed. Risk score {risk_res['risk_score']}/100. Guardrail status {guardrail_res['status']}."
    audit_finding = run_audit_agent(case_details, audit_summary)
    agent_findings.append(audit_finding)
    
    # 7. Write outputs to log folders
    trace_path = DIRS["agent_traces"] / f"{case_id}_trace.json"
    with open(trace_path, "w") as f:
        json.dump([finding.model_dump() for finding in agent_findings], f, indent=4)
        
    decision_path = DIRS["decision_logs"] / f"{case_id}_decision.json"
    decision_log = {
        "case_id": case_id,
        "customer_id": cust_id,
        "risk_result": risk_res,
        "guardrail_result": guardrail_res,
        "decision_workflow": decision_workflow,
        "gemini_reasoning": gemini_reasoning,
        "recommendation": rec_decision,
        "decision_workflow": decision_workflow,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    with open(decision_path, "w") as f:
        json.dump(decision_log, f, indent=4)
        
    # Append to audit trail JSON
    audit_path = DIRS["audit_logs"] / "audit_trail.json"
    audit_events = []
    if audit_path.exists():
        try:
            with open(audit_path, "r") as f:
                audit_events = json.load(f)
        except Exception:
            pass
            
    new_audit = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "case_id": case_id,
        "customer_id": cust_id,
        "risk_score": risk_res["risk_score"],
        "guardrail_status": guardrail_res["status"],
        "action": "Orchestrator Analysis",
        "actor": "Master Orchestrator Agent"
    }
    audit_events.append(new_audit)
    with open(audit_path, "w") as f:
        json.dump(audit_events, f, indent=4)

    return {
        "success": True,
        "case_id": case_id,
        "customer_id": cust_id,
        "secure_context": secure_context,
        "agent_findings": [f.model_dump() for f in agent_findings],
        "risk_result": risk_res,
        "guardrail_result": guardrail_res,
        "decision_workflow": decision_workflow,
        "gemini_reasoning": gemini_reasoning,
        "recommendation": rec_decision,
        "notification_drafts": drafts,
        "is_fallback": is_fallback
    }
