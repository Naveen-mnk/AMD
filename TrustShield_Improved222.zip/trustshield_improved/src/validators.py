"""
Input Validation Utilities — used across registration / upload forms.
Returns (is_valid: bool, error_message: str) tuples for easy Streamlit integration.
"""
from __future__ import annotations
import re
from datetime import date, datetime

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
MOBILE_RE = re.compile(r"^[6-9]\d{9}$")           # Indian mobile numbers
PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")   # Indian PAN format
AADHAAR_RE = re.compile(r"^\d{12}$")
PINCODE_RE = re.compile(r"^\d{6}$")


def validate_email(value: str) -> tuple[bool, str]:
    value = (value or "").strip()
    if not value:
        return False, "Email is required."
    if not EMAIL_RE.match(value):
        return False, "Enter a valid email address (e.g. name@example.com)."
    return True, ""


def validate_mobile(value: str) -> tuple[bool, str]:
    value = re.sub(r"[\s\-+]", "", str(value or ""))
    if value.startswith("91") and len(value) == 12:
        value = value[2:]
    if not value:
        return False, "Mobile number is required."
    if not MOBILE_RE.match(value):
        return False, "Enter a valid 10-digit Indian mobile number starting with 6-9."
    return True, ""


def validate_pan(value: str) -> tuple[bool, str]:
    value = (value or "").strip().upper()
    if not value:
        return False, "PAN is required."
    if not PAN_RE.match(value):
        return False, "Enter a valid PAN (format: ABCDE1234F)."
    return True, ""


def validate_aadhaar(value: str) -> tuple[bool, str]:
    value = re.sub(r"[^0-9]", "", str(value or ""))
    if not value:
        return False, "Aadhaar number is required."
    if not AADHAAR_RE.match(value):
        return False, "Enter a valid 12-digit Aadhaar number."
    return True, ""


def validate_pincode(value: str) -> tuple[bool, str]:
    value = (value or "").strip()
    if not value:
        return False, "PIN code is required."
    if not PINCODE_RE.match(value):
        return False, "Enter a valid 6-digit PIN code."
    return True, ""


def validate_full_name(value: str) -> tuple[bool, str]:
    value = (value or "").strip()
    if not value:
        return False, "Full name is required."
    if len(value) < 3:
        return False, "Full name must be at least 3 characters."
    if not re.match(r"^[A-Za-z\s.'\-]+$", value):
        return False, "Full name can only contain letters, spaces, apostrophes, periods and hyphens."
    return True, ""


def validate_dob(value, min_age: int = 18, max_age: int = 100) -> tuple[bool, str]:
    """Accepts a date object or 'YYYY-MM-DD' string."""
    if value is None or value == "":
        return False, "Date of birth is required."
    try:
        if isinstance(value, str):
            dob = datetime.strptime(value[:10], "%Y-%m-%d").date()
        elif isinstance(value, datetime):
            dob = value.date()
        else:
            dob = value
    except Exception:
        return False, "Enter a valid date of birth (YYYY-MM-DD)."

    today = date.today()
    if dob > today:
        return False, "Date of birth cannot be in the future."
    age = (today - dob).days // 365
    if age < min_age:
        return False, f"Applicant must be at least {min_age} years old."
    if age > max_age:
        return False, f"Date of birth implies an age over {max_age} — please verify."
    return True, ""


def validate_bank_account(value: str) -> tuple[bool, str]:
    value = re.sub(r"[^0-9]", "", str(value or ""))
    if not value:
        return False, "Bank account number is required."
    if not (9 <= len(value) <= 18):
        return False, "Bank account number must be between 9 and 18 digits."
    return True, ""


def validate_username(value: str) -> tuple[bool, str]:
    value = (value or "").strip()
    if not value:
        return False, "Username is required."
    if len(value) < 4:
        return False, "Username must be at least 4 characters."
    if not re.match(r"^[A-Za-z0-9._\-]+$", value):
        return False, "Username can only contain letters, numbers, dots, underscores and hyphens."
    return True, ""


def validate_password(value: str) -> tuple[bool, str]:
    value = value or ""
    if len(value) < 6:
        return False, "Password must be at least 6 characters."
    return True, ""


def validate_uploaded_file(uploaded_file, allowed_ext=(".png", ".jpg", ".jpeg", ".pdf"), max_size_mb: int = 5) -> tuple[bool, str]:
    """Validates a Streamlit UploadedFile object."""
    if uploaded_file is None:
        return False, "Please select a file to upload."
    name = uploaded_file.name.lower()
    if not any(name.endswith(ext) for ext in allowed_ext):
        return False, f"Unsupported file type. Allowed: {', '.join(allowed_ext)}"
    size_mb = uploaded_file.size / (1024 * 1024)
    if size_mb > max_size_mb:
        return False, f"File too large ({size_mb:.1f} MB). Maximum allowed size is {max_size_mb} MB."
    return True, ""


def validate_all(*results: tuple[bool, str]) -> tuple[bool, list[str]]:
    """Combines multiple (is_valid, msg) tuples. Returns (all_valid, [error messages])."""
    errors = [msg for ok, msg in results if not ok]
    return (len(errors) == 0), errors
