import os
import json
from datetime import datetime
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from src.config import DIRS
from src.pii_masking import mask_customer_dict, mask_pan, mask_aadhaar, mask_mobile, mask_bank_account, mask_address
import src.audit_trail as audit_trail

def generate_evidence_pack_pdf(orchestrator_result: dict) -> str:
    """
    Compiles a highly detailed multi-page PDF Audit Evidence Pack using ReportLab.
    Returns the path to the generated PDF file.
    """
    case_id = orchestrator_result["case_id"]
    cust_id = orchestrator_result["customer_id"]
    secure_context = orchestrator_result["secure_context"]
    cust = secure_context["customer_profile"]
    
    # Target PDF path
    pdf_path = DIRS["evidence_packs"] / f"{case_id}_evidence_pack.pdf"
    
    # Create the document template
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=letter,
        rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40
    )
    
    story = []
    
    # Style configuration
    styles = getSampleStyleSheet()
    
    # Custom colors
    navy = colors.HexColor('#0F172A') # Dark Navy Slate
    light_blue = colors.HexColor('#F1F5F9') # Cool Slate Background
    accent_blue = colors.HexColor('#2563EB') # Indigo Accent
    danger_red = colors.HexColor('#DC2626') # Red warning
    success_green = colors.HexColor('#16A34A') # Green pass
    
    # Custom Styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=22,
        textColor=colors.white,
        spaceAfter=10,
        alignment=0 # Left
    )
    
    h1_style = ParagraphStyle(
        'DocH1',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=14,
        textColor=navy,
        spaceBefore=14,
        spaceAfter=6,
        borderPadding=2
    )

    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['BodyText'],
        fontName='Helvetica',
        fontSize=9.5,
        textColor=colors.HexColor('#334155'),
        spaceAfter=4
    )
    
    body_bold = ParagraphStyle(
        'DocBodyBold',
        parent=body_style,
        fontName='Helvetica-Bold'
    )
    
    table_cell_style = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        textColor=colors.HexColor('#1E293B')
    )

    table_header_style = ParagraphStyle(
        'TableHeader',
        parent=table_cell_style,
        fontName='Helvetica-Bold',
        textColor=colors.white
    )

    # 1. Header Banner
    banner_data = [
        [
            Paragraph("TRUSTSHIELD AI COMPLIANCE ENGINE", title_style),
            Paragraph(f"AUDIT PROOF GENERATED: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ParagraphStyle('RightTime', fontName='Helvetica-Bold', fontSize=8, textColor=colors.white, alignment=2))
        ]
    ]
    banner_table = Table(banner_data, colWidths=[350, 180])
    banner_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), navy),
        ('PADDING', (0,0), (-1,-1), 12),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 14),
    ]))
    story.append(banner_table)
    story.append(Spacer(1, 15))
    
    # 2. Executive Case Summary Table
    story.append(Paragraph("1. EXECUTIVE CASE SUMMARY", h1_style))
    
    risk_result = orchestrator_result["risk_result"]
    guardrail_result = orchestrator_result["guardrail_result"]
    decision_workflow = orchestrator_result.get("decision_workflow", {})
    
    risk_level = risk_result["risk_level"]
    risk_color = danger_red if risk_level in ["Critical", "High"] else success_green if risk_level == "Low" else colors.orange
    
    summary_data = [
        [Paragraph("Case ID:", body_bold), Paragraph(case_id, body_style), Paragraph("Risk Score:", body_bold), Paragraph(f"{risk_result['risk_score']}/100", ParagraphStyle('Score', parent=body_bold, textColor=risk_color))],
        [Paragraph("Customer ID:", body_bold), Paragraph(cust_id, body_style), Paragraph("Risk Level:", body_bold), Paragraph(risk_level, ParagraphStyle('Level', parent=body_bold, textColor=risk_color))],
        [Paragraph("Full Name (Masked):", body_bold), Paragraph(cust["full_name"], body_style), Paragraph("Guardrail Status:", body_bold), Paragraph(guardrail_result["status"], ParagraphStyle('Guard', parent=body_bold, textColor=danger_red if guardrail_result["status"] == "Blocked" else success_green))],
        [Paragraph("DOB (Masked):", body_bold), Paragraph(cust["dob"], body_style), Paragraph("SLA Target:", body_bold), Paragraph(f"{cust['sla_hours']} Hours", body_style)],
        [Paragraph("Nationality:", body_bold), Paragraph(cust["nationality"], body_style), Paragraph("Case Status:", body_bold), Paragraph(cust["case_status"], body_bold)],
        [Paragraph("AI Workflow Action:", body_bold), Paragraph(decision_workflow.get("system_action", "Pending"), body_style), Paragraph("Discrepancy Level:", body_bold), Paragraph(decision_workflow.get("discrepancy_level", "N/A"), body_bold)],
    ]
    summary_table = Table(summary_data, colWidths=[130, 140, 120, 140])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), light_blue),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('PADDING', (0,0), (-1,-1), 6),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 12))
    
    # 2B. AI Workflow Decision
    if decision_workflow:
        story.append(Paragraph("2. AI AGENT WORKFLOW DECISION", h1_style))
        wf_text = f"""
        <b>System Action:</b> {decision_workflow.get('system_action')}<br/>
        <b>Final Case Status:</b> {decision_workflow.get('final_case_status')}<br/>
        <b>Decision Reason:</b> {decision_workflow.get('decision_reason')}<br/>
        <b>Required Staff Action:</b> {decision_workflow.get('staff_required_action')}<br/>
        <b>Customer Message:</b> {decision_workflow.get('customer_message')}
        """
        story.append(Paragraph(wf_text, body_style))
        triggers = decision_workflow.get('high_discrepancy_triggers') or decision_workflow.get('manual_review_triggers') or decision_workflow.get('all_discrepancies') or []
        if triggers:
            story.append(Paragraph("<b>Discrepancies / Incorrect Findings:</b>", body_bold))
            for t in triggers[:10]:
                story.append(Paragraph(f"• {t}", body_style))
        story.append(Spacer(1, 10))

    # 3. Embedding Customer Photo & Selfie Previews
    # Check if files exist and embed
    photo_path = DIRS["uploads"] / cust_id / "customer_photo.png"
    selfie_path = DIRS["uploads"] / cust_id / "selfie.png"
    
    image_elements = []
    if photo_path.exists():
        try:
            image_elements.append(Image(str(photo_path), width=1.8*inch, height=1.3*inch))
        except Exception:
            pass
    if selfie_path.exists():
        try:
            image_elements.append(Image(str(selfie_path), width=1.8*inch, height=1.3*inch))
        except Exception:
            pass
            
    if image_elements:
        story.append(Paragraph("2. FACIAL & IDENTITY CHECK PREVIEWS", h1_style))
        img_table_data = [image_elements]
        img_table = Table(img_table_data, colWidths=[2.5*inch, 2.5*inch])
        img_table.setStyle(TableStyle([
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('LEFTPADDING', (0,0), (-1,-1), 0),
            ('RIGHTPADDING', (0,0), (-1,-1), 20),
        ]))
        story.append(img_table)
        story.append(Spacer(1, 10))

    # 4. Specialist Agent Findings Table
    story.append(Paragraph("3. AUTOMATED SPECIALIST AGENTS LOG", h1_style))
    agent_headers = [Paragraph("Agent Name", table_header_style), Paragraph("Status", table_header_style), Paragraph("Findings & Context Evidence", table_header_style)]
    agent_rows = [agent_headers]
    
    for f in orchestrator_result["agent_findings"]:
        status_color = danger_red if f["status"] == "Failed" else success_green if f["status"] == "Passed" else colors.orange
        agent_rows.append([
            Paragraph(f["agent_name"], table_cell_style),
            Paragraph(f["status"], ParagraphStyle('AStat', parent=table_cell_style, fontName='Helvetica-Bold', textColor=status_color)),
            Paragraph(f"{f['finding']}. <i>{f['evidence']}</i>", table_cell_style)
        ])
        
    agent_table = Table(agent_rows, colWidths=[150, 60, 320])
    agent_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), navy),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#94A3B8')),
        ('PADDING', (0,0), (-1,-1), 5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, light_blue]),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(agent_table)
    story.append(Spacer(1, 12))

    # 5. Gemini Compliance Reasoning
    story.append(Paragraph("4. COMPLIANCE REASONING & POLICIES EXPLAINED", h1_style))
    gemini_text = orchestrator_result["gemini_reasoning"]
    
    # Break explanation into paragraphs
    gemini_paras = gemini_text.split("\n\n")
    for para in gemini_paras:
        if para.strip():
            story.append(Paragraph(para.replace("\n", "<br/>"), ParagraphStyle('GeminiP', parent=body_style, fontSize=9, leading=12)))
            story.append(Spacer(1, 4))
    story.append(Spacer(1, 8))
    
    # 6. Audit Trail & Human Review Override History
    story.append(Paragraph("5. COMPLIANCE AUDIT HISTORY LOG", h1_style))
    history_headers = [Paragraph("Timestamp", table_header_style), Paragraph("Action Event", table_header_style), Paragraph("Actor", table_header_style)]
    history_rows = [history_headers]
    
    # Read history entries from context
    for h in secure_context.get("ocr_sim_results", []):
        history_rows.append([
            Paragraph("OCR Check", table_cell_style),
            Paragraph(f"Doc: {h['document_type']} | Name Match: {h['name_match']} | DOB Match: {h['dob_match']}", table_cell_style),
            Paragraph("Doc Intel Agent", table_cell_style)
        ])
        
    for act in secure_context.get("case_history", []):
        history_rows.append([
            Paragraph(act.get("created_at", ""), table_cell_style),
            Paragraph(f"Status changed to {act.get('current_status')} - {act.get('last_action')}", table_cell_style),
            Paragraph(f"Ops/Reviewer User", table_cell_style)
        ])
        
    audit_table = Table(history_rows, colWidths=[110, 310, 110])
    audit_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), navy),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('PADDING', (0,0), (-1,-1), 4),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, light_blue]),
    ]))
    story.append(audit_table)
    story.append(Spacer(1, 12))

    # 5B. Guardrail Warnings (EDD triggers)
    warning_reasons = guardrail_result.get("warning_reasons", [])
    blocked_reasons = guardrail_result.get("blocked_reasons", [])
    if blocked_reasons or warning_reasons:
        story.append(Paragraph("6. POLICY GUARDRAIL TRIGGERS", h1_style))
        if blocked_reasons:
            story.append(Paragraph("<b>Hard Blocks:</b>", body_bold))
            for r in blocked_reasons:
                story.append(Paragraph(f"✗ {r}", ParagraphStyle('Blk', parent=body_style, textColor=danger_red)))
        if warning_reasons:
            story.append(Paragraph("<b>Enhanced Due Diligence (EDD) Warnings:</b>", body_bold))
            for w in warning_reasons:
                story.append(Paragraph(f"⚠ {w}", ParagraphStyle('Wrn', parent=body_style, textColor=colors.orange)))
        story.append(Spacer(1, 8))

    # 5C. Audit Trail Integrity Verification
    story.append(Paragraph("7. AUDIT TRAIL INTEGRITY VERIFICATION", h1_style))
    try:
        chain_status = audit_trail.verify_chain()
    except Exception:
        chain_status = {"valid": None, "total_events": 0}

    if chain_status.get("valid") is True:
        integrity_text = f"✅ Audit trail integrity VERIFIED. {chain_status.get('total_events', 0)} hash-chained event(s) recorded. No tampering detected."
        integrity_color = success_green
    elif chain_status.get("valid") is False:
        integrity_text = f"⚠️ Audit trail integrity check FAILED at event #{chain_status.get('first_invalid_index')}. Investigate immediately."
        integrity_color = danger_red
    else:
        integrity_text = "Audit trail integrity could not be verified at report-generation time."
        integrity_color = colors.orange

    story.append(Paragraph(integrity_text, ParagraphStyle('Integrity', parent=body_style, textColor=integrity_color, fontName='Helvetica-Bold')))
    story.append(Spacer(1, 12))


    story.append(KeepTogether([
        Paragraph("<b>Audit Declaration:</b> This onboarding record contains generated synthetic customer identities created solely for testing compliance pipelines under the TCS + AMD trust program framework. No real regulatory PII is contained herein.", ParagraphStyle('Disc', parent=body_style, fontSize=7.5, leading=10, textColor=colors.HexColor('#64748B'))),
        Spacer(1, 10),
        Table([
            [Paragraph("Prepared By: TrustShield AI Orchestrator", body_style), Paragraph("Authorized Supervisor Signature: _______________________", ParagraphStyle('Sig', parent=body_style, alignment=2))]
        ], colWidths=[260, 270])
    ]))

    # Build the document
    doc.build(story)
    
    # Write summary event to audit trail logs
    report_log_path = DIRS["audit_reports"] / f"{case_id}_report_generation.json"
    with open(report_log_path, "w") as f:
        json.dump({
            "case_id": case_id,
            "customer_id": cust_id,
            "pdf_report_path": str(pdf_path),
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "Archived Successfully"
        }, f, indent=4)
        
    return str(pdf_path)
