import os
import hashlib
import hmac
from pathlib import Path

# ─────────────────────────────────────────────────────────────────
#  PROJECT ROOT
# ─────────────────────────────────────────────────────────────────
SRC_DIR     = Path(__file__).resolve().parent
PROJECT_ROOT = SRC_DIR.parent

# ─────────────────────────────────────────────────────────────────
#  DIRECTORY MAP
# ─────────────────────────────────────────────────────────────────
DIRS = {
    "data":           PROJECT_ROOT / "data",
    "uploads":        PROJECT_ROOT / "uploads" / "demo_customer_docs",
    "agent_traces":   PROJECT_ROOT / "outputs" / "agent_traces",
    "decision_logs":  PROJECT_ROOT / "outputs" / "decision_logs",
    "notifications":  PROJECT_ROOT / "outputs" / "notifications",
    "audit_logs":     PROJECT_ROOT / "outputs" / "audit_logs",
    "audit_reports":  PROJECT_ROOT / "reports" / "audit_reports",
    "evidence_packs": PROJECT_ROOT / "reports" / "evidence_packs",
    "assets_images":  PROJECT_ROOT / "assets" / "images",
    "assets_styles":  PROJECT_ROOT / "assets" / "styles",
}

def ensure_directories():
    for path in DIRS.values():
        path.mkdir(parents=True, exist_ok=True)

ensure_directories()

# ─────────────────────────────────────────────────────────────────
#  PASSWORD HASHING  (SHA-256 + HMAC — no external deps needed)
# ─────────────────────────────────────────────────────────────────
# Secret pepper — in production this should come from an env variable / secrets manager.
_PEPPER = os.environ.get("TS_PASSWORD_PEPPER", "TrustShield#AMD#KYC#2025")

def _hash_password(plain: str) -> str:
    """Returns a hex-encoded HMAC-SHA256 hash of the password."""
    return hmac.new(_PEPPER.encode(), plain.encode(), hashlib.sha256).hexdigest()

def verify_password(plain: str, hashed: str) -> bool:
    """Constant-time comparison — prevents timing attacks."""
    return hmac.compare_digest(_hash_password(plain), hashed)

# ─────────────────────────────────────────────────────────────────
#  CREDENTIALS  (passwords stored as HMAC-SHA256 hashes)
#  Plain password for all demo accounts: Trust@123
# ─────────────────────────────────────────────────────────────────
_DEMO_HASH = _hash_password("Trust@123")

STAFF_CREDENTIALS = {
    "staff": {
        "password_hash": _DEMO_HASH,
        "role": "KYC Staff",
        "name": "KYC Review Officer",
    },
}

CUSTOMER_CREDENTIALS = {
    "demo.low1":     {"password_hash": _DEMO_HASH, "customer_id": "CUST00001", "risk": "Low"},
    "demo.low2":     {"password_hash": _DEMO_HASH, "customer_id": "CUST00002", "risk": "Low"},
    "demo.medium1":  {"password_hash": _DEMO_HASH, "customer_id": "CUST02500", "risk": "Medium"},
    "demo.medium2":  {"password_hash": _DEMO_HASH, "customer_id": "CUST02501", "risk": "Medium"},
    "demo.medium3":  {"password_hash": _DEMO_HASH, "customer_id": "CUST02502", "risk": "Medium"},
    "demo.high1":    {"password_hash": _DEMO_HASH, "customer_id": "CUST04999", "risk": "High"},
    "demo.high2":    {"password_hash": _DEMO_HASH, "customer_id": "CUST04998", "risk": "High"},
    "demo.critical1":{"password_hash": _DEMO_HASH, "customer_id": "CUST05000", "risk": "Critical"},
    "demo.critical2":{"password_hash": _DEMO_HASH, "customer_id": "CUST05001", "risk": "Critical"},
    "demo.critical3":{"password_hash": _DEMO_HASH, "customer_id": "CUST05002", "risk": "Critical"},
}

# ─────────────────────────────────────────────────────────────────
#  FILE MAP
# ─────────────────────────────────────────────────────────────────
FILES = {
    "customers":              DIRS["data"] / "customers.csv",
    "kyc_documents":          DIRS["data"] / "kyc_documents.csv",
    "transactions":           DIRS["data"] / "transactions.csv",
    "fraud_watchlist":        DIRS["data"] / "fraud_watchlist.csv",
    "sanctions_watchlist":    DIRS["data"] / "sanctions_watchlist.csv",
    "pep_watchlist":          DIRS["data"] / "pep_watchlist.csv",
    "adverse_media":          DIRS["data"] / "adverse_media.csv",
    "case_history":           DIRS["data"] / "case_history.csv",
    "selfie_verification":    DIRS["data"] / "selfie_verification.csv",
    "document_file_registry": DIRS["data"] / "document_file_registry.csv",
    "compliance_rules":       DIRS["data"] / "compliance_rules.json",
    "kyc_policy_knowledge":   DIRS["data"] / "kyc_policy_knowledge.txt",
}

# ─────────────────────────────────────────────────────────────────
#  SESSION TIMEOUT  (minutes of inactivity before auto-logout)
# ─────────────────────────────────────────────────────────────────
SESSION_TIMEOUT_MINUTES = 30
