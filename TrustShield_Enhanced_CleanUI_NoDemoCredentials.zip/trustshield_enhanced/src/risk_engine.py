def calculate_case_risk(case_details: dict, rules: dict) -> dict:
    """
    Calculates the aggregate risk score (0-100) and risk level for a case.
    Also returns a breakdown of risk drivers and recommended decisions.
    """
    weights = rules.get("risk_weights", {})
    
    score = 0
    drivers = []
    
    # 1. Document checks
    docs = case_details.get("documents", [])
    doc_types_present = [d.get("document_type") for d in docs]
    mandatory_docs = rules.get("mandatory_documents", ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof", "Selfie"])
    
    # Check missing mandatory docs
    for m_doc in mandatory_docs:
        if m_doc == "Selfie":
            continue # Checked separately in selfie verification
        if m_doc not in doc_types_present:
            impact = weights.get("missing_document", 15)
            score += impact
            drivers.append(f"Missing mandatory document: {m_doc} (+{impact})")

    # Document details check
    for doc in docs:
        dtype = doc.get("document_type")
        status = doc.get("document_status")
        tamper = doc.get("tampering_indicator")
        confidence = doc.get("confidence_score", 1.0)
        quality = doc.get("quality_status")
        
        # Check tampering
        if tamper == "Detected" or status == "Failed":
            impact = weights.get("tampering_suspected", 30)
            score += impact
            drivers.append(f"Suspected document tampering on {dtype} (+{impact})")
            
        # Check expired
        if status == "Expired":
            impact = weights.get("expired_document", 20)
            score += impact
            drivers.append(f"Expired document: {dtype} (+{impact})")
            
        # Check low confidence
        elif confidence < rules.get("min_document_confidence", 0.60):
            impact = weights.get("low_confidence_doc", 10)
            score += impact
            drivers.append(f"Low confidence OCR extraction for {dtype} (+{impact})")
            
        # Check quality
        elif quality in ["Blurred", "Incomplete"]:
            impact = weights.get("poor_selfie_quality", 10) # poor doc quality
            score += impact
            drivers.append(f"Poor image quality for {dtype}: {quality} (+{impact})")

        # Mismatch checks
        # Compare profile values vs document values
        cust = case_details.get("customer", {})
        # Check name mismatch
        doc_name = doc.get("document_name_value", "")
        prof_name = cust.get("full_name", "")
        if doc_name and prof_name:
            # simple token check
            d_tok = set(str(doc_name).lower().split())
            p_tok = set(str(prof_name).lower().split())
            if not d_tok.intersection(p_tok):
                impact = weights.get("name_mismatch", 15)
                score += impact
                drivers.append(f"Name mismatch in {dtype} (+{impact})")
            elif d_tok != p_tok:
                # partial mismatch
                impact = 5
                score += impact
                drivers.append(f"Partial name mismatch in {dtype} (+{impact})")
                
        # Check DOB mismatch
        doc_dob = doc.get("document_dob_value", "")
        prof_dob = cust.get("dob", "")
        if doc_dob and prof_dob and doc_dob != prof_dob:
            impact = weights.get("dob_mismatch", 15)
            score += impact
            drivers.append(f"DOB mismatch in {dtype} (+{impact})")

    # 2. Selfie verification checks
    selfie = case_details.get("selfie_verification", {})
    if not selfie or not selfie.get("selfie_available", 0):
        impact = weights.get("missing_document", 15)
        score += impact
        drivers.append(f"Missing customer selfie upload (+{impact})")
    else:
        liveness = selfie.get("liveness_check", "Passed")
        match_score = selfie.get("selfie_match_score", 1.0)
        quality = selfie.get("selfie_quality", "Passed")
        
        if liveness == "Failed":
            impact = weights.get("liveness_failed", 25)
            score += impact
            drivers.append(f"Selfie liveness check failed (+{impact})")
            
        if match_score < 0.50:
            impact = weights.get("selfie_match_failed", 25)
            score += impact
            drivers.append(f"Selfie facial match failed: {match_score*100:.0f}% similarity (+{impact})")
            
        elif quality == "Poor":
            impact = weights.get("poor_selfie_quality", 10)
            score += impact
            drivers.append(f"Poor selfie image quality (+{impact})")

    # 3. Fraud Watchlist
    fraud = case_details.get("fraud_watchlist", {})
    if fraud:
        if fraud.get("duplicate_pan", 0):
            impact = weights.get("duplicate_pan", 30)
            score += impact
            drivers.append(f"Duplicate PAN matching another account (+{impact})")
        if fraud.get("duplicate_mobile", 0):
            impact = weights.get("duplicate_mobile", 15)
            score += impact
            drivers.append(f"Duplicate mobile number matching another account (+{impact})")
        if fraud.get("duplicate_bank_account", 0):
            impact = weights.get("duplicate_bank_account", 15)
            score += impact
            drivers.append(f"Duplicate bank account matching another account (+{impact})")
        if fraud.get("synthetic_identity_signal", 0):
            impact = weights.get("synthetic_identity", 25)
            score += impact
            drivers.append(f"Synthetic identity signature detected (+{impact})")
        if fraud.get("repeated_kyc_attempt", 0):
            impact = weights.get("repeated_kyc", 10)
            score += impact
            drivers.append(f"Repeated KYC registration attempts (+{impact})")

    # 4. Sanctions Watchlist
    sanctions = case_details.get("sanctions_watchlist", {})
    if sanctions:
        if sanctions.get("sanctions_match", 0):
            impact = weights.get("sanctions_match", 45)
            score += impact
            drivers.append(f"Watchlist Match: India AML watchlist (+{impact})")
        if sanctions.get("high_risk_country", 0):
            impact = weights.get("high_risk_country", 20)
            score += impact
            drivers.append(f"Domestic enhanced due diligence geography (+{impact})")

    # 5. PEP Watchlist
    pep = case_details.get("pep_watchlist", {})
    if pep and pep.get("pep_match", 0):
        impact = weights.get("pep_match", 25)
        score += impact
        drivers.append(f"Watchlist Match: Politically Exposed Person (PEP) ({pep.get('pep_category', 'Category-1')}) (+{impact})")

    # 6. Adverse Media
    adverse = case_details.get("adverse_media", {})
    if adverse and adverse.get("adverse_media_match", 0):
        impact = weights.get("adverse_media_match", 20)
        score += impact
        drivers.append(f"Negative media hit detected: Regulatory/Scrutiny concern (+{impact})")

    # 7. Transaction Risk Analysis
    txns = case_details.get("transactions", [])
    suspicious_count = sum(1 for t in txns if t.get("suspicious_txn_flag", 0))
    high_val_count = sum(1 for t in txns if t.get("high_value_flag", 0))
    velocity_risk_count = sum(1 for t in txns if t.get("velocity_risk", 0))
    
    if suspicious_count > 0:
        impact = weights.get("suspicious_txn", 15)
        score += impact
        drivers.append(f"Suspicious transaction pattern flagged (+{impact})")
        
    if high_val_count > 0:
        impact = weights.get("high_value_txn", 10)
        score += impact
        drivers.append(f"High-value transactions detected (+{impact})")

    # Bound the score between 0 and 100
    score = min(max(score, 0), 100)
    
    # Classify Risk Band
    if score <= rules.get("manual_review_score", 30):
        risk_level = "Low"
        recommended_decision = "Eligible for Approval"
    elif score <= rules.get("escalate_score", 60):
        risk_level = "Medium"
        recommended_decision = "Manual Review Required"
    elif score <= rules.get("reject_score", 80):
        risk_level = "High"
        recommended_decision = "Escalated to Compliance / Fraud Team"
    else:
        risk_level = "Critical"
        recommended_decision = "Reject or Senior Approval Required"
        
    return {
        "risk_score": int(score),
        "risk_level": risk_level,
        "risk_drivers": drivers if drivers else ["No notable risk drivers detected (Standard Profile)"],
        "recommended_decision": recommended_decision
    }
