import os
import json
import time
import random
from datetime import datetime, date, timedelta
from pathlib import Path

import pandas as pd
import streamlit as st
from PIL import Image
from dotenv import load_dotenv

load_dotenv()

from src.config import STAFF_CREDENTIALS, CUSTOMER_CREDENTIALS, DIRS
from src.constants import *
from src.pii_masking import mask_customer_dict
from src.data_loader import (
    load_customers, save_customers, load_kyc_documents, save_kyc_documents,
    load_transactions, load_case_history, save_case_history, load_selfie_verification, save_selfie_verification,
    load_document_file_registry, save_document_file_registry, load_compliance_rules, get_case_details, update_case_status
)
from src.orchestrator import run_master_orchestrator
from src.report_generator import generate_evidence_pack_pdf

st.set_page_config(
    page_title="TrustShield AI — KYC Intelligence Platform",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ═══════════════════════════════════════════════════════════════════
#  WORLD-CLASS KYC PORTAL CSS  — Dark navy / gold / white  
# ═══════════════════════════════════════════════════════════════════
st.markdown("""
<style>
/* ── Hide Streamlit default toolbar/menu/footer for clean UI ── */
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}
[data-testid="stToolbar"] {display: none !important;}
[data-testid="stDecoration"] {display: none !important;}
[data-testid="stStatusWidget"] {display: none !important;}
[data-testid="stHeader"] {display: none !important;}
.stDeployButton {display: none !important;}

/* ── Cleaner enterprise form fields ── */
.stTextInput input, .stTextArea textarea, .stSelectbox div[data-baseweb="select"] > div,
.stNumberInput input, .stDateInput input {
  background-color: #F8FAFC !important;
  color: #111827 !important;
  border: 1px solid #CBD5E1 !important;
  border-radius: 10px !important;
}
.stTextInput input:focus, .stTextArea textarea:focus, .stNumberInput input:focus, .stDateInput input:focus {
  border-color: #D4A017 !important;
  box-shadow: 0 0 0 1px #D4A017 !important;
}
.stTextInput input::placeholder, .stTextArea textarea::placeholder {
  color: #64748B !important;
}

/* Muted logout style - avoid bright attention stealing button */
button[kind="secondary"] {
  border-radius: 10px !important;
}

/* ── Google Fonts ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');

/* ── CSS Variables ── */
:root {
  --navy:       #0a1628;
  --navy-2:     #0f2044;
  --navy-3:     #142554;
  --gold:       #c8962a;
  --gold-light: #f5c842;
  --gold-pale:  #fff8e7;
  --accent:     #1e6fb5;
  --accent-2:   #0d4f8c;
  --success:    #10b981;
  --success-bg: #ecfdf5;
  --warning:    #f59e0b;
  --warning-bg: #fffbeb;
  --danger:     #ef4444;
  --danger-bg:  #fef2f2;
  --info:       #3b82f6;
  --info-bg:    #eff6ff;
  --surface:    #ffffff;
  --surface-2:  #f8faff;
  --border:     #e2e8f5;
  --text:       #1a2540;
  --muted:      #64748b;
  --sidebar-w:  280px;
}

/* ── Reset & Base ── */
html, body, [class*="css"] {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
  -webkit-font-smoothing: antialiased;
}

/* ── App Background — KYC themed geometric pattern ── */
.stApp {
  background:
    radial-gradient(ellipse at 0% 0%, rgba(14,32,68,0.95) 0%, transparent 60%),
    radial-gradient(ellipse at 100% 100%, rgba(10,22,40,0.98) 0%, transparent 60%),
    linear-gradient(135deg, #0a1628 0%, #0f2044 35%, #0d1a35 65%, #0a1628 100%);
  min-height: 100vh;
}

/* ── Subtle hex/grid overlay ── */
.stApp::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image:
    linear-gradient(rgba(200,150,42,0.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(200,150,42,0.04) 1px, transparent 1px);
  background-size: 60px 60px;
  pointer-events: none;
  z-index: 0;
}

/* ── Main container ── */
.block-container {
  padding: 1.5rem 2rem 4rem !important;
  max-width: 1500px !important;
  position: relative;
  z-index: 1;
}

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
  background: linear-gradient(180deg, #060e1f 0%, #091628 40%, #060e1f 100%) !important;
  border-right: 1px solid rgba(200,150,42,0.25) !important;
  box-shadow: 4px 0 32px rgba(0,0,0,0.5) !important;
}
section[data-testid="stSidebar"] > div { padding-top: 0 !important; }
section[data-testid="stSidebar"] * { color: #c8d8f0 !important; }
section[data-testid="stSidebar"] .stRadio > label { color: #a0b4d0 !important; font-size: 13px !important; }
section[data-testid="stSidebar"] hr { border-color: rgba(200,150,42,0.2) !important; margin: 10px 0 !important; }

/* Sidebar brand strip */
.sidebar-brand {
  background: linear-gradient(135deg, var(--gold) 0%, #e8ac30 100%);
  margin: -1rem -1rem 1rem;
  padding: 18px 20px 16px;
  text-align: center;
}
.sidebar-brand-title {
  font-size: 20px;
  font-weight: 900;
  color: #0a1628 !important;
  letter-spacing: -0.5px;
}
.sidebar-brand-sub {
  font-size: 10px;
  font-weight: 700;
  color: rgba(10,22,40,0.7) !important;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  margin-top: 2px;
}
.sidebar-user-badge {
  background: rgba(200,150,42,0.12);
  border: 1px solid rgba(200,150,42,0.25);
  border-radius: 10px;
  padding: 10px 14px;
  margin: 8px 0;
}
.sidebar-user-name { font-size: 13px; font-weight: 700; color: #e8d098 !important; }
.sidebar-user-role { font-size: 11px; color: #8a9ab8 !important; }

/* ── Page Title ── */
.page-header {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid rgba(200,150,42,0.2);
}
.page-title {
  font-size: 28px;
  font-weight: 800;
  color: #ffffff;
  letter-spacing: -0.5px;
  line-height: 1;
}
.page-subtitle { font-size: 13px; color: #7a94b8; margin-top: 4px; }
.page-icon {
  width: 46px; height: 46px;
  background: linear-gradient(135deg, var(--gold) 0%, #e8ac30 100%);
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  font-size: 22px;
  flex-shrink: 0;
  box-shadow: 0 4px 16px rgba(200,150,42,0.35);
}

/* ── KPI Metric Cards ── */
.kpi-grid { display: grid; gap: 14px; }
.kpi-card {
  background: linear-gradient(135deg, #0f1f3d 0%, #142048 100%);
  border: 1px solid rgba(200,150,42,0.2);
  border-radius: 16px;
  padding: 18px 20px;
  position: relative;
  overflow: hidden;
  transition: transform 0.2s, box-shadow 0.2s;
}
.kpi-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--gold), #e8ac30);
}
.kpi-card:hover { transform: translateY(-2px); box-shadow: 0 12px 32px rgba(0,0,0,0.4); }
.kpi-icon { font-size: 28px; margin-bottom: 10px; opacity: 0.9; }
.kpi-value { font-size: 34px; font-weight: 900; color: #ffffff; line-height: 1; }
.kpi-label { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; color: #7a94b8; margin-top: 6px; }
.kpi-caption { font-size: 11px; color: #556080; margin-top: 4px; }
.kpi-card.success::before { background: linear-gradient(90deg, var(--success), #34d399); }
.kpi-card.danger::before { background: linear-gradient(90deg, var(--danger), #f87171); }
.kpi-card.warning::before { background: linear-gradient(90deg, var(--warning), #fbbf24); }
.kpi-card.info::before { background: linear-gradient(90deg, var(--info), #60a5fa); }

/* ── Section Cards ── */
.section-card {
  background: linear-gradient(135deg, #0d1b35 0%, #111e3a 100%);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 18px;
  padding: 22px 24px;
  margin-bottom: 18px;
  position: relative;
  overflow: hidden;
}
.section-card-title {
  font-size: 12px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--gold);
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.section-card-title::after {
  content: '';
  flex: 1;
  height: 1px;
  background: rgba(200,150,42,0.2);
}

/* ── Status Badges ── */
.badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.3px;
  white-space: nowrap;
  border: 1px solid transparent;
}
.badge::before { content: '●'; font-size: 8px; }
.badge-success { background: rgba(16,185,129,0.15); color: #34d399; border-color: rgba(16,185,129,0.3); }
.badge-warning { background: rgba(245,158,11,0.15); color: #fbbf24; border-color: rgba(245,158,11,0.3); }
.badge-danger  { background: rgba(239,68,68,0.15);  color: #f87171; border-color: rgba(239,68,68,0.3);  }
.badge-info    { background: rgba(59,130,246,0.15); color: #60a5fa; border-color: rgba(59,130,246,0.3); }
.badge-gold    { background: rgba(200,150,42,0.15); color: var(--gold-light); border-color: rgba(200,150,42,0.35); }
.badge-neutral { background: rgba(100,116,139,0.15); color: #94a3b8; border-color: rgba(100,116,139,0.3); }

/* ── Tables ── */
div[data-testid="stDataFrame"] {
  border-radius: 14px !important;
  overflow: hidden !important;
  border: 1px solid rgba(255,255,255,0.08) !important;
}
div[data-testid="stDataFrame"] > div {
  background: #0d1b35 !important;
}
.table-container {
  background: #0d1b35;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  overflow: hidden;
  margin: 12px 0;
}

/* ── Buttons ── */
.stButton > button {
  background: linear-gradient(135deg, var(--gold) 0%, #e8ac30 100%) !important;
  color: #0a1628 !important;
  border: none !important;
  border-radius: 10px !important;
  font-weight: 800 !important;
  font-size: 13px !important;
  padding: 10px 20px !important;
  letter-spacing: 0.3px !important;
  box-shadow: 0 4px 16px rgba(200,150,42,0.3) !important;
  transition: all 0.2s !important;
  text-transform: none !important;
}
.stButton > button:hover {
  transform: translateY(-1px) !important;
  box-shadow: 0 8px 24px rgba(200,150,42,0.45) !important;
  background: linear-gradient(135deg, #e8ac30 0%, var(--gold-light) 100%) !important;
}
.stButton > button:active { transform: translateY(0) !important; }

/* Secondary button style via extra class */
.btn-secondary .stButton > button {
  background: rgba(255,255,255,0.07) !important;
  color: #c8d8f0 !important;
  border: 1px solid rgba(255,255,255,0.15) !important;
  box-shadow: none !important;
}
.btn-danger .stButton > button {
  background: linear-gradient(135deg, #dc2626, #b91c1c) !important;
  color: white !important;
  box-shadow: 0 4px 16px rgba(220,38,38,0.35) !important;
}
.btn-success .stButton > button {
  background: linear-gradient(135deg, #059669, #047857) !important;
  color: white !important;
  box-shadow: 0 4px 16px rgba(5,150,105,0.35) !important;
}

/* Download button */
.stDownloadButton > button {
  background: rgba(59,130,246,0.15) !important;
  color: #60a5fa !important;
  border: 1px solid rgba(59,130,246,0.35) !important;
  border-radius: 10px !important;
  font-weight: 700 !important;
}

/* ── Inputs ── */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stSelectbox > div > div > div,
.stDateInput > div > div > input {
  background: rgba(255,255,255,0.05) !important;
  border: 1px solid rgba(255,255,255,0.12) !important;
  border-radius: 10px !important;
  color: #e0eaf8 !important;
  font-size: 14px !important;
}
.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus {
  border-color: rgba(200,150,42,0.6) !important;
  box-shadow: 0 0 0 3px rgba(200,150,42,0.1) !important;
}
label { color: #7a94b8 !important; font-size: 12px !important; font-weight: 600 !important; text-transform: uppercase !important; letter-spacing: 0.5px !important; }

/* ── Alerts ── */
.stAlert > div {
  border-radius: 12px !important;
  border: none !important;
}
div[data-testid="stAlert"][data-baseweb="notification"] {
  background: rgba(59,130,246,0.1) !important;
  border: 1px solid rgba(59,130,246,0.25) !important;
  border-radius: 12px !important;
}

/* ── Expander ── */
.streamlit-expanderHeader {
  background: rgba(255,255,255,0.04) !important;
  border-radius: 10px !important;
  color: #c8d8f0 !important;
  font-weight: 600 !important;
}

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] {
  background: rgba(255,255,255,0.04) !important;
  border-radius: 12px !important;
  padding: 4px !important;
  gap: 2px !important;
  border: 1px solid rgba(255,255,255,0.08) !important;
}
.stTabs [data-baseweb="tab"] {
  border-radius: 8px !important;
  color: #7a94b8 !important;
  font-weight: 600 !important;
  font-size: 13px !important;
  padding: 8px 16px !important;
}
.stTabs [aria-selected="true"] {
  background: linear-gradient(135deg, var(--gold), #e8ac30) !important;
  color: #0a1628 !important;
}

/* ── Progress ── */
.stProgress > div > div > div > div {
  background: linear-gradient(90deg, var(--gold), var(--gold-light)) !important;
}

/* ── Spinner ── */
.stSpinner > div { border-top-color: var(--gold) !important; }

/* ── Divider ── */
hr { border-color: rgba(255,255,255,0.08) !important; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: rgba(255,255,255,0.03); }
::-webkit-scrollbar-thumb { background: rgba(200,150,42,0.3); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: rgba(200,150,42,0.5); }

/* ── Agent Cards ── */
.agent-card {
  background: linear-gradient(135deg, #0d1b35 0%, #111e3a 100%);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 16px 18px;
  margin: 8px 0;
  border-left: 4px solid #3b82f6;
  position: relative;
  overflow: hidden;
  transition: transform 0.15s;
}
.agent-card:hover { transform: translateX(2px); }
.agent-card.passed  { border-left-color: #10b981; }
.agent-card.failed  { border-left-color: #ef4444; background: linear-gradient(135deg, #180d0d, #1e1010); }
.agent-card.blocked { border-left-color: #7f1d1d; background: linear-gradient(135deg, #1a0808, #200a0a); }
.agent-card.warning { border-left-color: #f59e0b; }
.agent-title { font-size: 14px; font-weight: 800; color: #e2eaf8; margin-bottom: 6px; }
.agent-meta  { font-size: 11px; color: #556080; }
.agent-finding { font-size: 13px; color: #b0c4de; margin-top: 6px; line-height: 1.5; }
.agent-number {
  position: absolute; top: 12px; right: 16px;
  font-size: 32px; font-weight: 900;
  color: rgba(255,255,255,0.04);
}

/* ── Timeline ── */
.timeline { border-left: 2px solid rgba(200,150,42,0.3); padding-left: 20px; margin-left: 8px; }
.timeline-item {
  background: linear-gradient(135deg, #0d1b35, #111e3a);
  border: 1px solid rgba(255,255,255,0.07);
  border-radius: 12px;
  padding: 12px 16px;
  margin: 10px 0;
  position: relative;
}
.timeline-item::before {
  content: '';
  position: absolute;
  left: -26px; top: 16px;
  width: 10px; height: 10px;
  border-radius: 50%;
  background: var(--gold);
  border: 2px solid #0a1628;
}
.timeline-step { font-weight: 800; color: #c8d8f0; font-size: 14px; }
.timeline-detail { font-size: 12px; color: #556080; margin-top: 4px; }

/* ── Workflow Decision Card ── */
.decision-card {
  background: linear-gradient(135deg, #0d1b35, #121f3a);
  border: 1px solid rgba(200,150,42,0.25);
  border-radius: 16px;
  padding: 22px 24px;
  margin: 12px 0;
}
.decision-card.reject {
  background: linear-gradient(135deg, #1a0808, #200d0d);
  border-color: rgba(239,68,68,0.3);
}
.decision-card.review {
  background: linear-gradient(135deg, #1a1208, #1f1608);
  border-color: rgba(245,158,11,0.3);
}
.decision-title { font-size: 17px; font-weight: 800; color: #e2eaf8; margin-bottom: 14px; }
.decision-field { font-size: 13px; color: #8a9ab8; margin: 6px 0; }
.decision-field strong { color: #c8d8f0; }

/* ── Risk Score Ring (CSS only) ── */
.risk-score-display {
  text-align: center;
  padding: 20px;
}
.risk-score-number { font-size: 64px; font-weight: 900; line-height: 1; }
.risk-score-label { font-size: 13px; color: #7a94b8; margin-top: 6px; text-transform: uppercase; letter-spacing: 0.8px; }
.risk-low    { color: #10b981; }
.risk-medium { color: #f59e0b; }
.risk-high   { color: #f97316; }
.risk-critical { color: #ef4444; }

/* ── Landing Page ── */
.landing-hero {
  text-align: center;
  padding: 60px 20px 40px;
}
.landing-logo {
  width: 80px; height: 80px;
  background: linear-gradient(135deg, var(--gold), #e8ac30);
  border-radius: 24px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 40px;
  margin-bottom: 20px;
  box-shadow: 0 12px 40px rgba(200,150,42,0.4);
}
.landing-title {
  font-size: 52px;
  font-weight: 900;
  color: #ffffff;
  letter-spacing: -2px;
  line-height: 1.1;
}
.landing-title span { color: var(--gold-light); }
.landing-subtitle {
  font-size: 18px;
  color: #7a94b8;
  max-width: 600px;
  margin: 16px auto 0;
  line-height: 1.6;
  font-weight: 400;
}
.landing-strip {
  width: 80px; height: 4px;
  background: linear-gradient(90deg, var(--gold), var(--gold-light));
  border-radius: 2px;
  margin: 24px auto;
}
.portal-card {
  background: linear-gradient(135deg, #0d1b35, #111e3a);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 22px;
  padding: 28px;
  height: 100%;
  transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s;
  cursor: default;
  position: relative;
  overflow: hidden;
}
.portal-card::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--gold), #e8ac30);
}
.portal-card:hover {
  transform: translateY(-4px);
  border-color: rgba(200,150,42,0.35);
  box-shadow: 0 20px 50px rgba(0,0,0,0.5), 0 0 30px rgba(200,150,42,0.1);
}
.portal-card-icon { font-size: 40px; margin-bottom: 14px; }
.portal-card-title { font-size: 20px; font-weight: 800; color: #ffffff; margin-bottom: 10px; }
.portal-card-desc { font-size: 14px; color: #7a94b8; line-height: 1.65; }
.portal-card-tag {
  display: inline-block;
  background: rgba(200,150,42,0.1);
  color: var(--gold-light);
  border: 1px solid rgba(200,150,42,0.25);
  border-radius: 6px;
  padding: 3px 8px;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-top: 14px;
}
.trust-badges {
  display: flex;
  justify-content: center;
  gap: 24px;
  flex-wrap: wrap;
  margin-top: 40px;
}
.trust-badge {
  display: flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 10px;
  padding: 8px 16px;
  font-size: 12px;
  color: #7a94b8;
  font-weight: 500;
}
.trust-badge-icon { font-size: 16px; }

/* ── Login ── */
.login-card {
  background: linear-gradient(135deg, #0d1b35, #111e3a);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 20px;
  padding: 32px;
}
.cred-card {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.07);
  border-radius: 14px;
  padding: 16px;
  margin-bottom: 12px;
}
.cred-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 6px 0;
  border-bottom: 1px solid rgba(255,255,255,0.05);
}
.cred-row:last-child { border-bottom: none; }
.cred-user { font-size: 13px; font-weight: 700; color: #e0eaf8; }
.cred-role { font-size: 11px; color: var(--gold); background: rgba(200,150,42,0.1); padding: 2px 8px; border-radius: 99px; font-weight: 600; }

/* ── Doc Cards ── */
.doc-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.doc-card {
  background: linear-gradient(135deg, #0d1b35, #111e3a);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 14px;
  overflow: hidden;
}
.doc-card-title { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #7a94b8; margin-bottom: 10px; }

/* ── Customer KYC progress bar ── */
.kyc-progress-wrap { margin: 20px 0; }
.kyc-steps { display: flex; gap: 0; }
.kyc-step {
  flex: 1;
  text-align: center;
  position: relative;
}
.kyc-step-dot {
  width: 32px; height: 32px;
  border-radius: 50%;
  background: rgba(255,255,255,0.06);
  border: 2px solid rgba(255,255,255,0.12);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 800;
  color: #556080;
  position: relative;
  z-index: 2;
}
.kyc-step-dot.active { background: var(--gold); border-color: var(--gold-light); color: #0a1628; box-shadow: 0 0 16px rgba(200,150,42,0.4); }
.kyc-step-dot.done { background: #10b981; border-color: #34d399; color: white; }
.kyc-step-label { font-size: 10px; color: #556080; margin-top: 6px; font-weight: 600; }
.kyc-step-label.active { color: var(--gold-light); }
.kyc-step-label.done { color: #34d399; }
.kyc-step-line {
  position: absolute;
  top: 15px; left: 50%; right: -50%;
  height: 2px;
  background: rgba(255,255,255,0.08);
  z-index: 1;
}
.kyc-step-line.done { background: linear-gradient(90deg, #10b981, rgba(16,185,129,0.3)); }

/* ── Notification badge ── */
.notif-dot {
  display: inline-block;
  width: 8px; height: 8px;
  border-radius: 50%;
  background: var(--danger);
  margin-left: 6px;
  animation: pulse 1.5s infinite;
}
@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.6; transform: scale(0.8); }
}

/* ── Insight chips row ── */
.insight-row { display: flex; flex-wrap: wrap; gap: 8px; margin: 10px 0; }
.insight-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 5px 10px;
  font-size: 12px;
  color: #a0b4d0;
  font-weight: 500;
}

/* ── Reason box ── */
.reason-box {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  border-left: 3px solid var(--gold);
  border-radius: 12px;
  padding: 16px 18px;
  font-size: 13px;
  color: #a0b4d0;
  line-height: 1.7;
  white-space: pre-wrap;
}

/* ── Charts ── */
div[data-testid="stBarChart"] svg,
div[data-testid="stLineChart"] svg { filter: brightness(1.1); }

/* ── Sidebar nav radio ── */
section[data-testid="stSidebar"] .stRadio > div > label {
  background: rgba(255,255,255,0.03) !important;
  border: 1px solid rgba(255,255,255,0.06) !important;
  border-radius: 8px !important;
  padding: 8px 12px !important;
  margin: 2px 0 !important;
  color: #8a9ab8 !important;
  font-size: 13px !important;
  font-weight: 500 !important;
  transition: all 0.15s !important;
  cursor: pointer !important;
}
section[data-testid="stSidebar"] .stRadio > div > label:hover {
  background: rgba(200,150,42,0.08) !important;
  border-color: rgba(200,150,42,0.2) !important;
  color: #e0d098 !important;
}
section[data-testid="stSidebar"] .stRadio > div [aria-checked="true"] + label,
section[data-testid="stSidebar"] .stRadio [data-checked="true"] label {
  background: rgba(200,150,42,0.12) !important;
  border-color: rgba(200,150,42,0.35) !important;
  color: var(--gold-light) !important;
}

/* ── Status indicator row ── */
.status-row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin: 10px 0; }

/* ── Live indicator ── */
.live-dot { display: inline-block; width: 8px; height: 8px; background: #10b981; border-radius: 50%; animation: pulse 2s infinite; margin-right: 6px; }

/* ── Evidence table ── */
.evidence-row { border-bottom: 1px solid rgba(255,255,255,0.06); padding: 10px 0; }
.evidence-row:last-child { border-bottom: none; }

/* ── Compact info text ── */
p, .stMarkdown p { color: #8a9ab8; font-size: 14px; line-height: 1.65; }
h1, h2, h3, h4 { color: #e2eaf8 !important; }
h2 { font-size: 22px !important; font-weight: 800 !important; letter-spacing: -0.3px !important; }
h3 { font-size: 17px !important; font-weight: 700 !important; }
h4 { font-size: 14px !important; font-weight: 700 !important; }

/* ── Form container ── */
.form-card {
  background: linear-gradient(135deg, #0d1b35, #111e3a);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 18px;
  padding: 24px;
  margin-bottom: 16px;
}

/* ── Skeleton loader ── */
.skeleton {
  background: linear-gradient(90deg, rgba(255,255,255,0.04) 25%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.04) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 8px;
  height: 20px;
}
@keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
</style>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════
#  SESSION STATE
# ═══════════════════════════════════════════════════════════════════
def ss_default(key, value):
    if key not in st.session_state:
        st.session_state[key] = value

ss_default("portal_view", "Landing")
ss_default("logged_in", False)
ss_default("username", "")
ss_default("user_role", "")
ss_default("customer_id", "")
ss_default("current_case_id", "")
ss_default("orchestrator_result", None)
ss_default("reasoning_mode", "Gemini Assisted" if os.getenv("GOOGLE_API_KEY") else "Rule-based Fallback")
ss_default("last_notification", {})
ss_default("active_tab", 0)


# ═══════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════
def logout():
    for key in ["logged_in", "username", "user_role", "customer_id", "current_case_id", "orchestrator_result", "last_notification"]:
        st.session_state[key] = {} if key == "last_notification" else "" if key != "logged_in" else False
    st.session_state["portal_view"] = "Landing"
    st.rerun()


def badge(text, kind="neutral"):
    """Render a colored status badge."""
    if kind == "auto":
        key = str(text).lower().replace(" ", "-").replace("/", "-")
        if any(x in key for x in ["critical", "failed", "rejected", "blocked", "high-risk"]): kind = "danger"
        elif any(x in key for x in ["high", "escalated"]): kind = "warning"
        elif any(x in key for x in ["medium", "warning", "manual", "pending", "review"]): kind = "warning"
        elif any(x in key for x in ["low", "approved", "passed", "allowed", "success"]): kind = "success"
        elif any(x in key for x in ["info", "progress", "uploaded", "open"]): kind = "info"
        else: kind = "neutral"
    return f'<span class="badge badge-{kind}">{text}</span>'


def kpi(title, value, caption="", kind="", icon=""):
    cls = f"kpi-card {kind}"
    st.markdown(
        f'<div class="{cls}">'
        f'{"<div class=kpi-icon>" + icon + "</div>" if icon else ""}'
        f'<div class="kpi-value">{value}</div>'
        f'<div class="kpi-label">{title}</div>'
        f'{"<div class=kpi-caption>" + caption + "</div>" if caption else ""}'
        f'</div>',
        unsafe_allow_html=True,
    )


def section_card(title, content_html, icon=""):
    ico = f"{icon}&ensp;" if icon else ""
    st.markdown(
        f'<div class="section-card"><div class="section-card-title">{ico}{title}</div>{content_html}</div>',
        unsafe_allow_html=True,
    )


def page_header(title, subtitle="", icon=""):
    st.markdown(
        f'<div class="page-header">'
        f'{"<div class=page-icon>" + icon + "</div>" if icon else ""}'
        f'<div><div class="page-title">{title}</div>'
        f'{"<div class=page-subtitle>" + subtitle + "</div>" if subtitle else ""}'
        f'</div></div>',
        unsafe_allow_html=True,
    )


def masked_case_df(df, limit=200):
    out = df.copy().head(limit)
    if "full_name" in out.columns:
        out["full_name"] = out["full_name"].astype(str).str.split().str[0] + " *****"
    if "email" in out.columns:
        out["email"] = out["email"].astype(str).apply(lambda x: x[:2] + "*****@" + x.split("@")[-1] if "@" in x else "*****")
    if "mobile" in out.columns:
        out["mobile"] = out["mobile"].astype(str).apply(lambda x: "XXXXXX" + x[-4:])
    return out


def get_customer_by_id(customer_id):
    df = load_customers()
    row = df[df["customer_id"] == customer_id]
    return row.iloc[0].to_dict() if not row.empty else {}


def get_case_options():
    df = load_customers()
    demo_ids = ["CUST00001","CUST00002","CUST02500","CUST02501","CUST02502","CUST04999","CUST04998","CUST05000","CUST05001","CUST05002"]
    demo = df[df["customer_id"].isin(demo_ids)].copy()
    rest = df[~df["customer_id"].isin(demo_ids)].head(80)
    show = pd.concat([demo, rest], ignore_index=True)
    show["label"] = show.apply(lambda r: f"{r['case_id']} | {r['customer_id']} | {r['synthetic_risk_profile']} | {r['case_status']}", axis=1)
    return dict(zip(show["label"], show["case_id"])), show


def image_path(customer_id, file_name):
    return DIRS["uploads"] / customer_id / file_name


def show_img(path, caption=None):
    if Path(path).exists():
        st.image(Image.open(path), caption=caption, use_container_width=True)
    else:
        st.markdown(
            f'<div style="background:rgba(255,255,255,0.03);border:1px dashed rgba(255,255,255,0.1);border-radius:10px;padding:30px;text-align:center;color:#556080;font-size:12px;">📄 {Path(path).name}</div>',
            unsafe_allow_html=True,
        )


def document_grid(customer_id, docs_df=None):
    docs = [
        ("👤", "Customer Photo", "customer_photo.png"),
        ("🤳", "Selfie", "selfie.png"),
        ("📋", "PAN Card", "pan_card.png"),
        ("🪪", "Aadhaar", "aadhaar_card.png"),
        ("🏦", "Bank Statement", "bank_statement.png"),
        ("💼", "Salary Slip", "salary_slip.png"),
        ("🏠", "Address Proof", "address_proof.png"),
    ]
    cols = st.columns(3)
    for i, (emoji, label, fname) in enumerate(docs):
        with cols[i % 3]:
            st.markdown(f'<div class="doc-card">', unsafe_allow_html=True)
            st.markdown(f'<div class="doc-card-title">{emoji}&ensp;{label}</div>', unsafe_allow_html=True)
            show_img(image_path(customer_id, fname))
            if docs_df is not None and label not in ["Customer Photo", "Selfie"]:
                rec = docs_df[docs_df["document_type"].str.contains(label.replace("Card","").strip(), case=False, na=False)]
                if not rec.empty:
                    r = rec.iloc[0]
                    conf = float(r["confidence_score"]) * 100
                    st.markdown(
                        f"{badge(r['document_status'], 'auto')}&nbsp;{badge(r['quality_status'], 'auto')}<br>"
                        f"<span style='font-size:11px;color:#556080'>Confidence: <b style='color:#a0b4d0'>{conf:.0f}%</b> &nbsp;|&nbsp; Tamper: <b style='color:#a0b4d0'>{r['tampering_indicator']}</b></span>",
                        unsafe_allow_html=True,
                    )
            st.markdown('</div>', unsafe_allow_html=True)


def agent_kind(status):
    s = str(status).lower()
    if "fail" in s: return "failed"
    if "block" in s: return "blocked"
    if "warn" in s: return "warning"
    return "passed"


def show_agent_cards(findings):
    for idx, f in enumerate(findings, start=1):
        kind = agent_kind(f.get("status", ""))
        conf = float(f.get("confidence", 0)) * 100
        impact = f.get("risk_impact", 0)
        b_status = badge(f.get("status", "Completed"), "auto")
        st.markdown(
            f"""<div class="agent-card {kind}">
              <div class="agent-number">{idx:02d}</div>
              <div class="agent-title">{f.get('agent_name','Agent')}</div>
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">{b_status}
                <span class="agent-meta">Confidence: <b>{conf:.0f}%</b> &nbsp;|&nbsp; Risk Impact: <b>+{impact}</b> &nbsp;|&nbsp; {f.get('timestamp','')}</span>
              </div>
              <div class="agent-finding"><span style="color:#7a94b8;font-size:11px;text-transform:uppercase;letter-spacing:0.5px">Finding</span><br>{f.get('finding','')}</div>
              <div class="agent-finding" style="margin-top:6px"><span style="color:#7a94b8;font-size:11px;text-transform:uppercase;letter-spacing:0.5px">Evidence</span><br>{f.get('evidence','')}</div>
            </div>""",
            unsafe_allow_html=True,
        )


def show_timeline(res):
    timeline = [
        ("🔐", "Secure Context Loaded", f"Masked context prepared — {res['case_id']} / {res['customer_id']}"),
        ("📄", "Documents Validated", "Document Intelligence Agent: mandatory docs, quality, confidence & tamper indicators"),
        ("🪞", "Identity Verified", "Selfie liveness check, face match & demographic comparison"),
        ("📜", "Compliance Policy Applied", "Local KYC policy + JSON rules via Compliance RAG Agent"),
        ("🔍", "AML / Sanctions / PEP Screened", "Watchlists, adverse media and fraud signal review"),
        ("📊", "Risk Score Calculated", f"Final score: {res['risk_result']['risk_score']}/100 — {res['risk_result']['risk_level']}"),
        ("🛡️", "Guardrails Applied", f"Guardrail status: {res['guardrail_result']['status']}"),
        ("👤", "Human Review Evaluated", res['guardrail_result']['required_human_action']),
        ("🗂️", "Audit Evidence Prepared", "Trace JSON, decision log, notification draft and evidence pack created"),
    ]
    st.markdown('<div class="timeline">', unsafe_allow_html=True)
    for i, (emoji, title, detail) in enumerate(timeline, 1):
        st.markdown(
            f'<div class="timeline-item"><span class="timeline-step">{emoji}&ensp;Step {i}: {title}</span>'
            f'<div class="timeline-detail">{detail}</div></div>',
            unsafe_allow_html=True,
        )
    st.markdown('</div>', unsafe_allow_html=True)


def show_workflow_decision(res):
    wf = res.get("decision_workflow", {}) if res else {}
    if not wf:
        return
    kind = "reject" if wf.get("auto_reject") else "review" if wf.get("manual_review") else ""
    b_discrepancy = badge("Discrepancy: " + str(wf.get("discrepancy_level", "")), "auto")
    b_action = badge(str(wf.get("system_action", "")), "auto")
    b_status = badge(str(wf.get("final_case_status", "")), "auto")
    st.markdown(
        f"""<div class="decision-card {kind}">
          <div class="decision-title">⚖️ AI Agent Workflow Decision</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
            {b_discrepancy}&nbsp;{b_action}&nbsp;{b_status}
          </div>
          <div class="decision-field"><strong>Decision Reason:</strong> {wf.get('decision_reason','')}</div>
          <div class="decision-field"><strong>Required Staff Action:</strong> {wf.get('staff_required_action','')}</div>
          <div class="decision-field"><strong>Customer Message:</strong> {wf.get('customer_message','')}</div>
        </div>""",
        unsafe_allow_html=True,
    )
    triggers = wf.get("high_discrepancy_triggers") or wf.get("manual_review_triggers") or wf.get("all_discrepancies") or []
    if triggers:
        st.markdown('<div class="section-card-title">⚠️ Discrepancies Detected</div>', unsafe_allow_html=True)
        for t in triggers[:10]:
            st.markdown(f"&nbsp;&nbsp;`→` {t}")
    st.info("📧 Email drafts are generated for both staff and customer. No outbound email is sent from this environment.")


def run_agents_for_case(case_id):
    key = os.getenv("GOOGLE_API_KEY")
    st.session_state["reasoning_mode"] = "Gemini Assisted" if key else "Rule-based Fallback"
    res = run_master_orchestrator(case_id, key)
    if res and res.get("success"):
        wf = res.get("decision_workflow", {})
        final_status = wf.get("final_case_status")
        if final_status:
            update_case_status(case_id, final_status, "TrustShield Orchestrator", wf.get("decision_reason", "Agentic KYC decision workflow applied"))
    return res


def get_active_result(case_id=None):
    res = st.session_state.get("orchestrator_result")
    if res and (case_id is None or res.get("case_id") == case_id):
        return res
    return None


def save_notification_file(case_id, draft_type, draft):
    notif_dir = DIRS["notifications"] / case_id
    notif_dir.mkdir(parents=True, exist_ok=True)
    path = notif_dir / f"{draft_type}.txt"
    text = f"Subject: {draft.get('subject','')}\n\n{draft.get('body','')}"
    path.write_text(text, encoding="utf-8")
    return path, text


def risk_color_class(level):
    l = str(level).lower()
    if "critical" in l: return "risk-critical"
    if "high" in l: return "risk-high"
    if "medium" in l: return "risk-medium"
    return "risk-low"


# ═══════════════════════════════════════════════════════════════════
#  LANDING PAGE
# ═══════════════════════════════════════════════════════════════════
if st.session_state["portal_view"] == "Landing":
    st.markdown("""
    <div class="landing-hero">
      <div class="landing-logo">🛡️</div>
      <div class="landing-title">TrustShield <span>AI</span></div>
      <div class="landing-subtitle">Enterprise-grade Agentic KYC, AML Risk & Compliance Intelligence Platform powered by multi-agent AI</div>
      <div class="landing-strip"></div>
    </div>
    """, unsafe_allow_html=True)

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.markdown("""
        <div class="portal-card">
          <div class="portal-card-icon">🏦</div>
          <div class="portal-card-title">Staff & Admin Portal</div>
          <div class="portal-card-desc">
            Run full agentic KYC review pipelines with real-time multi-agent coordination. Includes AML screening,
            PEP/sanctions checks, document intelligence, risk scoring, guardrails, human review workflows,
            email notification drafts and tamper-proof audit evidence packs.
          </div>
          <div><span class="portal-card-tag">Compliance</span> <span class="portal-card-tag">Fraud</span> <span class="portal-card-tag">Operations</span> <span class="portal-card-tag">Audit</span></div>
        </div>
        """, unsafe_allow_html=True)
        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        if st.button("Enter Staff / Admin Portal →", use_container_width=True):
            st.session_state["portal_view"] = "Staff"; st.rerun()

    with c2:
        st.markdown("""
        <div class="portal-card">
          <div class="portal-card-icon">👤</div>
          <div class="portal-card-title">Customer Self-Service Portal</div>
          <div class="portal-card-desc">
            Secure, privacy-first customer view. Track KYC application status, view document verification results,
            selfie and liveness checks, upload replacement documents, receive real-time notifications
            and view final onboarding decision — with full PII masking.
          </div>
          <div><span class="portal-card-tag">Privacy-First</span> <span class="portal-card-tag">Self-Service</span> <span class="portal-card-tag">GDPR Ready</span></div>
        </div>
        """, unsafe_allow_html=True)
        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        if st.button("Enter Customer Portal →", use_container_width=True):
            st.session_state["portal_view"] = "Customer"; st.rerun()

    st.markdown("""
    <div class="trust-badges">
      <div class="trust-badge"><span class="trust-badge-icon">🤖</span> 9-Agent AI Pipeline</div>
      <div class="trust-badge"><span class="trust-badge-icon">🔒</span> End-to-End PII Masking</div>
      <div class="trust-badge"><span class="trust-badge-icon">📊</span> Real-Time Risk Scoring</div>
      <div class="trust-badge"><span class="trust-badge-icon">🛡️</span> Guardrail Enforcement</div>
      <div class="trust-badge"><span class="trust-badge-icon">📋</span> Audit Evidence Packs</div>
      <div class="trust-badge"><span class="trust-badge-icon">☁️</span> AMD Cloud Ready</div>
    </div>
    """, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════
#  LOGIN
# ═══════════════════════════════════════════════════════════════════
elif not st.session_state["logged_in"]:
    # Sidebar
    st.sidebar.markdown("""
    <div class="sidebar-brand">
      <div class="sidebar-brand-title">🛡️ TrustShield AI</div>
      <div class="sidebar-brand-sub">KYC Intelligence Platform</div>
    </div>
    """, unsafe_allow_html=True)
    if st.sidebar.button("← Back to Home"):
        st.session_state["portal_view"] = "Landing"; st.rerun()

    portal = st.session_state["portal_view"]
    page_header(
        f"{'Staff & Admin' if portal == 'Staff' else 'Customer'} Login",
        "Secure role-based authentication",
        "🔐"
    )

    left, right = st.columns([1, 1.2], gap="large")
    with left:
        st.markdown('<div class="login-card">', unsafe_allow_html=True)
        st.markdown("<h3 style='margin-top:0'>Sign In</h3>", unsafe_allow_html=True)
        username = st.text_input("User ID", placeholder="Enter User ID")
        password = st.text_input("Password", type="password", placeholder="Enter password")
        st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
        if portal == "Staff":
            if st.button("Login to Staff Portal", use_container_width=True):
                if username in STAFF_CREDENTIALS and STAFF_CREDENTIALS[username]["password"] == password:
                    st.session_state.update({"logged_in": True, "username": username,
                                             "user_role": STAFF_CREDENTIALS[username]["role"], "customer_id": ""})
                    st.rerun()
                else:
                    st.error("❌ Invalid credentials. Please try again.")
        else:
            if st.button("Login to Customer Portal", use_container_width=True):
                # Existing customer credentials
                if username in CUSTOMER_CREDENTIALS and CUSTOMER_CREDENTIALS[username]["password"] == password:
                    st.session_state.update({"logged_in": True, "username": username,
                                             "user_role": "Customer",
                                             "customer_id": CUSTOMER_CREDENTIALS[username]["customer_id"]})
                    st.rerun()
                else:
                    # Fresh customers created through registration can sign in with their generated user ID
                    try:
                        cust_df_login = load_customers()
                        match = cust_df_login[cust_df_login.get("login_username", "") == username]
                        if (not match.empty) and password == "Trust@123":
                            st.session_state.update({"logged_in": True, "username": username,
                                                     "user_role": "Customer",
                                                     "customer_id": match.iloc[0]["customer_id"]})
                            st.rerun()
                        else:
                            st.error("❌ Invalid credentials. Please try again.")
                    except Exception:
                        st.error("❌ Invalid credentials. Please try again.")
        st.markdown('</div>', unsafe_allow_html=True)

    with right:
        if portal == "Staff":
            st.markdown('<div class="cred-card">', unsafe_allow_html=True)
            st.markdown('<div class="section-card-title">Staff Access</div>', unsafe_allow_html=True)
            st.markdown(
                '<div style="color:#8fa8c8;font-size:14px;line-height:1.7">'
                'Authorized KYC staff can securely review queues, validate cases, perform human review, '
                'generate notification drafts, and create audit evidence packs.'
                '</div>',
                unsafe_allow_html=True,
            )
            st.markdown('</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="cred-card">', unsafe_allow_html=True)
            st.markdown('<div class="section-card-title">Existing Customer Status Check</div>', unsafe_allow_html=True)
            st.markdown(
                '<div style="color:#8fa8c8;font-size:14px;line-height:1.7">'
                'Existing customers can sign in to view KYC status, submitted document checklist, '
                'acknowledgements, notifications, and final status updates.'
                '</div>',
                unsafe_allow_html=True,
            )
            st.markdown('</div>', unsafe_allow_html=True)

            # Fresh customer self-registration
            st.markdown('<div class="cred-card" style="margin-top:16px">', unsafe_allow_html=True)
            st.markdown('<div class="section-card-title">Start Fresh Customer Registration</div>', unsafe_allow_html=True)
            with st.form("fresh_customer_registration_form"):
                fr_name = st.text_input("Full Name", "Fresh Customer")
                fr_mobile = st.text_input("Mobile", "9876543210")
                fr_email = st.text_input("Email", "customer@example.com")
                fr_city = st.text_input("City", "Chennai")
                fr_state = st.text_input("State", "Tamil Nadu")
                fr_submit = st.form_submit_button("Register New Customer & Start KYC", use_container_width=True)
            if fr_submit:
                df_new = load_customers()
                nums = pd.to_numeric(df_new["customer_id"].astype(str).str.extract(r"(\d+)")[0], errors="coerce").fillna(0).astype(int)
                next_num = int(nums.max()) + 1
                new_cust_id = f"CUST{next_num:05d}"
                new_case_id = f"CASE{next_num:05d}"
                new_login = f"fresh.customer.{next_num:05d}"
                new_row = {
                    "case_id": new_case_id, "customer_id": new_cust_id, "login_username": new_login,
                    "full_name": fr_name, "dob": "1995-01-01", "gender": "Prefer not to say",
                    "email": fr_email, "mobile": fr_mobile, "address": f"Residential Address, {fr_city}",
                    "city": fr_city, "state": fr_state, "country": "India", "nationality": "Indian",
                    "occupation": "Salaried", "income_range": "5L-10L", "customer_type": "Retail",
                    "application_channel": "Customer Portal", "application_date": datetime.now().strftime("%Y-%m-%d"),
                    "case_status": "Document Pending", "assigned_queue": "Document Upload Queue",
                    "sla_hours": 24, "synthetic_risk_profile": "Medium", "profile_image_path": ""
                }
                save_customers(pd.concat([df_new, pd.DataFrame([new_row])], ignore_index=True))

                # Create placeholder mandatory document records so the fresh customer can upload immediately
                all_docs_new = load_kyc_documents()
                required_docs_new = ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"]
                doc_rows = []
                for dt in required_docs_new:
                    doc_rows.append({
                        "case_id": new_case_id, "customer_id": new_cust_id, "document_type": dt,
                        "document_name": f"{dt} - Pending Upload", "id_number": "",
                        "document_name_value": fr_name, "document_dob_value": "1995-01-01",
                        "document_address_value": f"Residential Address, {fr_city}", "document_age_days": 0,
                        "confidence_score": 0.0, "file_type": "Pending", "quality_status": "Pending",
                        "document_status": "Missing", "tampering_indicator": "Not Checked",
                        "issue_date": "", "expiry_date": ""
                    })
                save_kyc_documents(pd.concat([all_docs_new, pd.DataFrame(doc_rows)], ignore_index=True))

                # Placeholder selfie verification row
                try:
                    selfie_all = load_selfie_verification()
                    selfie_row = {
                        "case_id": new_case_id, "customer_id": new_cust_id, "selfie_available": False,
                        "selfie_file_path": "", "selfie_quality": "Pending", "selfie_match_score": 0.0,
                        "liveness_check": "Pending", "face_match_status": "Pending"
                    }
                    save_selfie_verification(pd.concat([selfie_all, pd.DataFrame([selfie_row])], ignore_index=True))
                except Exception:
                    pass

                update_case_status(new_case_id, "Document Pending", "Customer Portal", "Fresh customer self-registration completed")
                st.success(f"✅ Registration completed. Customer ID: {new_cust_id} | Case ID: {new_case_id}")
                st.info(f"Registration completed. You are now signed in to continue your KYC application.")
                st.session_state.update({"logged_in": True, "username": new_login, "user_role": "Customer", "customer_id": new_cust_id})
                st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════
#  CUSTOMER PORTAL
# ═══════════════════════════════════════════════════════════════════
elif st.session_state["portal_view"] == "Customer":
    cust_id = st.session_state["customer_id"]
    cust = get_customer_by_id(cust_id)
    if not cust:
        st.error("Customer profile not found"); st.stop()
    masked = mask_customer_dict(cust)
    docs = load_kyc_documents()
    cust_docs = docs[docs["customer_id"] == cust_id]
    selfie_df = load_selfie_verification()
    selfie = selfie_df[selfie_df["customer_id"] == cust_id]

    # Sidebar
    st.sidebar.markdown("""
    <div class="sidebar-brand">
      <div class="sidebar-brand-title">🛡️ TrustShield AI</div>
      <div class="sidebar-brand-sub">Customer Portal</div>
    </div>
    """, unsafe_allow_html=True)
    st.sidebar.markdown(
        f'<div class="sidebar-user-badge">'
        f'<div class="sidebar-user-name">👤 Customer Portal</div>'
        f'<div class="sidebar-user-role">Secure KYC Status Access</div>'
        f'<div style="margin-top:6px">{badge(cust.get("case_status","Pending"), "auto")}</div>'
        f'</div>',
        unsafe_allow_html=True,
    )
    cust_page = st.sidebar.radio("Navigation", [
        "Dashboard", "My Profile", "Photo & Selfie", "KYC Status",
        "Document Checklist", "Upload Document", "Request Status", "Notifications", "Final Decision"
    ])
    if st.sidebar.button("Logout", use_container_width=True):
        logout()

    # Page header
    risk_level = cust.get("synthetic_risk_profile", "")
    page_header(f"KYC Application — {cust_id}", f"Case: {cust.get('case_id','')} &nbsp;|&nbsp; {cust.get('application_channel','')}", "👤")

    if cust_page == "Dashboard":
        c1, c2, c3, c4 = st.columns(4)
        with c1: kpi("KYC Case", cust["case_id"], "Your reference", icon="🗂️")
        with c2: kpi("Status", cust["case_status"], "Current stage", icon="📊")
        with c3: kpi("Documents", f"{len(cust_docs)} / 5", "Verified records", icon="📄")
        with c4:
            conf_avg = cust_docs["confidence_score"].mean() * 100 if not cust_docs.empty else 0
            kpi("Avg Confidence", f"{conf_avg:.0f}%", "Document quality", icon="✅")

        st.markdown("<br>", unsafe_allow_html=True)
        col1, col2 = st.columns([1, 2], gap="large")
        with col1:
            st.markdown('<div class="section-card"><div class="section-card-title">📸 Your Photo</div>', unsafe_allow_html=True)
            show_img(image_path(cust_id, "customer_photo.png"))
            st.markdown('</div>', unsafe_allow_html=True)
        with col2:
            st.markdown('<div class="section-card"><div class="section-card-title">📋 Document Summary</div>', unsafe_allow_html=True)
            if not cust_docs.empty:
                show = cust_docs[["document_type","document_status","confidence_score","quality_status"]].copy()
                show["confidence_score"] = (show["confidence_score"]*100).round(0).astype(int).astype(str)+"%"
                show.columns = ["Document Type", "Status", "Confidence", "Quality"]
                st.dataframe(show, use_container_width=True, hide_index=True)
            else:
                st.info("No documents on file yet.")
            st.markdown('<div style="margin-top:14px;padding:14px;background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.2);border-radius:12px;font-size:13px;color:#7a94b8">💬 Your KYC application is being processed through secure identity verification. You will be notified once a decision is made.</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

    elif cust_page == "My Profile":
        page_header("Profile Summary", "Sensitive fields are masked for privacy", "🔒")
        profile = pd.DataFrame({
            "Field": ["Full Name","Date of Birth","Gender","Email","Mobile","Address","City","State","Nationality","Occupation","Income Range","Customer Type"],
            "Value": [masked.get("full_name"),masked.get("dob"),masked.get("gender"),masked.get("email"),masked.get("mobile"),masked.get("address"),masked.get("city"),masked.get("state"),masked.get("nationality"),masked.get("occupation"),masked.get("income_range"),cust.get("customer_type")]
        })
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.dataframe(profile, use_container_width=True, hide_index=True)
        st.markdown('</div>', unsafe_allow_html=True)

    elif cust_page == "Photo & Selfie":
        page_header("Photo & Selfie Verification", "Biometric identity verification results", "🪞")
        c1, c2 = st.columns(2, gap="large")
        with c1:
            st.markdown('<div class="section-card"><div class="section-card-title">📷 Registered Photo</div>', unsafe_allow_html=True)
            show_img(image_path(cust_id,"customer_photo.png"))
            st.markdown('</div>', unsafe_allow_html=True)
        with c2:
            st.markdown('<div class="section-card"><div class="section-card-title">🤳 Onboarding Selfie</div>', unsafe_allow_html=True)
            show_img(image_path(cust_id,"selfie.png"))
            st.markdown('</div>', unsafe_allow_html=True)
        if not selfie.empty:
            s = selfie.iloc[0]
            a, b, c = st.columns(3)
            with a: kpi("Selfie Quality", s["selfie_quality"], "Image clarity score", icon="🖼️")
            with b: kpi("Liveness Check", s["liveness_check"], "Anti-spoofing", icon="👁️")
            with c: kpi("Face Match", s["face_match_status"], "Biometric match", icon="🔗")

    elif cust_page == "KYC Status":
        page_header("KYC Progress Tracker", "Your onboarding journey", "📊")
        phases = [
            ("📩", "Application Submitted", "Initial KYC application received"),
            ("📄", "Documents Uploaded", "Identity and address documents submitted"),
            ("🔍", "Validation In Progress", "AI agents verifying all documents"),
            ("👤", "Manual Review", "Compliance officer review"),
            ("✅", "Decision Made", "Final KYC outcome"),
        ]
        current_status = cust.get("case_status","")
        status_map = {
            "Document Pending": 0, "Document Uploaded": 1,
            "Validation In Progress": 2, "Agent Review In Progress": 2,
            "Manual Review Required": 3, "Approved": 4, "Rejected": 4, "Closed": 4,
        }
        current_step = status_map.get(current_status, 0)

        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        for i, (emoji, title, detail) in enumerate(phases):
            is_done = i < current_step
            is_active = i == current_step
            dot_class = "done" if is_done else "active" if is_active else ""
            label_class = "done" if is_done else "active" if is_active else ""
            status_icon = "✅" if is_done else "▶" if is_active else str(i+1)
            bg = "rgba(16,185,129,0.08)" if is_done else "rgba(200,150,42,0.08)" if is_active else "rgba(255,255,255,0.02)"
            border = "rgba(16,185,129,0.25)" if is_done else "rgba(200,150,42,0.3)" if is_active else "rgba(255,255,255,0.06)"
            st.markdown(
                f'<div style="background:{bg};border:1px solid {border};border-radius:12px;padding:14px 18px;margin:8px 0;display:flex;align-items:center;gap:14px">'
                f'<div style="width:36px;height:36px;border-radius:50%;background:{"#10b981" if is_done else "#c8962a" if is_active else "rgba(255,255,255,0.06)"};display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:800;color:{"#fff" if (is_done or is_active) else "#556080"};flex-shrink:0">{status_icon}</div>'
                f'<div><div style="font-size:14px;font-weight:700;color:{"#34d399" if is_done else "#f5c842" if is_active else "#556080"}">{emoji} {title}</div>'
                f'<div style="font-size:12px;color:#556080;margin-top:2px">{detail}</div></div>'
                f'</div>',
                unsafe_allow_html=True,
            )
        st.markdown('</div>', unsafe_allow_html=True)

    elif cust_page == "Document Checklist":
        page_header("Document Verification Checklist", "Status of all submitted documents", "📋")
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        if not cust_docs.empty:
            show = cust_docs[["document_type","document_status","confidence_score","quality_status","tampering_indicator"]].copy()
            show["confidence_score"] = (show["confidence_score"]*100).round(0).astype(int).astype(str)+"%"
            show.columns = ["Document", "Verification Status", "Confidence", "Quality", "Tamper Check"]
            st.dataframe(show, use_container_width=True, hide_index=True)
        else:
            st.info("No documents on file yet.")
        st.markdown('</div>', unsafe_allow_html=True)

    elif cust_page == "Upload Document":
        page_header("Upload / Re-submit Documents", "Submit all required KYC documents and receive acknowledgement", "📤")
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.info("Upload the required documents or submit them for secure validation and acknowledgement generation.")

        required_docs = ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"]
        selected_docs = st.multiselect("Documents to submit", required_docs, default=required_docs)
        uploaded_files = st.file_uploader(
            "Optional: select document files",
            type=["png", "jpg", "jpeg", "pdf"],
            accept_multiple_files=True
        )
        if uploaded_files:
            st.success(f"✅ {len(uploaded_files)} file(s) selected for upload simulation")

        if st.button("📤 Submit Documents & Generate Acknowledgement", use_container_width=True):
            if not selected_docs:
                st.error("Please select at least one document type.")
                st.stop()

            all_docs = load_kyc_documents()
            # Ensure fresh self-registered customers also have document rows
            missing_rows = []
            for dt in selected_docs:
                mask = (all_docs["customer_id"] == cust_id) & (all_docs["document_type"] == dt)
                if not mask.any():
                    missing_rows.append({
                        "case_id": cust["case_id"], "customer_id": cust_id, "document_type": dt,
                        "document_name": f"{dt} - Uploaded via Customer Portal", "id_number": "",
                        "document_name_value": cust.get("full_name", ""), "document_dob_value": cust.get("dob", ""),
                        "document_address_value": cust.get("address", ""), "document_age_days": 0,
                        "confidence_score": 0.96, "file_type": "PDF/PNG", "quality_status": "Passed",
                        "document_status": "Passed", "tampering_indicator": "Not Detected",
                        "issue_date": datetime.now().strftime("%Y-%m-%d"), "expiry_date": ""
                    })
                else:
                    all_docs.loc[mask, ["document_status", "quality_status", "tampering_indicator", "confidence_score"]] = ["Passed", "Passed", "Not Detected", 0.96]
            if missing_rows:
                all_docs = pd.concat([all_docs, pd.DataFrame(missing_rows)], ignore_index=True)
            save_kyc_documents(all_docs)

            refreshed = all_docs[(all_docs["customer_id"] == cust_id) & (all_docs["document_type"].isin(required_docs))]
            passed_count = int((refreshed["document_status"] == "Passed").sum())
            if passed_count >= len(required_docs):
                update_case_status(cust["case_id"], "Document Uploaded", "Customer Portal", "All mandatory KYC documents submitted by customer")
                ack_status = "All mandatory documents uploaded"
            else:
                update_case_status(cust["case_id"], "Document Uploaded", "Customer Portal", f"Partial document submission: {', '.join(selected_docs)}")
                ack_status = f"{passed_count}/{len(required_docs)} mandatory documents validated"

            ack_id = f"ACK-{cust['case_id']}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            email_body = f"""Subject: KYC Document Upload Acknowledgement - {cust['case_id']}

Dear Customer,

We have received your KYC document submission for Case ID: {cust['case_id']}.

Acknowledgement ID: {ack_id}
Status: {ack_status}
Submitted Documents: {', '.join(selected_docs)}

Your KYC application has moved to the validation and review stage. You will receive further updates through email/notification once the review is completed.

Regards,
TrustShield AI KYC Operations
"""
            st.session_state["customer_ack_email"] = email_body

            st.success("✅ All selected documents are uploaded successfully.")
            st.success("📧 Acknowledgement generated. You will receive the acknowledgement in your registered email.")
            st.info(f"Acknowledgement ID: {ack_id}")

        if st.session_state.get("customer_ack_email"):
            st.markdown("#### Acknowledgement Email Preview")
            st.text_area("Email Content", st.session_state["customer_ack_email"], height=220)
            st.download_button(
                "⬇ Download Acknowledgement Email",
                data=st.session_state["customer_ack_email"],
                file_name=f"acknowledgement_{cust['case_id']}.txt",
                mime="text/plain",
                use_container_width=True
            )
        st.markdown('</div>', unsafe_allow_html=True)

    elif cust_page == "Request Status":
        page_header("Additional Document Request", "Check if further documents are needed", "📬")
        if cust.get("case_status") == "More Documents Required":
            st.warning("⚠️ Additional documents are required to continue your KYC application. Please upload a recent address proof or bank statement via the Upload Document page.")
        else:
            st.markdown('<div class="section-card">', unsafe_allow_html=True)
            st.markdown('<div style="text-align:center;padding:30px;color:#7a94b8"><div style="font-size:48px">✅</div><div style="font-size:16px;font-weight:600;margin-top:10px">No additional documents required at this time</div></div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

    elif cust_page == "Notifications":
        page_header("Notifications", "Latest updates on your KYC application", "🔔")
        status = cust.get("case_status")
        msgs = {
            "Approved": ("success", "✅ KYC Approved", "Congratulations! Your KYC verification is complete. You are now fully onboarded."),
            "Rejected": ("danger", "❌ KYC Rejected", "Unfortunately your KYC could not be approved. Please contact support for guidance on next steps."),
            "More Documents Required": ("warning", "📎 Documents Required", "We need additional documents to proceed with your KYC. Please check the Upload Document section."),
            "Manual Review Required": ("info", "🔍 Under Review", "Your application is currently being reviewed by our compliance team. No action required from you at this time."),
        }
        kind, title, msg = msgs.get(status, ("info", "📋 Application In Progress", "Your KYC application is being processed. We will notify you once a decision is made."))
        color_map = {"success": "#10b981", "danger": "#ef4444", "warning": "#f59e0b", "info": "#3b82f6"}
        bg_map = {"success": "rgba(16,185,129,0.08)", "danger": "rgba(239,68,68,0.08)", "warning": "rgba(245,158,11,0.08)", "info": "rgba(59,130,246,0.08)"}
        color = color_map[kind]; bg = bg_map[kind]
        st.markdown(
            f'<div style="background:{bg};border:1px solid {color}40;border-radius:16px;padding:28px;margin:12px 0">'
            f'<div style="font-size:20px;font-weight:800;color:{color};margin-bottom:10px">{title}</div>'
            f'<div style="font-size:14px;color:#a0b4d0;line-height:1.65">{msg}</div>'
            f'<div style="font-size:11px;color:#556080;margin-top:12px">Last updated: {datetime.now().strftime("%d %b %Y, %I:%M %p")}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    elif cust_page == "Final Decision":
        page_header("Final KYC Decision", "Your onboarding outcome", "🏆")
        status = cust.get("case_status")
        if status == "Approved":
            st.markdown('<div style="text-align:center;padding:40px"><div style="font-size:72px">✅</div><div style="font-size:28px;font-weight:900;color:#10b981;margin-top:10px">KYC Approved</div><div style="font-size:15px;color:#7a94b8;margin-top:10px">Your identity has been verified. Welcome aboard!</div></div>', unsafe_allow_html=True)
        elif status == "Rejected":
            st.markdown('<div style="text-align:center;padding:40px"><div style="font-size:72px">❌</div><div style="font-size:28px;font-weight:900;color:#ef4444;margin-top:10px">KYC Rejected</div><div style="font-size:15px;color:#7a94b8;margin-top:10px">Please contact support for assistance.</div></div>', unsafe_allow_html=True)
        elif status == "Closed":
            st.markdown('<div style="text-align:center;padding:40px"><div style="font-size:72px">📁</div><div style="font-size:28px;font-weight:900;color:#94a3b8;margin-top:10px">Case Closed</div></div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div style="text-align:center;padding:40px"><div style="font-size:72px">⏳</div><div style="font-size:28px;font-weight:900;color:#f59e0b;margin-top:10px">Pending Decision</div><div style="font-size:15px;color:#7a94b8;margin-top:10px">Current status: {status}</div></div>', unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════
#  STAFF PORTAL
# ═══════════════════════════════════════════════════════════════════
elif st.session_state["portal_view"] == "Staff":
    role = st.session_state["user_role"]
    username = st.session_state["username"]
    reasoning_mode = "Gemini Assisted" if os.getenv("GOOGLE_API_KEY") else "Rule-based Fallback"
    st.session_state["reasoning_mode"] = reasoning_mode

    # Sidebar
    st.sidebar.markdown("""
    <div class="sidebar-brand">
      <div class="sidebar-brand-title">🛡️ TrustShield AI</div>
      <div class="sidebar-brand-sub">Staff Intelligence Portal</div>
    </div>
    """, unsafe_allow_html=True)

    role_icons = {"Admin":"👑","Compliance Reviewer":"📜","Fraud Analyst":"🔍","Auditor":"📋","Operations User":"⚙️"}
    st.sidebar.markdown(
        f'<div class="sidebar-user-badge">'
        f'<div class="sidebar-user-name">{role_icons.get(role,"👤")} KYC Staff Portal</div>'
        f'<div class="sidebar-user-role">Authorized Review Access</div>'
        f'<div style="margin-top:6px;font-size:11px;color:#556080"><span class="live-dot"></span>Live · {reasoning_mode}</div>'
        f'</div>',
        unsafe_allow_html=True,
    )
    st.sidebar.markdown("---")

    pages = [
        "Executive Dashboard", "Customer Registration", "Document Upload & Checklist",
        "Customer Photo & Document Preview", "KYC Case Queue", "Multi-Agent Review",
        "Risk & Guardrail Intelligence", "Human Review Workflow",
        "Notification & Email Center", "Audit Evidence Pack", "Case Closure"
    ]
    page = st.sidebar.radio("Navigation", pages)
    st.sidebar.markdown("---")
    if st.sidebar.button("🚪 Logout", use_container_width=True):
        logout()

    allowed = {
        "KYC Staff": pages,
        "Admin": pages,
        "Operations User": ["Executive Dashboard","Customer Registration","Document Upload & Checklist","Customer Photo & Document Preview"],
        "Compliance Reviewer": ["Executive Dashboard","Document Upload & Checklist","Customer Photo & Document Preview","KYC Case Queue","Multi-Agent Review","Risk & Guardrail Intelligence","Human Review Workflow","Notification & Email Center","Audit Evidence Pack"],
        "Fraud Analyst": ["Executive Dashboard","KYC Case Queue","Multi-Agent Review","Risk & Guardrail Intelligence","Human Review Workflow","Notification & Email Center"],
        "Auditor": ["Executive Dashboard","Customer Photo & Document Preview","Audit Evidence Pack","Case Closure"],
    }
    if page not in allowed.get(role, []):
        st.error(f"🚫 Access denied for role: {role}"); st.stop()

    def case_selector(label="Select KYC Case", key="case_select"):
        mapping, _ = get_case_options()
        labels = list(mapping.keys())
        default_label = labels[0]
        if st.session_state.get("current_case_id"):
            for lab, cid in mapping.items():
                if cid == st.session_state["current_case_id"]:
                    default_label = lab; break
        idx = labels.index(default_label) if default_label in labels else 0
        lab = st.selectbox(label, labels, index=idx, key=key)
        st.session_state["current_case_id"] = mapping[lab]
        return mapping[lab]

    # ── EXECUTIVE DASHBOARD ──────────────────────────────────────────
    if page == "Executive Dashboard":
        page_header("Executive Dashboard", "Real-time KYC portfolio overview", "📊")
        df = load_customers()
        risk_score_map = {"Low":15,"Medium":45,"High":70,"Critical":90}

        c1,c2,c3,c4,c5 = st.columns(5)
        with c1: kpi("Total Cases", f"{len(df):,}", "All KYC records", icon="🗂️")
        with c2:
            pending = len(df[df["case_status"].isin(["Manual Review Required","Agent Review In Progress","Validation In Progress"])])
            kpi("Pending Review", f"{pending:,}", "Compliance workload", "warning", "⏳")
        with c3:
            approved = len(df[df["case_status"]=="Approved"])
            kpi("Approved", f"{approved:,}", "Completed cases", "success", "✅")
        with c4:
            escalated = len(df[df["case_status"].str.contains("Escalated", na=False)])
            kpi("Escalated", f"{escalated:,}", "Fraud/Compliance queue", "warning", "🚨")
        with c5:
            critical = len(df[df["synthetic_risk_profile"]=="Critical"])
            kpi("Critical Risk", f"{critical:,}", "Immediate review needed", "danger", "⛔")

        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        c1,c2,c3,c4,c5 = st.columns(5)
        with c1:
            rejected = len(df[df["case_status"]=="Rejected"])
            kpi("Rejected", f"{rejected:,}", "Non-compliant cases", "danger", "❌")
        with c2:
            doc_pending = len(df[df["case_status"]=="Document Pending"])
            kpi("Doc Pending", f"{doc_pending:,}", "Awaiting customer", icon="📄")
        with c3:
            high_risk = len(df[df["synthetic_risk_profile"]=="High"])
            kpi("High Risk", f"{high_risk:,}", "Enhanced review", "warning", "⚠️")
        with c4:
            sla_breach = len(df[(df["synthetic_risk_profile"].isin(["High","Critical"])) & (~df["case_status"].isin(["Approved","Rejected","Closed"]))])
            kpi("SLA Breach Risk", f"{sla_breach:,}", "Priority escalation", "danger", "🔔")
        with c5:
            avg_risk = int(df["synthetic_risk_profile"].map(risk_score_map).mean())
            kpi("Avg Risk Score", f"{avg_risk}", "Portfolio risk index", icon="📈")

        st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)

        tab1, tab2, tab3 = st.tabs(["📋 Priority Queue", "📊 Analytics", "🗺️ Queue Distribution"])
        with tab1:
            priority = df[df["synthetic_risk_profile"].isin(["High","Critical"])].head(15)
            display = masked_case_df(priority)[["case_id","customer_id","full_name","synthetic_risk_profile","case_status","assigned_queue","sla_hours"]]
            display.columns = ["Case ID","Customer ID","Name","Risk","Status","Queue","SLA (hrs)"]
            st.dataframe(display, use_container_width=True, hide_index=True)
        with tab2:
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("##### Risk Distribution")
                st.bar_chart(df["synthetic_risk_profile"].value_counts(), color="#c8962a")
            with col2:
                st.markdown("##### Case Status Distribution")
                st.bar_chart(df["case_status"].value_counts().head(8), color="#3b82f6")
        with tab3:
            st.markdown("##### Cases by Queue")
            st.bar_chart(df["assigned_queue"].value_counts().head(10))

    # ── CUSTOMER REGISTRATION ─────────────────────────────────────────
    elif page == "Customer Registration":
        page_header("New Customer Registration", "Create a new KYC onboarding case", "➕")
        st.markdown('<div class="form-card">', unsafe_allow_html=True)
        with st.form("reg_form", clear_on_submit=True):
            st.markdown("#### Personal Information")
            c1, c2, c3 = st.columns(3)
            with c1:
                full_name = st.text_input("Full Name", "New Applicant")
                dob = st.date_input("Date of Birth", value=date(1995,1,1))
                gender = st.selectbox("Gender", ["Female","Male","Other","Prefer not to say"])
                email = st.text_input("Email", "applicant@example.com")
            with c2:
                mobile = st.text_input("Mobile Number", "9876543210")
                address = st.text_area("Residential Address", "Residential Street, Residential Area")
                city = st.text_input("City", "Chennai")
                state = st.text_input("State", "Tamil Nadu")
            with c3:
                nationality = st.text_input("Nationality", "Indian")
                occupation = st.text_input("Occupation", "Salaried")
                income = st.selectbox("Annual Income Range", ["<5L","5L-10L","10L-25L","25L-50L","50L+"])
                cust_type = st.selectbox("Customer Type", ["Retail","Business","NRI","HNI"])
                channel = st.selectbox("Application Channel", ["Branch","Mobile App","Web Portal","API","Partner"])
            st.markdown("---")
            submitted = st.form_submit_button("🚀 Create KYC Case", use_container_width=True)
        if submitted:
            df = load_customers()
            next_id = f"CUST{len(df)+1:05d}"; case_id = f"CASE{len(df)+1:05d}"
            new = {
                "case_id": case_id, "customer_id": next_id, "login_username": "",
                "full_name": full_name, "dob": dob.strftime("%Y-%m-%d"), "gender": gender,
                "email": email, "mobile": mobile, "address": address, "city": city,
                "state": state, "country": "India", "nationality": nationality,
                "occupation": occupation, "income_range": income, "customer_type": cust_type,
                "application_channel": channel, "application_date": datetime.now().strftime("%Y-%m-%d"),
                "case_status": "Document Pending", "assigned_queue": "Compliance Queue",
                "sla_hours": 24, "synthetic_risk_profile": "Medium", "profile_image_path": ""
            }
            save_customers(pd.concat([df, pd.DataFrame([new])], ignore_index=True))
            update_case_status(case_id, "Document Pending", username, "New customer registration")
            st.success(f"✅ Customer created: **{next_id}** | Case: **{case_id}** | Status: Document Pending")
        st.markdown('</div>', unsafe_allow_html=True)

    # ── DOCUMENT UPLOAD & CHECKLIST ───────────────────────────────────
    elif page == "Document Upload & Checklist":
        page_header("Document Management", "View and manage KYC document status", "📄")
        case_id = case_selector(key="doc_case")
        details = get_case_details(case_id)
        cust = details["customer"]
        docs = pd.DataFrame(details["documents"])

        st.markdown(
            f'<div class="section-card"><div class="section-card-title">📋 Case Overview</div>'
            f'<b style="color:#e2eaf8">{cust["customer_id"]}</b> &ensp; {badge(cust["synthetic_risk_profile"],"auto")} &ensp; {badge(cust["case_status"],"auto")}'
            f'</div>',
            unsafe_allow_html=True,
        )
        if not docs.empty:
            show = docs[["document_type","document_status","confidence_score","quality_status","tampering_indicator","document_age_days"]].copy()
            show["confidence_score"] = (show["confidence_score"]*100).round(0).astype(int).astype(str)+"%"
            show.columns = ["Document","Status","Confidence","Quality","Tamper","Age (days)"]
            st.dataframe(show, use_container_width=True, hide_index=True)

        st.markdown('<div class="section-card"><div class="section-card-title">🔄 Simulate Re-validation</div>', unsafe_allow_html=True)
        doc_type = st.selectbox("Document Type", ["PAN","Aadhaar","Bank Statement","Salary Slip","Address Proof"])
        if st.button("✅ Mark Selected Document as Passed"):
            all_docs = load_kyc_documents()
            mask = (all_docs["case_id"]==case_id) & (all_docs["document_type"]==doc_type)
            all_docs.loc[mask, ["document_status","quality_status","tampering_indicator","confidence_score"]] = ["Passed","Passed","Not Detected",0.96]
            save_kyc_documents(all_docs)
            update_case_status(case_id, "Document Uploaded", username, f"Document {doc_type} validated as passed")
            st.success(f"✅ {doc_type} updated to Passed")
        st.markdown('</div>', unsafe_allow_html=True)

    # ── PHOTO & DOCUMENT PREVIEW ──────────────────────────────────────
    elif page == "Customer Photo & Document Preview":
        page_header("Document Preview", "View all submitted identity documents", "🔎")
        case_id = case_selector(key="preview_case")
        details = get_case_details(case_id)
        cust_id_sel = details["customer"]["customer_id"]
        docs = pd.DataFrame(details["documents"])
        st.markdown(
            f'<div class="section-card" style="margin-bottom:18px"><div class="section-card-title">👤 Customer</div>'
            f'<b style="color:#e2eaf8">{cust_id_sel}</b> &ensp; {badge(details["customer"]["synthetic_risk_profile"],"auto")} &ensp; {badge(details["customer"]["case_status"],"auto")}'
            f'</div>',
            unsafe_allow_html=True,
        )
        document_grid(cust_id_sel, docs)

    # ── KYC CASE QUEUE ────────────────────────────────────────────────
    elif page == "KYC Case Queue":
        page_header("KYC Case Queue", "Auto-approved and pending human review queues", "📥")
        df = load_customers()

        auto_queue = df[
            (df["synthetic_risk_profile"] == "Low") &
            (df["case_status"].isin(["Document Uploaded", "Approved", "Closed"]))
        ].copy()

        pending_queue = df[
            (df["synthetic_risk_profile"].isin(["Medium", "High", "Critical"])) &
            (~df["case_status"].isin(["Approved", "Rejected", "Closed"]))
        ].copy()

        q1, q2, q3 = st.columns(3)
        with q1:
            kpi("Auto Approved Queue", f"{len(auto_queue):,}", "Low-risk / eligible cases", "success", "✅")
        with q2:
            kpi("Pending Human Review", f"{len(pending_queue):,}", "Manual reviewer workload", "warning", "👤")
        with q3:
            kpi("Total Active Cases", f"{len(df[~df['case_status'].isin(['Closed'])]):,}", "All open/closed mix", icon="📥")

        tab_auto, tab_pending, tab_all = st.tabs(["✅ Auto Approved Queue", "👤 Pending Human Review Queue", "📋 All Cases"])

        def render_queue_table(work, label, key_prefix):
            st.markdown(f"<div style='color:#7a94b8;font-size:13px;margin-bottom:10px'>{label}: showing {min(len(work),200)} of {len(work)} cases</div>", unsafe_allow_html=True)
            if work.empty:
                st.info("No cases available in this queue.")
                return
            display = masked_case_df(work)[["case_id","customer_id","full_name","synthetic_risk_profile","case_status","assigned_queue","sla_hours"]].head(200)
            display.columns = ["Case ID","Customer ID","Name","Risk","Status","Queue","SLA (hrs)"]
            st.dataframe(display, use_container_width=True, hide_index=True)
            mapping = {f"{r.case_id} | {r.customer_id} | {r.synthetic_risk_profile} | {r.case_status}": r.case_id for r in work.head(200).itertuples()}
            selected = st.selectbox("Select case", list(mapping.keys()), key=f"{key_prefix}_select")
            if st.button("📌 Set as Active Case", key=f"{key_prefix}_set", use_container_width=True):
                st.session_state["current_case_id"] = mapping[selected]
                st.success(f"✅ Active case set to: **{mapping[selected]}**. Continue to Multi-Agent Review or Human Review Workflow.")

        with tab_auto:
            st.markdown('<div class="section-card"><div class="section-card-title">✅ Auto Approved Queue</div>', unsafe_allow_html=True)
            st.success("These are low-risk cases eligible for auto approval after document upload and validation. Staff can still open any case for audit review.")
            render_queue_table(auto_queue, "Auto approved / eligible queue", "auto_queue")
            st.markdown('</div>', unsafe_allow_html=True)

        with tab_pending:
            st.markdown('<div class="section-card"><div class="section-card-title">👤 Pending Human Review Queue</div>', unsafe_allow_html=True)
            st.warning("These cases require manual verification because of medium/high/critical risk, missing/failed checks, or guardrail triggers.")
            render_queue_table(pending_queue, "Pending human review queue", "pending_queue")
            st.markdown('</div>', unsafe_allow_html=True)

        with tab_all:
            col1, col2, col3 = st.columns(3)
            with col1:
                queue = st.selectbox("Queue Filter", ["All Queues"] + sorted(df["assigned_queue"].dropna().unique().tolist()), key="all_queue_filter")
            with col2:
                risk = st.selectbox("Risk Level", ["All","Low","Medium","High","Critical"], key="all_risk_filter")
            with col3:
                status_filter = st.selectbox("Status", ["All"] + sorted(df["case_status"].dropna().unique().tolist()), key="all_status_filter")

            work = df.copy()
            if queue != "All Queues": work = work[work["assigned_queue"]==queue]
            if risk != "All": work = work[work["synthetic_risk_profile"]==risk]
            if status_filter != "All": work = work[work["case_status"]==status_filter]
            render_queue_table(work, "All cases", "all_cases")

    # ── MULTI-AGENT REVIEW ────────────────────────────────────────────
    elif page == "Multi-Agent Review":
        page_header("Multi-Agent Review Center", "Run the full agentic KYC analysis pipeline", "🤖")
        case_id = case_selector("Select Case for Agentic Review", "agent_case")
        details = get_case_details(case_id)
        cust = details["customer"]

        c1,c2,c3,c4 = st.columns(4)
        with c1: kpi("Case ID", case_id, cust["customer_id"], icon="🗂️")
        with c2:
            kind = "danger" if cust["synthetic_risk_profile"] in ["Critical","High"] else "warning" if cust["synthetic_risk_profile"] == "Medium" else "success"
            kpi("Risk Profile", cust["synthetic_risk_profile"], "Dataset scenario", kind, "⚡")
        with c3: kpi("Status", cust["case_status"][:20], "Current workflow", icon="📊")
        with c4:
            rm_kind = "success" if "Gemini" in reasoning_mode else "warning"
            kpi("AI Engine", reasoning_mode.split()[0], "Reasoning mode", rm_kind, "🧠")

        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        c1, c2 = st.columns([1, 2], gap="large")
        with c1:
            st.markdown('<div class="section-card"><div class="section-card-title">📷 Customer</div>', unsafe_allow_html=True)
            show_img(image_path(cust["customer_id"],"customer_photo.png"))
            st.markdown('</div>', unsafe_allow_html=True)
        with c2:
            st.markdown('<div class="section-card"><div class="section-card-title">🔄 Execution Timeline</div>', unsafe_allow_html=True)
            pending = get_active_result(case_id)
            if pending:
                show_timeline(pending)
            else:
                st.markdown('<div style="text-align:center;padding:30px;color:#556080"><div style="font-size:40px">🤖</div><div style="font-size:14px;margin-top:10px">Click the button below to run the complete 9-agent KYC pipeline</div></div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

        if st.button("▶ Run Agentic KYC Review Pipeline", use_container_width=True):
            with st.spinner("🤖 Running Document Intelligence, Identity, Compliance RAG, AML, PEP, Sanctions, Fraud, Risk Scoring, Guardrail and Audit agents..."):
                res = run_agents_for_case(case_id)
                st.session_state["orchestrator_result"] = res
            st.success("✅ Agentic KYC Review pipeline completed successfully")
            st.rerun()

        res = get_active_result(case_id)
        if res:
            st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
            risk_res = res["risk_result"]
            guard = res["guardrail_result"]
            wf = res.get("decision_workflow", {})

            st.markdown("### Agent Decision Summary")
            x1,x2,x3,x4 = st.columns(4)
            rc = "danger" if risk_res["risk_score"] >= 70 else "warning" if risk_res["risk_score"] >= 40 else "success"
            with x1: kpi("Risk Score", f"{risk_res['risk_score']}/100", risk_res["risk_level"], rc, "📊")
            with x2: kpi("AI Decision", risk_res["recommended_decision"][:18], "System recommendation", icon="🧠")
            with x3: kpi("Workflow", wf.get("system_action", guard["status"])[:18], wf.get("final_case_status","")[:20], icon="⚖️")
            with x4: kpi("Reasoning", "Fallback" if res.get("is_fallback") else "Gemini", "Engine used", icon="🔬")

            show_workflow_decision(res)

            st.markdown("#### Risk Drivers")
            cols = st.columns(2)
            for i, d in enumerate(risk_res.get("risk_drivers", [])[:6]):
                with cols[i % 2]:
                    st.markdown(f"<div style='background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.15);border-radius:8px;padding:8px 12px;margin:4px 0;font-size:13px;color:#f87171'>⚠ {d}</div>", unsafe_allow_html=True)

            st.markdown("### Specialist Agent Findings")
            show_agent_cards(res["agent_findings"])

            with st.expander("🔐 View Secure Masked Context JSON"):
                st.json(res["secure_context"])

    # ── RISK & GUARDRAIL ──────────────────────────────────────────────
    elif page == "Risk & Guardrail Intelligence":
        page_header("Risk & Guardrail Intelligence", "Detailed risk scoring and compliance guardrails", "🛡️")
        case_id = st.session_state.get("current_case_id") or case_selector(key="risk_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("⚠️ Run the Agentic KYC Review pipeline first from the Multi-Agent Review page."); st.stop()

        risk_res = res["risk_result"]
        guard = res["guardrail_result"]
        score = risk_res["risk_score"]
        rc = risk_color_class(risk_res["risk_level"])

        col1, col2 = st.columns([1, 1], gap="large")
        with col1:
            st.markdown(
                f'<div class="section-card"><div class="section-card-title">📊 Risk Scorecard</div>'
                f'<div class="risk-score-display">'
                f'<div class="risk-score-number {rc}">{score}</div>'
                f'<div class="risk-score-label">/ 100 — {risk_res["risk_level"]}</div>'
                f'</div>'
                f'<div style="margin:14px 0">{badge(risk_res["recommended_decision"],"auto")}</div>'
                f'</div>',
                unsafe_allow_html=True,
            )
            st.markdown('<div class="section-card"><div class="section-card-title">⚠️ Risk Drivers</div>', unsafe_allow_html=True)
            for d in risk_res["risk_drivers"]:
                st.markdown(f"<div style='font-size:13px;color:#a0b4d0;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.05)'>→ {d}</div>", unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

        with col2:
            g_kind = "danger" if "block" in guard["status"].lower() else "warning" if "warn" in guard["status"].lower() else "success"
            st.markdown(
                f'<div class="section-card"><div class="section-card-title">🛡️ Guardrail Result</div>'
                f'{badge(guard["status"], "auto")}'
                f'<div style="margin:14px 0"><div class="decision-field"><strong>Policy Reference:</strong> {guard["policy_reference"]}</div>'
                f'<div class="decision-field"><strong>Required Action:</strong> {guard["required_human_action"]}</div></div>'
                f'</div>',
                unsafe_allow_html=True,
            )
            blocked = guard.get("blocked_reasons", [])
            if blocked:
                st.markdown('<div class="section-card"><div class="section-card-title">🚫 Blocked Triggers</div>', unsafe_allow_html=True)
                for b in blocked:
                    st.markdown(f"<div style='font-size:13px;color:#f87171;padding:5px 0;border-bottom:1px solid rgba(239,68,68,0.1)'>✗ {b}</div>", unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

        st.markdown("### Business Workflow Decision")
        show_workflow_decision(res)
        st.markdown("### Compliance Reasoning")
        st.markdown(f'<div class="reason-box">{res["gemini_reasoning"]}</div>', unsafe_allow_html=True)

    # ── HUMAN REVIEW WORKFLOW ─────────────────────────────────────────
    elif page == "Human Review Workflow":
        page_header("Human Review Workflow", "Reviewer decision and override controls", "👤")
        case_id = st.session_state.get("current_case_id") or case_selector(key="review_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("⚠️ Run the Agentic KYC Review pipeline first."); st.stop()

        details = get_case_details(case_id)
        cust = details["customer"]
        risk_res = res["risk_result"]
        guard = res["guardrail_result"]

        c1,c2,c3 = st.columns(3)
        with c1: kpi("Customer", cust["customer_id"], cust["synthetic_risk_profile"], icon="👤")
        with c2:
            rc = "danger" if risk_res["risk_score"] >= 70 else "warning" if risk_res["risk_score"] >= 40 else "success"
            kpi("Risk Score", f"{risk_res['risk_score']}/100", risk_res["risk_level"], rc, "📊")
        with c3: kpi("Guardrail", guard["status"][:20], guard["required_human_action"][:30], icon="🛡️")

        show_workflow_decision(res)
        st.markdown("### Agent Summary (Top 5)")
        show_agent_cards(res["agent_findings"][:5])

        st.markdown('<div class="section-card"><div class="section-card-title">✍️ Reviewer Action</div>', unsafe_allow_html=True)
        options = ["Approve","Reject","Escalate to Compliance","Escalate to Fraud Team","Request More Documents","Senior Approval Required","Close Case"]
        wf_action = res.get("decision_workflow",{}).get("system_action","")
        default_idx = 1 if wf_action == "Auto Reject" else 2 if "Manual Review" in wf_action else 0
        action = st.selectbox("Decision Action", options, index=default_idx)
        comment = st.text_area("Reviewer Comment (Mandatory)", placeholder="Provide your review findings and rationale...")
        override = st.text_area("Override Reason (Required for approving blocked/high-risk cases)", placeholder="Document the business justification for override...")

        col_a, col_b = st.columns(2)
        with col_a:
            if st.button("✅ Submit Human Review", use_container_width=True):
                if not comment.strip():
                    st.error("❌ Reviewer comment is mandatory."); st.stop()
                if action == "Approve" and (guard["status"] == "Blocked" or risk_res["risk_level"] in ["High","Critical"]) and not override.strip():
                    st.error("❌ Override reason is mandatory for high-risk or blocked case approvals."); st.stop()
                mapping = {"Approve":"Approved","Reject":"Rejected","Escalate to Compliance":"Escalated to Compliance","Escalate to Fraud Team":"Escalated to Fraud Team","Request More Documents":"More Documents Required","Senior Approval Required":"Senior Approval Required","Close Case":"Closed"}
                final_status = mapping[action]
                update_case_status(case_id, final_status, f"{username} ({role})", f"{comment} | Override: {override}")
                pdf = generate_evidence_pack_pdf(res)
                st.success(f"✅ Review submitted. Status → **{final_status}**. Evidence pack: `{pdf}`")
        with col_b:
            if st.button("📋 Export Review Summary", use_container_width=True):
                st.info("Review summary export is available after submission via Audit Evidence Pack.")
        st.markdown('</div>', unsafe_allow_html=True)

    # ── NOTIFICATION & EMAIL CENTER ───────────────────────────────────
    elif page == "Notification & Email Center":
        page_header("Notification & Email Center", "AI-generated email drafts for all stakeholders", "📧")
        case_id = st.session_state.get("current_case_id") or case_selector(key="notif_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("⚠️ Run the Agentic KYC Review pipeline first."); st.stop()

        drafts = res.get("notification_drafts", {})
        st.info("📧 After agentic review, notification drafts are generated for both customer and staff. This environment creates downloadable .txt drafts; no outbound email is sent.")

        draft_type = st.selectbox("Select Draft Type", list(drafts.keys()))
        draft = drafts[draft_type]

        col1, col2 = st.columns([1, 2], gap="large")
        with col1:
            st.markdown(
                f'<div class="section-card">'
                f'<div class="section-card-title">📨 Draft Info</div>'
                f'<div class="decision-field"><strong>Type:</strong> {draft_type.replace("_"," ").title()}</div>'
                f'<div class="decision-field"><strong>Case:</strong> {case_id}</div>'
                f'<div class="decision-field"><strong>Recipient:</strong> {"Customer" if "customer" in draft_type else "Staff"}</div>'
                f'<div class="decision-field" style="margin-top:12px"><strong>Evidence:</strong><br><code style="font-size:11px;color:#7a94b8">reports/evidence_packs/{case_id}_evidence_pack.pdf</code></div>'
                f'</div>',
                unsafe_allow_html=True,
            )
        with col2:
            st.markdown('<div class="section-card"><div class="section-card-title">✉️ Email Preview</div>', unsafe_allow_html=True)
            st.text_input("Subject Line", value=draft.get("subject",""), disabled=True)
            st.text_area("Email Body", value=draft.get("body",""), height=260)
            path, text = save_notification_file(case_id, draft_type, draft)
            st.download_button("📥 Download Email Draft", text, file_name=path.name, mime="text/plain")
            st.markdown('</div>', unsafe_allow_html=True)

    # ── AUDIT EVIDENCE PACK ───────────────────────────────────────────
    elif page == "Audit Evidence Pack":
        page_header("Audit Evidence Pack", "Generate tamper-proof compliance evidence packages", "📑")
        case_id = st.session_state.get("current_case_id") or case_selector(key="pdf_case")
        res = get_active_result(case_id)
        if not res:
            st.warning("⚠️ Run the Agentic KYC Review pipeline first."); st.stop()

        show_workflow_decision(res)

        st.markdown('<div class="section-card"><div class="section-card-title">🔍 Agent Findings Evidence Table</div>', unsafe_allow_html=True)
        findings_df = pd.DataFrame(res["agent_findings"])[["agent_name","status","finding","evidence","confidence","risk_impact"]]
        findings_df["confidence"] = (findings_df["confidence"]*100).round(0).astype(int).astype(str)+"%"
        findings_df.columns = ["Agent","Status","Finding","Evidence","Confidence","Risk Impact"]
        st.dataframe(findings_df, use_container_width=True, hide_index=True)
        st.markdown('</div>', unsafe_allow_html=True)

        col1, col2 = st.columns(2)
        with col1:
            if st.button("📄 Generate Audit PDF Evidence Pack", use_container_width=True):
                with st.spinner("Generating PDF evidence pack..."):
                    path = generate_evidence_pack_pdf(res)
                st.success(f"✅ Evidence pack generated: `{path}`")
        with col2:
            pdf_path = DIRS["evidence_packs"] / f"{case_id}_evidence_pack.pdf"
            if pdf_path.exists():
                st.download_button("📥 Download Evidence Pack PDF", pdf_path.read_bytes(), file_name=pdf_path.name, mime="application/pdf", use_container_width=True)
            else:
                st.info("Generate the PDF first to enable download.")

        with st.expander("🗂️ Agent Trace JSON"):
            trace_path = DIRS["agent_traces"] / f"{case_id}_trace.json"
            if trace_path.exists():
                try: st.json(json.loads(trace_path.read_text()))
                except: st.code(trace_path.read_text())
            else:
                st.info("Trace file will be generated after running the agent pipeline.")

    # ── CASE CLOSURE ──────────────────────────────────────────────────
    elif page == "Case Closure":
        page_header("Case Closure & Audit Log", "Finalized cases and full audit trail", "🗃️")
        df = load_customers()
        hist = load_case_history()
        closed = df[df["case_status"].isin(["Approved","Rejected","Closed"])]

        c1, c2, c3 = st.columns(3)
        with c1: kpi("Closed Cases", f"{len(closed):,}", "Approved + Rejected + Closed", "success", "✅")
        with c2: kpi("Approved", f"{len(closed[closed['case_status']=='Approved']):,}", "Successfully onboarded", "success", "🏆")
        with c3: kpi("Rejected", f"{len(closed[closed['case_status']=='Rejected']):,}", "Non-compliant", "danger", "❌")

        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        tab1, tab2 = st.tabs(["📋 Closed Cases", "📜 Audit Trail"])
        with tab1:
            display = masked_case_df(closed)[["case_id","customer_id","full_name","synthetic_risk_profile","case_status","assigned_queue"]].head(200)
            display.columns = ["Case ID","Customer ID","Name","Risk","Status","Queue"]
            st.dataframe(display, use_container_width=True, hide_index=True)
        with tab2:
            st.markdown("##### Latest 100 Audit Events")
            audit_display = hist.sort_values("created_at", ascending=False).head(100)
            st.dataframe(audit_display, use_container_width=True, hide_index=True)
            audit_path = DIRS["audit_logs"] / "audit_trail.json"
            if audit_path.exists():
                with st.expander("🔐 Raw Audit Trail JSON"):
                    try: st.json(json.loads(audit_path.read_text()))
                    except: st.info("Audit JSON not available")
