import os
import random
import json
import csv
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from src.config import FILES, DIRS

# Seed configuration for deterministic output
RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

# Helper function to generate safe names
FIRST_NAMES_MALE = ["Aarav", "Rohan", "Aditya", "Kabir", "Sameer", "Raj", "Amit", "Rahul", "Kunal", "Vikram", "Siddharth", "Arjun", "Neil", "Dev"]
FIRST_NAMES_FEMALE = ["Priya", "Meera", "Zara", "Elena", "Ananya", "Riya", "Neha", "Kiran", "Simran", "Asha", "Divya", "Sonia", "Pooja", "Tina"]
LAST_NAMES = ["Sharma", "Verma", "Das", "Patel", "Nair", "Khan", "Malhotra", "Ahmed", "Singhania", "Gupta", "Mehta", "Rao", "Joshi", "Sen"]

OCCUPATIONS = ["Software Engineer", "Consultant", "Doctor", "Business Analyst", "Teacher", "Entrepreneur", "Retired", "Student", "Financial Analyst", "Public Servant"]
INCOME_RANGES = ["< 5 LPA", "5 - 10 LPA", "10 - 25 LPA", "25 - 50 LPA", "50 LPA+"]
CHANNELS = ["Mobile App", "Web Portal", "Branch", "Relationship Manager"]
STATES = ["Maharashtra", "Karnataka", "Delhi", "Gujarat", "Tamil Nadu", "West Bengal", "Uttar Pradesh", "Kerala"]
CITIES = {
    "Maharashtra": ["Mumbai", "Pune", "Nagpur"],
    "Karnataka": ["Bangalore", "Mysore", "Hubli"],
    "Delhi": ["New Delhi", "Dwarka", "Rohini"],
    "Gujarat": ["Ahmedabad", "Gandhinagar", "Surat"],
    "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"],
    "West Bengal": ["Kolkata", "Howrah", "Siliguri"],
    "Uttar Pradesh": ["Noida", "Lucknow", "Kanpur"],
    "Kerala": ["Kochi", "Trivandrum", "Calicut"],
}

def generate_random_dob(age_range=(19, 70)):
    """Generate birthdate based on age range."""
    age = random.randint(*age_range)
    current_year = datetime.now().year
    birth_year = current_year - age
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return f"{birth_year:04d}-{month:02d}-{day:02d}"

def generate_document_image(file_path, text_lines, is_document=True):
    """Generate a clean synthetic image using Pillow with a watermark."""
    img = Image.new('RGB', (500, 350), color='#F0F2F6')
    draw = ImageDraw.Draw(img)
    
    # Try loading default font
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None
        
    # Draw background border
    draw.rectangle([10, 10, 490, 340], outline='#1E3A8A', width=3)
    
    # Draw secure watermark banner at top and bottom
    draw.rectangle([10, 10, 490, 40], fill='#EF4444')
    draw.rectangle([10, 310, 490, 340], fill='#EF4444')
    
    title_wm = "SYNTHETIC DEMO DOCUMENT - NOT A REAL ID"
    draw.text((30, 18), title_wm, fill='white', font=font)
    draw.text((30, 318), title_wm, fill='white', font=font)
    
    # Fill main body text
    y_offset = 60
    for line in text_lines:
        draw.text((30, y_offset), line, fill='#1F2937', font=font)
        y_offset += 25
        
    # If not a document, draw a basic face symbol
    if not is_document:
        draw.ellipse([340, 100, 440, 200], fill='#9CA3AF', outline='#4B5563', width=2) # head
        draw.ellipse([310, 200, 470, 290], fill='#6B7280', outline='#4B5563', width=2) # body
        draw.text((330, 295), "DEMO PHOTO", fill='#4B5563', font=font)
        
    img.save(file_path)

def generate_all_datasets():
    """Generates all the datasets if they do not exist."""
    print("Starting deterministic dataset generation...")
    
    # Define rules JSON first
    rules = {
        "minimum_age": 18,
        "mandatory_documents": ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof", "Selfie"],
        "address_proof_max_age_days": 90,
        "bank_statement_max_age_days": 90,
        "min_document_confidence": 0.60,
        "manual_review_score": 31,
        "escalate_score": 61,
        "reject_score": 81,
        "risk_weights": {
            "missing_document": 15,
            "expired_document": 20,
            "low_confidence_doc": 10,
            "name_mismatch": 15,
            "dob_mismatch": 15,
            "address_mismatch": 10,
            "poor_selfie_quality": 10,
            "selfie_match_failed": 25,
            "liveness_failed": 25,
            "duplicate_pan": 30,
            "duplicate_mobile": 15,
            "duplicate_bank_account": 15,
            "sanctions_match": 45,
            "pep_match": 25,
            "adverse_media_match": 20,
            "suspicious_txn": 15,
            "high_value_txn": 10,
            "high_risk_country": 20,
            "synthetic_identity": 25,
            "repeated_kyc": 10,
            "tampering_suspected": 30
        },
        "guardrails": {
            "block_sanctions": True,
            "block_duplicate_pan": True,
            "block_missing_mandatory": True,
            "block_failed_liveness": True,
            "block_critical_risk": True,
            "require_override_reason": True
        },
        "role_permissions": {
            "Admin": ["register", "upload", "check_docs", "run_ai", "human_review", "view_audit", "evidence_pack"],
            "Compliance Reviewer": ["check_docs", "run_ai", "human_review", "view_audit", "evidence_pack"],
            "Fraud Analyst": ["run_ai", "human_review", "view_audit"],
            "Auditor": ["view_audit", "evidence_pack"],
            "Operations User": ["register", "upload", "check_docs"]
        }
    }
    
    with open(FILES["compliance_rules"], "w") as f:
        json.dump(rules, f, indent=4)
        
    # Define policy text
    policy_text = """TRUSTSHIELD AI - ENTERPRISE KYC & AML COMPLIANCE POLICY GUIDELINES
========================================================================
Effective Date: January 1, 2026

1. MANDATORY KYC DOCUMENTS
All retail customers seeking onboarding must submit:
a. Permanent Account Number (PAN) Card (for tax verification)
b. Aadhaar Card or Passport (for proof of identity)
c. Utility Bill, Rent Agreement, or Passport (for proof of address)
d. Bank Statement (last 3 months, for financial profiling)
e. Salary Slip (recent, for occupation/income validation)
f. Selfie Portrait (captured during onboarding for liveness check)

2. MINIMUM AGE REQUIREMENT
The customer must be at least 18 years of age at the time of onboarding. Any application with a calculated age under 18 must be flagged and automatically rejected.

3. RECENCY OF DOCUMENTS
Proof of address documents and Bank Statements must be issued within the last 90 days. Documents older than 90 days are considered expired, adding +20 to the risk score and requiring submission of newer files.

4. SANCTIONS AND WATCHLIST POLICY
Customers matching any records in the Sanctions Watchlist (e.g. UN, OFAC, EU watchlists) must be blocked immediately. Automatic approval of a customer with a sanctions match is strictly prohibited by Guardrails.

5. POLITICALLY EXPOSED PERSONS (PEP) POLICY
Customers identified as Politically Exposed Persons (PEPs), including politicians, judicial officials, and senior military personnel, are subject to enhanced due diligence (EDD). PEP status adds +25 to the risk score and requires compliance manager approval.

6. ADVERSE MEDIA FINDINGS
Negative public information, such as fraud regulatory charges, news reports linking to money laundering, or pending financial crimes, triggers a Warning flag and adds +20 to the risk score.

7. FRAUD AND DUPLICATION RULES
The system must scan and prevent duplicate registration parameters:
- Duplicate PAN numbers across profiles will trigger synthetic identity alerts (+30 risk impact) and block automatic approvals.
- Duplicate mobile numbers or bank accounts trigger fraud warnings.

8. SELFIE VERIFICATION AND LIVENESS
The selfie must be checked for liveness (to prevent print or video spoofing) and matched against the customer's photo extracted from Aadhaar/PAN. A liveness failure or matching score under 50% adds +25 to the risk score and blocks automatic approval.

9. AUDITING AND GOVERNANCE REQUIREMENTS
An immutable audit trail must record all events, including document uploads, OCR extractions, agent decisions, risk score updates, guardrail triggers, and reviewer override comments.
"""
    with open(FILES["kyc_policy_knowledge"], "w") as f:
        f.write(policy_text)

    # 10 Important Demo Customers Config
    demo_cust_configs = {
        "CUST00001": {"name": "Aarav Sharma", "username": "demo.low1", "risk": "Low", "gender": "Male", "dob": "1990-05-15", "pan": "ABCDE1234F", "aadhaar": "1111-2222-3333", "bank_acc": "1234567890", "mobile": "9876543210", "email": "aarav.sharma@example.com"},
        "CUST00002": {"name": "Priya Patel", "username": "demo.low2", "risk": "Low", "gender": "Female", "dob": "1993-08-20", "pan": "FGHIJ5678K", "aadhaar": "4444-5555-6666", "bank_acc": "9876543210", "mobile": "9812345670", "email": "priya.patel@example.com"},
        "CUST02500": {"name": "Aditya Verma", "username": "demo.medium1", "risk": "Medium", "gender": "Male", "dob": "1988-11-02", "pan": "KLMNO9012L", "aadhaar": "7777-8888-9999", "bank_acc": "5555666677", "mobile": "9900887766", "email": "aditya.v@example.com", "fail_reason": "address_expired"},
        "CUST02501": {"name": "Meera Nair", "username": "demo.medium2", "risk": "Medium", "gender": "Female", "dob": "1995-04-10", "pan": "PQRST3456M", "aadhaar": "2222-3333-4444", "bank_acc": "3333444455", "mobile": "9776655443", "email": "meera.nair@example.com", "fail_reason": "low_confidence_doc"},
        "CUST02502": {"name": "Rohan Das", "username": "demo.medium3", "risk": "Medium", "gender": "Male", "dob": "1991-12-25", "pan": "UVWXY7890N", "aadhaar": "5555-6666-7777", "bank_acc": "4444555566", "mobile": "9887766554", "email": "rohan.das@example.com", "fail_reason": "name_mismatch"},
        "CUST04998": {"name": "Elena Rostova", "username": "demo.high2", "risk": "High", "gender": "Female", "dob": "1982-03-30", "pan": "ABCDE7777Z", "aadhaar": "8888-9999-0000", "bank_acc": "7777888899", "mobile": "9654321098", "email": "elena.r@example.com", "fail_reason": "high_risk_country"},
        "CUST04999": {"name": "Vikram Singhania", "username": "demo.high1", "risk": "High", "gender": "Male", "dob": "1975-06-22", "pan": "ZBCDE9999Q", "aadhaar": "1212-3434-5656", "bank_acc": "1122334455", "mobile": "9112233445", "email": "vikram.s@example.com", "fail_reason": "pep_match"},
        "CUST05000": {"name": "Kabir Malhotra", "username": "demo.critical1", "risk": "Critical", "gender": "Male", "dob": "1980-01-01", "pan": "ZBCDE0000W", "aadhaar": "9999-8888-7777", "bank_acc": "9999999999", "mobile": "9988776655", "email": "kabir.m@example.com", "fail_reason": "sanctions_match"},
        "CUST05001": {"name": "Sameer Khan", "username": "demo.critical2", "risk": "Critical", "gender": "Male", "dob": "1985-07-07", "pan": "ABCDE1234F", "aadhaar": "1234-5678-9012", "bank_acc": "2222111100", "mobile": "9998887776", "email": "sameer.k@example.com", "fail_reason": "duplicate_pan"}, # Duplicates Aarav's PAN ABCDE1234F
        "CUST05002": {"name": "Zara Ahmed", "username": "demo.critical3", "risk": "Critical", "gender": "Female", "dob": "1992-09-09", "pan": "PQRST0000R", "aadhaar": "4321-8765-0987", "bank_acc": "8888999900", "mobile": "9009009009", "email": "zara.a@example.com", "fail_reason": "selfie_failed"},
    }

    # 1. Customers Dataset
    customers_data = []
    print("Generating 5000 customers...")
    
    for i in range(1, 5001):
        cust_id = f"CUST{i:05d}"
        case_id = f"CASE{i:05d}"
        
        # Check if this is one of our special 10 customers
        if cust_id in demo_cust_configs:
            cfg = demo_cust_configs[cust_id]
            full_name = cfg["name"]
            username = cfg["username"]
            dob = cfg["dob"]
            gender = cfg["gender"]
            email = cfg["email"]
            mobile = cfg["mobile"]
            risk_profile = cfg["risk"]
            country = "Russia" if cfg.get("fail_reason") == "high_risk_country" else "Iran" if cfg.get("fail_reason") == "sanctions_match" else "India"
            nationality = "Russian" if cfg.get("fail_reason") == "high_risk_country" else "Iranian" if cfg.get("fail_reason") == "sanctions_match" else "Indian"
            state = "Moscow Region" if country == "Russia" else "Tehran Province" if country == "Iran" else random.choice(STATES)
            city = "Moscow" if country == "Russia" else "Tehran" if country == "Iran" else random.choice(CITIES[state])
            address = f"{random.randint(10, 500)} Main St, {city}, {state}, {country}"
        else:
            gender = random.choice(["Male", "Female"])
            first = random.choice(FIRST_NAMES_MALE if gender == "Male" else FIRST_NAMES_FEMALE)
            last = random.choice(LAST_NAMES)
            full_name = f"{first} {last}"
            username = f"user{i}"
            dob = generate_random_dob()
            email = f"{first.lower()}.{last.lower()}{i}@example.com"
            mobile = f"{random.randint(60000, 99999)}{random.randint(10000, 99999)}"
            state = random.choice(STATES)
            city = random.choice(CITIES[state])
            country = "India"
            nationality = "Indian"
            address = f"{random.randint(10, 500)} {random.choice(['Rosewood Lane', 'Maple St', 'Orchard Rd', 'Vikas Marg'])}, {city}, {state}, {country}"
            
            # Map index to risk profile
            if i < 2000:
                risk_profile = "Low"
            elif i < 4000:
                risk_profile = "Medium"
            elif i < 4800:
                risk_profile = "High"
            else:
                risk_profile = "Critical"

        occupation = random.choice(OCCUPATIONS)
        income_range = random.choice(INCOME_RANGES)
        customer_type = "Retail"
        app_channel = random.choice(CHANNELS)
        app_date = (datetime.now() - timedelta(days=random.randint(1, 60))).strftime("%Y-%m-%d")
        
        # Case statuses mapping
        if risk_profile == "Low":
            case_status = "Approved"
        elif risk_profile == "Medium":
            case_status = "Manual Review Required"
        elif risk_profile == "High":
            case_status = "Escalated to Compliance"
        else:
            case_status = "Escalated to Fraud Team"
            
        # Let's reset the status of all demo logins so the demo workflow is cleaner
        if cust_id in demo_cust_configs:
            case_status = "Document Pending" if cust_id == "CUST00001" or cust_id == "CUST00002" else "Manual Review Required"
            
        assigned_queue = "Compliance Queue" if risk_profile in ["Medium", "High"] else "Fraud Queue" if risk_profile == "Critical" else "Auto Approval Queue"
        sla_hours = 24 if risk_profile == "Critical" else 48 if risk_profile == "High" else 72
        
        img_path = f"uploads/demo_customer_docs/{cust_id}/customer_photo.png"
        
        customers_data.append({
            "case_id": case_id,
            "customer_id": cust_id,
            "login_username": username,
            "full_name": full_name,
            "dob": dob,
            "gender": gender,
            "email": email,
            "mobile": mobile,
            "address": address,
            "city": city,
            "state": state,
            "country": country,
            "nationality": nationality,
            "occupation": occupation,
            "income_range": income_range,
            "customer_type": customer_type,
            "application_channel": app_channel,
            "application_date": app_date,
            "case_status": case_status,
            "assigned_queue": assigned_queue,
            "sla_hours": sla_hours,
            "synthetic_risk_profile": risk_profile,
            "profile_image_path": img_path
        })
        
    df_customers = pd.DataFrame(customers_data)
    df_customers.to_csv(FILES["customers"], index=False)
    
    # 2. Documents Dataset (5 documents per customer)
    docs_data = []
    registry_data = []
    print("Generating 25,000 document records...")
    
    doc_types = ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"]
    
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        risk_profile = row["synthetic_risk_profile"]
        
        # Check special configurations for discrepancies
        special_cfg = demo_cust_configs.get(cust_id, {})
        fail_reason = special_cfg.get("fail_reason")
        
        for dtype in doc_types:
            doc_status = "Passed"
            tampering = "Not Detected"
            confidence = round(random.uniform(0.85, 0.99), 2)
            quality = "Passed"
            age_days = random.randint(10, 45)
            
            # Setup ID numbers
            if dtype == "PAN":
                id_num = special_cfg.get("pan", f"PAN{random.randint(10000, 99999)}P")
            elif dtype == "Aadhaar":
                id_num = special_cfg.get("aadhaar", f"{random.randint(1000, 9999)}-{random.randint(1000, 9999)}-{random.randint(1000, 9999)}")
            else:
                id_num = "N/A"
                
            doc_name_val = row["full_name"]
            doc_dob_val = row["dob"]
            doc_addr_val = row["address"]
            
            # Injecting medium/high risk failures for demo customers
            if fail_reason == "address_expired" and dtype == "Address Proof":
                age_days = 145 # expired (limit is 90)
                doc_status = "Expired"
            elif fail_reason == "low_confidence_doc" and dtype == "Bank Statement":
                confidence = 0.55 # low confidence
                quality = "Blurred"
                doc_status = "Low Confidence"
            elif fail_reason == "name_mismatch" and dtype == "PAN":
                doc_name_val = "Rohan K Das" # profile is "Rohan Das"
                doc_status = "Warning"
                
            # Random anomalies for non-demo users based on risk profile
            if cust_id not in demo_cust_configs:
                if risk_profile == "Medium" and random.random() < 0.15:
                    if dtype == "Address Proof":
                        age_days = random.randint(95, 180)
                        doc_status = "Expired"
                    elif dtype == "Bank Statement":
                        confidence = round(random.uniform(0.40, 0.59), 2)
                        quality = "Blurred"
                        doc_status = "Low Confidence"
                elif risk_profile == "High" and random.random() < 0.20:
                    if dtype == "PAN":
                        doc_name_val = row["full_name"] + " Junior"
                        doc_status = "Warning"
                    elif dtype == "Aadhaar" and random.random() < 0.5:
                        tampering = "Detected"
                        doc_status = "Failed"
            
            issue_date = (datetime.now() - timedelta(days=age_days)).strftime("%Y-%m-%d")
            expiry_date = (datetime.now() + timedelta(days=random.randint(100, 1000))).strftime("%Y-%m-%d") if dtype in ["PAN", "Aadhaar"] else "N/A"
            
            docs_data.append({
                "case_id": case_id,
                "customer_id": cust_id,
                "document_type": dtype,
                "document_name": f"{dtype} Card" if dtype in ["PAN", "Aadhaar"] else f"{dtype}",
                "id_number": id_num,
                "document_name_value": doc_name_val,
                "document_dob_value": doc_dob_val,
                "document_address_value": doc_addr_val,
                "document_age_days": age_days,
                "confidence_score": confidence,
                "file_type": "PDF" if "Statement" in dtype or "Slip" in dtype else "PNG",
                "quality_status": quality,
                "document_status": doc_status,
                "tampering_indicator": tampering,
                "issue_date": issue_date,
                "expiry_date": expiry_date
            })
            
            # Registry entry for uploads
            file_name = f"{dtype.lower().replace(' ', '_')}.png"
            sim_path = f"uploads/demo_customer_docs/{cust_id}/{file_name}"
            prev_path = f"uploads/demo_customer_docs/{cust_id}/{file_name}"
            
            registry_data.append({
                "case_id": case_id,
                "customer_id": cust_id,
                "document_type": dtype,
                "file_name": file_name,
                "simulated_file_path": sim_path,
                "preview_image_path": prev_path,
                "upload_status": "Uploaded",
                "file_type": "PNG",
                "file_size_kb": random.randint(150, 450)
            })

    df_docs = pd.DataFrame(docs_data)
    df_docs.to_csv(FILES["kyc_documents"], index=False)
    
    df_reg = pd.DataFrame(registry_data)
    df_reg.to_csv(FILES["document_file_registry"], index=False)

    # 3. Transactions Dataset (10 transactions per customer = 50,000)
    tx_data = []
    print("Generating 50,000 transaction records...")
    
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        risk_profile = row["synthetic_risk_profile"]
        
        special_cfg = demo_cust_configs.get(cust_id, {})
        fail_reason = special_cfg.get("fail_reason")
        
        for t in range(1, 11):
            tx_id = f"TXN{cust_id[4:]}{t:02d}"
            tx_date = (datetime.now() - timedelta(days=random.randint(1, 30))).strftime("%Y-%m-%d %H:%M:%S")
            tx_type = random.choice(["IMPS", "NEFT", "RTGS", "UPI", "ATM", "POS"])
            channel = random.choice(["Mobile App", "Net Banking", "Branch", "ATM"])
            
            # Default transaction sizes
            amount = round(random.uniform(500, 45000), 2)
            suspicious = 0
            velocity_risk = 0
            high_val = 0
            
            # High-risk profile / demo anomalies
            if fail_reason == "high_risk_country" and t == 5:
                amount = 850000.00
                high_val = 1
                suspicious = 1
                velocity_risk = 1
            elif risk_profile == "High" and random.random() < 0.15:
                amount = round(random.uniform(150000, 600000), 2)
                high_val = 1
                if random.random() < 0.5:
                    suspicious = 1
            elif risk_profile == "Critical":
                amount = round(random.uniform(200000, 1200000), 2)
                high_val = 1
                suspicious = 1
                velocity_risk = 1 if random.random() < 0.7 else 0
                
            tx_data.append({
                "transaction_id": tx_id,
                "case_id": case_id,
                "customer_id": cust_id,
                "transaction_date": tx_date,
                "transaction_type": tx_type,
                "amount": amount,
                "channel": channel,
                "suspicious_txn_flag": suspicious,
                "velocity_risk": velocity_risk,
                "high_value_flag": high_val
            })
            
    df_tx = pd.DataFrame(tx_data)
    df_tx.to_csv(FILES["transactions"], index=False)

    # 4. Fraud Watchlist
    fraud_data = []
    print("Generating fraud watchlist...")
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        
        dup_mob = 0
        dup_pan = 0
        dup_bank = 0
        rep_kyc = 0
        synth_id = 0
        pattern = "None"
        
        cfg = demo_cust_configs.get(cust_id, {})
        fail = cfg.get("fail_reason")
        
        if fail == "duplicate_pan":
            dup_pan = 1
            synth_id = 1
            pattern = "Duplicate ID Match & Synthetic Signal"
        elif fail == "selfie_failed":
            synth_id = 1
            pattern = "Liveness Failure / Facial Impersonation Risk"
            
        # Add random flags for non-demo users based on risk profile
        if cust_id not in demo_cust_configs:
            risk = row["synthetic_risk_profile"]
            if risk == "High" and random.random() < 0.10:
                dup_mob = 1
                pattern = "Shared Mobile Number Flag"
            elif risk == "Critical":
                synth_id = 1
                dup_pan = 1 if random.random() < 0.5 else 0
                pattern = "Multiple Discrepancy Pattern"
                
        fraud_data.append({
            "case_id": case_id,
            "customer_id": cust_id,
            "duplicate_mobile": dup_mob,
            "duplicate_pan": dup_pan,
            "duplicate_bank_account": dup_bank,
            "repeated_kyc_attempt": rep_kyc,
            "synthetic_identity_signal": synth_id,
            "fraud_pattern": pattern
        })
    pd.DataFrame(fraud_data).to_csv(FILES["fraud_watchlist"], index=False)

    # 5. Sanctions Watchlist
    sanctions_data = []
    print("Generating sanctions watchlist...")
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        
        sanctions_match = 0
        high_risk_country = 0
        remarks = "Clear"
        
        cfg = demo_cust_configs.get(cust_id, {})
        fail = cfg.get("fail_reason")
        
        if fail == "sanctions_match":
            sanctions_match = 1
            high_risk_country = 1
            remarks = "Matched Name 'Kabir Malhotra' on UN & OFAC Consolidated Sanctions Lists"
        elif fail == "high_risk_country":
            high_risk_country = 1
            remarks = "Transaction flow / residency details link to High Risk Jurisdiction (Russia)"
            
        if cust_id not in demo_cust_configs:
            risk = row["synthetic_risk_profile"]
            if risk == "High" and random.random() < 0.05:
                high_risk_country = 1
                remarks = "Connection to high-risk jurisdiction detected"
            elif risk == "Critical" and random.random() < 0.15:
                sanctions_match = 1
                high_risk_country = 1
                remarks = "Listed entity / SDN match flagged"
                
        sanctions_data.append({
            "case_id": case_id,
            "customer_id": cust_id,
            "sanctions_match": sanctions_match,
            "high_risk_country": high_risk_country,
            "remarks": remarks
        })
    pd.DataFrame(sanctions_data).to_csv(FILES["sanctions_watchlist"], index=False)

    # 6. PEP Watchlist
    pep_data = []
    print("Generating PEP watchlist...")
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        
        pep_match = 0
        pep_category = "None"
        remarks = "Clear"
        
        cfg = demo_cust_configs.get(cust_id, {})
        fail = cfg.get("fail_reason")
        
        if fail == "pep_match":
            pep_match = 1
            pep_category = "Member of Parliament"
            remarks = "Identified as a sitting Member of Parliament in national assembly"
            
        if cust_id not in demo_cust_configs:
            risk = row["synthetic_risk_profile"]
            if risk == "High" and random.random() < 0.10:
                pep_match = 1
                pep_category = "Senior Diplomat"
                remarks = "Close relative of a Foreign Public Official"
                
        pep_data.append({
            "case_id": case_id,
            "customer_id": cust_id,
            "pep_match": pep_match,
            "pep_category": pep_category,
            "remarks": remarks
        })
    pd.DataFrame(pep_data).to_csv(FILES["pep_watchlist"], index=False)

    # 7. Adverse Media
    adverse_data = []
    print("Generating adverse media watchlist...")
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        
        adverse_match = 0
        fraud_news = 0
        fin_crime = 0
        reg_concern = 0
        remarks = "Clear"
        
        cfg = demo_cust_configs.get(cust_id, {})
        fail = cfg.get("fail_reason")
        
        if fail in ["pep_match", "sanctions_match"]:
            adverse_match = 1
            reg_concern = 1
            remarks = "Listed in compliance bulletins for scrutiny regarding PEP/SDN ties"
            
        if cust_id not in demo_cust_configs:
            risk = row["synthetic_risk_profile"]
            if risk == "High" and random.random() < 0.10:
                adverse_match = 1
                fraud_news = 1
                remarks = "Local press release mention of court litigation regarding defaults"
            elif risk == "Critical":
                adverse_match = 1
                fin_crime = 1
                remarks = "Investigated by financial intelligence agency for asset mismatch"
                
        adverse_data.append({
            "case_id": case_id,
            "customer_id": cust_id,
            "adverse_media_match": adverse_match,
            "fraud_related_news": fraud_news,
            "financial_crime_indicator": fin_crime,
            "regulatory_concern": reg_concern,
            "remarks": remarks
        })
    pd.DataFrame(adverse_data).to_csv(FILES["adverse_media"], index=False)

    # 8. Selfie Verification
    selfie_data = []
    print("Generating selfie verification records...")
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        
        selfie_available = 1
        selfie_path = f"uploads/demo_customer_docs/{cust_id}/selfie.png"
        selfie_quality = "Passed"
        selfie_match = round(random.uniform(0.75, 0.98), 2)
        liveness = "Passed"
        face_status = "Passed"
        
        cfg = demo_cust_configs.get(cust_id, {})
        fail = cfg.get("fail_reason")
        
        if fail == "selfie_failed":
            selfie_match = 0.20 # mismatch
            liveness = "Failed"
            face_status = "Failed"
            selfie_quality = "Poor"
            
        # Random failures
        if cust_id not in demo_cust_configs:
            risk = row["synthetic_risk_profile"]
            if risk == "Critical" and random.random() < 0.4:
                selfie_match = round(random.uniform(0.10, 0.45), 2)
                liveness = "Failed"
                face_status = "Failed"
                
        selfie_data.append({
            "case_id": case_id,
            "customer_id": cust_id,
            "selfie_available": selfie_available,
            "selfie_file_path": selfie_path,
            "selfie_quality": selfie_quality,
            "selfie_match_score": selfie_match,
            "liveness_check": liveness,
            "face_match_status": face_status
        })
    pd.DataFrame(selfie_data).to_csv(FILES["selfie_verification"], index=False)

    # 9. Case History
    history_data = []
    print("Generating case histories...")
    for row in customers_data:
        cust_id = row["customer_id"]
        case_id = row["case_id"]
        status = row["case_status"]
        queue = row["assigned_queue"]
        sla = row["sla_hours"]
        
        created_at = (datetime.now() - timedelta(days=random.randint(1, 30))).strftime("%Y-%m-%d %H:%M:%S")
        
        history_data.append({
            "case_id": case_id,
            "customer_id": cust_id,
            "created_at": created_at,
            "current_status": status,
            "assigned_queue": queue,
            "sla_hours": sla,
            "escalation_level": 0 if status in ["Approved", "Rejected", "New"] else 1 if status == "Manual Review Required" else 2,
            "last_action": f"System initialized case as status {status}"
        })
    pd.DataFrame(history_data).to_csv(FILES["case_history"], index=False)

    # 10. Draw 70 Synthetic Images using Pillow
    print("Drawing 70 synthetic images (10 customers x 7 documents)...")
    for cust_id, cfg in demo_cust_configs.items():
        cust_dir = DIRS["uploads"] / cust_id
        cust_dir.mkdir(parents=True, exist_ok=True)
        
        # 1. Customer Photo
        generate_document_image(
            cust_dir / "customer_photo.png",
            [
                f"CUSTOMER PORTRAIT REFERENCE",
                f"Customer ID: {cust_id}",
                f"Name: {cfg['name']}",
                f"DOB: {cfg['dob']}",
                f"Gender: {cfg['gender']}"
            ],
            is_document=False
        )
        
        # 2. Selfie
        liveness_val = "FAILED" if cfg.get("fail_reason") == "selfie_failed" else "PASSED"
        match_val = "20%" if cfg.get("fail_reason") == "selfie_failed" else "92%"
        generate_document_image(
            cust_dir / "selfie.png",
            [
                f"CUSTOMER SELFIE CAPTURE",
                f"Customer ID: {cust_id}",
                f"Liveness Status: {liveness_val}",
                f"Identity Match Score: {match_val}",
                f"Capture Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            ],
            is_document=False
        )
        
        # 3. PAN Card
        generate_document_image(
            cust_dir / "pan_card.png",
            [
                f"INCOME TAX DEPARTMENT OF INDIA",
                f"Permanent Account Number (PAN)",
                f"Card Number: {cfg['pan']}",
                f"Cardholder Name: {cfg['name'] if cfg.get('fail_reason') != 'name_mismatch' else 'Rohan K Das'}",
                f"Date of Birth: {cfg['dob']}",
                f"Father's Name: Subhash {cfg['name'].split()[-1]}"
            ],
            is_document=True
        )
        
        # 4. Aadhaar Card
        generate_document_image(
            cust_dir / "aadhaar_card.png",
            [
                f"UNIQUE IDENTIFICATION AUTHORITY OF INDIA",
                f"Aadhaar - Proof of Identity",
                f"Aadhaar Number: {cfg['aadhaar']}",
                f"Name: {cfg['name']}",
                f"DOB: {cfg['dob']}",
                f"Gender: {cfg['gender']}"
            ],
            is_document=True
        )
        
        # 5. Bank Statement
        generate_document_image(
            cust_dir / "bank_statement.png",
            [
                f"METRO CREDIT BANK - STATEMENT OF ACCOUNT",
                f"Account Holder: {cfg['name']}",
                f"Account Number: {cfg['bank_acc']}",
                f"Statement Period: Last 90 Days",
                f"Current Balance: INR 1,45,230.12",
                f"Average Balance: INR 85,000.00"
            ],
            is_document=True
        )
        
        # 6. Salary Slip
        generate_document_image(
            cust_dir / "salary_slip.png",
            [
                f"APEX GLOBAL TECHNOLOGIES PRIVATE LIMITED",
                f"Pay Slip for May 2026",
                f"Employee Name: {cfg['name']}",
                f"Designation: Manager",
                f"Gross Monthly Salary: INR 1,20,000.00",
                f"Net Paid Amount: INR 98,500.00"
            ],
            is_document=True
        )
        
        # 7. Address Proof
        age_str = "145 Days Ago" if cfg.get("fail_reason") == "address_expired" else "12 Days Ago"
        generate_document_image(
            cust_dir / "address_proof.png",
            [
                f"STATE UTILITY ELECTRICITY CORPORATION",
                f"Monthly Power Utility Bill",
                f"Bill Date: {age_str}",
                f"Customer Name: {cfg['name']}",
                f"Billing Address:",
                f"12 Main St, Dwarka, Delhi, India"
            ],
            is_document=True
        )

    print("Deterministic dataset generation complete!")

if __name__ == "__main__":
    generate_all_datasets()
