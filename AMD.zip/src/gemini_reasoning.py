import os
import google.generativeai as genai
from typing import Optional

def generate_fallback_reasoning(case_details: dict, agent_findings: list, risk_result: dict, guardrail_result: dict) -> str:
    """
    Generates a high-quality deterministic compliance report as a fallback
    when Gemini API is unavailable or fails.
    """
    cust = case_details.get("customer", {})
    full_name = cust.get("full_name", "Unknown")
    cust_id = cust.get("customer_id", "Unknown")
    case_id = cust.get("case_id", "Unknown")
    risk_score = risk_result.get("risk_score", 0)
    risk_level = risk_result.get("risk_level", "Low")
    guard_status = guardrail_result.get("status", "Allowed")
    
    report = []
    report.append("========================================================================")
    report.append("TRUSTSHIELD AI - AGENTIC COMPLIANCE INTELLIGENCE REPORT (FALLBACK ENG)")
    report.append("========================================================================")
    report.append(f"Case ID: {case_id} | Customer ID: {cust_id} | Name: {full_name}")
    report.append(f"Analysis Timestamp: {pd_timestamp_now()} | Platform Mode: Rule-Based Fallback")
    report.append("------------------------------------------------------------------------\n")
    
    # 1. Executive Summary
    report.append("1. EXECUTIVE SUMMARY")
    report.append(f"The automated compliance orchestrator completed its audit review for {full_name}.")
    report.append(f"Total Risk Score is calculated at {risk_score}/100, placing the customer in the {risk_level} Risk band.")
    
    if guard_status == "Blocked":
        reasons = "; ".join(guardrail_result.get("blocked_reasons", []))
        report.append(f"POLICY GUARDRAILS: [BLOCKED] due to: {reasons}.")
        report.append(f"ACTION REQUIRED: {guardrail_result.get('required_human_action', 'Manual Verification Required')}.")
    else:
        report.append("POLICY GUARDRAILS: [ALLOWED] - Case is eligible for standard review.")
        report.append(f"ACTION REQUIRED: {risk_result.get('recommended_decision', 'Standard Processing')}.")
    report.append("")
    
    # 2. Checklist & Verification Breakdown
    report.append("2. SPECIALIST AGENT FINDINGS & EVIDENCE SUMMARY")
    for finding in agent_findings:
        name = finding.get("agent_name", "Specialist Agent")
        status = finding.get("status", "Passed")
        evidence = finding.get("evidence", "")
        # Mask any raw numbers if present in output
        report.append(f"- [{status}] {name}: {evidence}")
    report.append("")
    
    # 3. Policy & Regulatory Findings
    report.append("3. REGULATORY COMPLIANCE DETERMINATION")
    report.append(f"Based on the local policy file 'kyc_policy_knowledge.txt' and matched criteria:")
    report.append(f"- Minimum Age Policy: Checked (DOB: {cust.get('dob')})")
    
    # List warnings
    warnings = [f.get("evidence") for f in agent_findings if f.get("status") in ["Warning", "Failed"]]
    if warnings:
        report.append("- Scrutinized Policy Deviations:")
        for w in warnings:
            report.append(f"  * {w}")
    else:
        report.append("- No policy deviations detected. The file uploads matched the KYC requirements.")
        
    report.append("\n------------------------------------------------------------------------")
    report.append("End of Automated Review. Signed: TrustShield Audit Agent")
    report.append("========================================================================")
    
    return "\n".join(report)

def pd_timestamp_now() -> str:
    try:
        import pandas as pd
        return pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        import datetime
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def run_gemini_reasoning(
    api_key: Optional[str],
    case_context_str: str,
    agent_findings_str: str,
    risk_summary_str: str,
    guardrail_summary_str: str
) -> str:
    """
    Invokes Gemini API for natural language compliance analysis.
    If the key is missing or a call exception occurs, returns empty string so that orchestrator falls back.
    """
    key = api_key or os.environ.get("GOOGLE_API_KEY")
    if not key:
        return ""
        
    try:
        genai.configure(api_key=key)
        # Using gemini-1.5-flash as the fast reasoning model
        model = genai.GenerativeModel("gemini-1.5-flash")
        
        prompt = f"""
You are the Gemini Reasoning Agent of TrustShield AI, an enterprise compliance intelligence system.
Your task is to analyze the following case context and provide a comprehensive audit reasoning summary.

RULES:
1. ONLY generate reasoning and summaries.
2. Rely ONLY on the masked case context, policy rules, and agent findings provided below. Do NOT invent facts or assume details.
3. NEVER display raw unmasked sensitive PII (Aadhaar, PAN, Bank Accounts, Mobile, Full Emails, etc.). Ensure you use masked versions.
4. Do NOT make final approvals or overrides alone; you only recommend actions based on rules.
5. Do NOT ignore policy guardrail blocks.

--- SECURE MASKED CASE CONTEXT ---
{case_context_str}

--- SPECIALIST AGENT FINDINGS ---
{agent_findings_str}

--- AUTOMATED RISK RESULT ---
{risk_summary_str}

--- SYSTEM GUARDRAILS ---
{guardrail_summary_str}

--- ASSIGNMENT ---
Provide a highly professional compliance analysis report. Include:
1. EXECUTIVE SUMMARY: Summarize the customer status and aggregate risk.
2. DETAILED EVIDENCE ANALYSIS: Discuss the findings from the documents, watchlists (PEP/Sanctions), transaction risk, and facial checks.
3. ACTIONABLE COMPLIANCE RECOMMENDATION: Explain what action the compliance reviewer should take, mentioning relevant policy rules matched.
"""
        response = model.generate_content(prompt)
        if response and response.text:
            return response.text.strip()
        return ""
    except Exception as e:
        print(f"Gemini API invocation failed: {e}")
        return ""
