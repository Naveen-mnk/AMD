import os
import streamlit as st
import pandas as pd
from datetime import datetime
from PIL import Image

# Import local modules
from src.config import STAFF_CREDENTIALS, CUSTOMER_CREDENTIALS, DIRS
from src.constants import *
from src.pii_masking import mask_customer_dict, mask_pan, mask_aadhaar, mask_mobile, mask_bank_account, mask_address
from src.data_loader import (
    load_customers, save_customers, load_kyc_documents, save_kyc_documents,
    load_transactions, load_fraud_watchlist, load_sanctions_watchlist,
    load_pep_watchlist, load_adverse_media, load_case_history, save_case_history,
    load_selfie_verification, save_selfie_verification, load_document_file_registry,
    save_document_file_registry, load_compliance_rules, update_case_status, get_case_details
)
from src.orchestrator import run_master_orchestrator
from src.report_generator import generate_evidence_pack_pdf

# Set page config
st.set_page_config(
    page_title="TrustShield AI - Agentic Compliance Platform",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling (Dark Navy / Slate theme)
st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Outfit', sans-serif;
    }
    
    /* Title and text alignments */
    .landing-header {
        font-size: 2.8rem;
        font-weight: 700;
        color: #0F172A;
        text-align: center;
        margin-bottom: 5px;
    }
    .landing-subtitle {
        font-size: 1.25rem;
        color: #475569;
        text-align: center;
        margin-bottom: 30px;
    }
    
    /* Metrics Card styling */
    .metric-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        padding: 15px 20px;
        border-radius: 10px;
        text-align: left;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    }
    .metric-value {
        font-size: 1.75rem;
        font-weight: 700;
        color: #1E3A8A;
        margin: 5px 0;
    }
    .metric-label {
        font-size: 0.85rem;
        font-weight: 500;
        color: #64748B;
        text-transform: uppercase;
    }
    
    /* Custom status badges */
    .badge {
        padding: 4px 8px;
        border-radius: 6px;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
    }
    .badge-approved { background-color: #DEF7EC; color: #03543F; }
    .badge-rejected { background-color: #FDE8E8; color: #9B1C1C; }
    .badge-review { background-color: #FEF08A; color: #713F12; }
    .badge-escalated { background-color: #EDD5F5; color: #6B21A8; }
    .badge-pending { background-color: #E2E8F0; color: #475569; }
    
    /* Grid details container */
    .grid-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 15px;
        margin-top: 15px;
    }
    </style>
    """, unsafe_allow_html=True)

# Initialize Session States
if "portal_view" not in st.session_state:
    st.session_state["portal_view"] = "Landing"  # Landing, Staff, Customer
if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False
if "username" not in st.session_state:
    st.session_state["username"] = ""
if "user_role" not in st.session_state:
    st.session_state["user_role"] = ""
if "customer_id" not in st.session_state:
    st.session_state["customer_id"] = ""
if "current_case_id" not in st.session_state:
    st.session_state["current_case_id"] = ""
if "orchestrator_result" not in st.session_state:
    st.session_state["orchestrator_result"] = None
if "gemini_api_key" not in st.session_state:
    st.session_state["gemini_api_key"] = ""

def logout():
    st.session_state["logged_in"] = False
    st.session_state["username"] = ""
    st.session_state["user_role"] = ""
    st.session_state["customer_id"] = ""
    st.session_state["current_case_id"] = ""
    st.session_state["orchestrator_result"] = None
    st.session_state["portal_view"] = "Landing"
    st.rerun()

# ----------------- LANDING PAGE -----------------
if st.session_state["portal_view"] == "Landing":
    st.markdown('<div class="landing-header">🛡️ TrustShield AI</div>', unsafe_allow_html=True)
    st.markdown('<div class="landing-subtitle">Agentic Compliance Intelligence for KYC, AML Risk & Audit Automation</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div style="border: 1px solid #E2E8F0; padding: 25px; border-radius: 12px; background-color: #F8FAFC; text-align: center; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05);">
            <h3 style="color: #1E3A8A; font-weight: 700;">Admin & Staff Portal</h3>
            <p style="color: #475569; font-size: 0.95rem; min-height: 70px;">
                Access the multi-agent decision engine, review onboarding queues, run risk analyses, evaluate guardrails, draft alerts, and compile ReportLab audit PDFs.
            </p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Enter Staff Portal", key="btn_staff_portal", use_container_width=True):
            st.session_state["portal_view"] = "Staff"
            st.rerun()
            
    with col2:
        st.markdown("""
        <div style="border: 1px solid #E2E8F0; padding: 25px; border-radius: 12px; background-color: #F8FAFC; text-align: center; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05);">
            <h3 style="color: #1E3A8A; font-weight: 700;">Customer Portal</h3>
            <p style="color: #475569; font-size: 0.95rem; min-height: 70px;">
                Log in securely to view onboarding status checklist, upload pending credentials, simulate documents, and check notifications (internal risks and agent details masked).
            </p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Enter Customer Portal", key="btn_customer_portal", use_container_width=True):
            st.session_state["portal_view"] = "Customer"
            st.rerun()
            
    st.markdown("<br/><br/><div style='text-align: center; font-size: 0.85rem; color: #94A3B8;'>Secure compliance platform. All activities logged under federal auditing guidelines.</div>", unsafe_allow_html=True)

# ----------------- LOGIN HANDLING -----------------
elif not st.session_state["logged_in"]:
    # Sidebar Go Back
    if st.sidebar.button("← Back to Landing"):
        st.session_state["portal_view"] = "Landing"
        st.rerun()
        
    st.markdown(f"## 🛡️ TrustShield AI - {st.session_state['portal_view']} Login")
    
    col_l, col_r = st.columns([1, 1.5])
    
    with col_l:
        username_input = st.text_input("Username").strip()
        password_input = st.text_input("Password", type="password")
        
        if st.session_state["portal_view"] == "Staff":
            if st.button("Login as Staff"):
                if username_input in STAFF_CREDENTIALS and STAFF_CREDENTIALS[username_input]["password"] == password_input:
                    st.session_state["logged_in"] = True
                    st.session_state["username"] = username_input
                    st.session_state["user_role"] = STAFF_CREDENTIALS[username_input]["role"]
                    st.session_state["customer_id"] = ""
                    st.success(f"Logged in successfully as {STAFF_CREDENTIALS[username_input]['name']}")
                    st.rerun()
                else:
                    st.error("Invalid Staff username or password.")
        else: # Customer
            if st.button("Login as Customer"):
                if username_input in CUSTOMER_CREDENTIALS and CUSTOMER_CREDENTIALS[username_input]["password"] == password_input:
                    st.session_state["logged_in"] = True
                    st.session_state["username"] = username_input
                    st.session_state["user_role"] = "Customer"
                    st.session_state["customer_id"] = CUSTOMER_CREDENTIALS[username_input]["customer_id"]
                    st.success(f"Logged in successfully as Customer {st.session_state['customer_id']}")
                    st.rerun()
                else:
                    st.error("Invalid Customer username or password.")
                    
    with col_r:
        st.info("💡 **Demo Credentials Guide**")
        if st.session_state["portal_view"] == "Staff":
            st.markdown("""
            * **Admin**: `admin` / `Trust@123`
            * **Compliance Reviewer**: `compliance` / `Trust@123`
            * **Fraud Analyst**: `fraud` / `Trust@123`
            * **Auditor**: `auditor` / `Trust@123`
            * **Operations User**: `ops` / `Trust@123`
            """)
        else:
            st.markdown("""
            * **Low Risk onboarding (CUST00001)**: `demo.low1` / `Trust@123`
            * **Medium Risk, Expired Address (CUST02500)**: `demo.medium1` / `Trust@123`
            * **Medium Risk, Low Image Conf (CUST02501)**: `demo.medium2` / `Trust@123`
            * **High Risk, PEP politician (CUST04999)**: `demo.high1` / `Trust@123`
            * **Critical Risk, Sanctions list match (CUST05000)**: `demo.critical1` / `Trust@123`
            * **Critical Risk, Duplicate PAN (CUST05001)**: `demo.critical2` / `Trust@123`
            * **Critical Risk, Selfie mismatch (CUST05002)**: `demo.critical3` / `Trust@123`
            """)

# ----------------- CUSTOMER PORTAL PAGES -----------------
elif st.session_state["portal_view"] == "Customer":
    cust_id = st.session_state["customer_id"]
    
    # Sidebar
    st.sidebar.markdown(f"#### Customer Portal")
    st.sidebar.markdown(f"**ID:** {cust_id}")
    st.sidebar.markdown(f"**User:** {st.session_state['username']}")
    
    cust_page = st.sidebar.radio("Navigation Menu", [
        "1. Customer Dashboard",
        "2. Profile Summary",
        "3. Customer Photo / Selfie View",
        "4. KYC Status",
        "5. Document Checklist",
        "6. Document Upload / Simulation",
        "7. Additional Document Request",
        "8. Customer Notifications",
        "9. Final Status"
    ])
    
    if st.sidebar.button("Logout"):
        logout()
        
    # Load customer details dynamically (filtered for safety)
    df_c = load_customers()
    row_c = df_c[df_c["customer_id"] == cust_id]
    if row_c.empty:
        st.error("Profile not found.")
        st.stop()
        
    cust = row_c.iloc[0].to_dict()
    masked_cust = mask_customer_dict(cust)
    
    # Dynamic document loading
    df_d = load_kyc_documents()
    cust_docs = df_d[df_d["customer_id"] == cust_id]
    
    # Dynamic selfie checks
    df_selfie = load_selfie_verification()
    cust_selfie = df_selfie[df_selfie["customer_id"] == cust_id]
    
    # Case status color mapping
    status_colors = {
        "Approved": "badge-approved",
        "Rejected": "badge-rejected",
        "Manual Review Required": "badge-review",
        "Escalated to Compliance": "badge-escalated",
        "Escalated to Fraud Team": "badge-escalated",
        "Document Pending": "badge-pending",
        "New": "badge-pending",
    }
    badge_class = status_colors.get(cust["case_status"], "badge-pending")

    # 1. Customer Dashboard
    if cust_page == "1. Customer Dashboard":
        st.markdown(f"## Welcome back, {masked_cust['full_name']}!")
        
        col1, col2 = st.columns([2, 1])
        with col1:
            st.markdown(f"""
            <div style="background-color: #F8FAFC; padding: 20px; border-radius: 10px; border: 1px solid #E2E8F0;">
                <h4>Verification Summary</h4>
                <p>Onboarding Case Reference: <b>{cust['case_id']}</b></p>
                <p>KYC Verification Status: <span class="badge {badge_class}">{cust['case_status']}</span></p>
                <p>Submission Channel: <b>{cust['application_channel']}</b></p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown("#### Latest Portal Alerts & Guidelines")
            if cust["case_status"] == "Document Pending":
                st.warning("⚠️ Action Required: Some of your mandatory documents are missing or have failed validation checks. Please complete the checklist.")
            elif cust["case_status"] == "Approved":
                st.success("🎉 Congratulations! Your identity check is complete. Your account is fully active and enabled for transaction services.")
            elif cust["case_status"] == "Rejected":
                st.error("❌ Onboarding Rejected: Your compliance check does not meet our minimum threshold requirements.")
            else:
                st.info("ℹ️ Your application is currently under manual audit review. We will notify you here once processing completes.")

        with col2:
            st.markdown("#### Portrait Reference")
            photo_file = DIRS["uploads"] / cust_id / "customer_photo.png"
            if photo_file.exists():
                st.image(Image.open(photo_file), use_container_width=True)
            else:
                st.warning("Photo pending upload.")

    # 2. Profile Summary
    elif cust_page == "2. Profile Summary":
        st.markdown("### Profile Summary (PII Masked)")
        st.markdown("""*Note: To protect your privacy, sensitive demographic identifiers are masked.*""")
        
        st.write(pd.DataFrame({
            "Field": ["Full Name", "Date of Birth", "Gender", "Email Address", "Mobile Number", "Address Profile", "City", "State", "Nationality", "Occupation", "Income Range"],
            "Registered Profile Value": [
                masked_cust["full_name"],
                masked_cust["dob"],
                masked_cust["gender"],
                masked_cust["email"],
                masked_cust["mobile"],
                masked_cust["address"],
                masked_cust["city"],
                masked_cust["state"],
                masked_cust["nationality"],
                masked_cust["occupation"],
                masked_cust["income_range"]
            ]
        }))

    # 3. Customer Photo / Selfie View
    elif cust_page == "3. Customer Photo / Selfie View":
        st.markdown("### Facial Portrait & Selfie verification")
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("#### Primary Account Portrait")
            photo_file = DIRS["uploads"] / cust_id / "customer_photo.png"
            if photo_file.exists():
                st.image(Image.open(photo_file), use_container_width=True)
            else:
                st.warning("No portrait file is simulated.")
        with col2:
            st.markdown("#### Onboarding Selfie Image")
            selfie_file = DIRS["uploads"] / cust_id / "selfie.png"
            if selfie_file.exists():
                st.image(Image.open(selfie_file), use_container_width=True)
            else:
                st.warning("No selfie file uploaded.")
                
        # Liveness & Match details (filtered - no internal logs shown)
        if not cust_selfie.empty:
            row_s = cust_selfie.iloc[0]
            st.markdown(f"""
            * **Liveness Validation Status:** `{row_s['liveness_check']}`
            * **Selfie Quality Grade:** `{row_s['selfie_quality']}`
            * **Identity Check Matching Result:** `{row_s['face_match_status']}`
            """)

    # 4. KYC Status
    elif cust_page == "4. KYC Status":
        st.markdown("### Verification Checklist Timeline")
        st.markdown(f"Current Phase Status: **{cust['case_status']}**")
        
        phases = [
            ("Document Pending", "Onboarding registration. Pending document files."),
            ("Document Uploaded", "Files successfully uploaded to the banking server."),
            ("Validation In Progress", "Automated system checking and OCR matching."),
            ("Manual Review Required", "Awaiting Compliance Analyst review override."),
            ("Approved", "Case closed. Account active.")
        ]
        
        for phase, desc in phases:
            is_active = cust["case_status"] == phase
            is_checked = (phase == "Document Pending") or \
                         (phase == "Document Uploaded" and cust["case_status"] not in ["New", "Document Pending"]) or \
                         (phase == "Validation In Progress" and cust["case_status"] not in ["New", "Document Pending", "Document Uploaded"]) or \
                         (phase == "Manual Review Required" and cust["case_status"] in ["Manual Review Required", "Approved", "Closed"]) or \
                         (phase == "Approved" and cust["case_status"] == "Approved")
            
            icon = "✅" if is_checked else "🔵" if is_active else "⚪"
            st.markdown(f"{icon} **{phase}**: {desc}")

    # 5. Document Checklist
    elif cust_page == "5. Document Checklist":
        st.markdown("### Mandatory Verification Documents Status")
        
        checklist = []
        mandatory = ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"]
        
        for dtype in mandatory:
            matching_docs = cust_docs[cust_docs["document_type"] == dtype]
            if matching_docs.empty:
                checklist.append({"Document": dtype, "Status": "Missing", "Confidence": "N/A", "Issues": "Pending upload"})
            else:
                row_d = matching_docs.iloc[0]
                status_val = row_d["document_status"]
                issues = "None"
                if status_val == "Expired":
                    issues = "Utility issue date older than 90 days threshold"
                elif status_val == "Low Confidence":
                    issues = "Image resolution low (blurred)"
                elif status_val == "Failed":
                    issues = "Tampering or validation checks failed"
                    
                checklist.append({
                    "Document": dtype,
                    "Status": status_val,
                    "Confidence": f"{row_d['confidence_score']*100:.0f}%" if pd.notna(row_d['confidence_score']) else "N/A",
                    "Issues": issues
                })
                
        st.table(pd.DataFrame(checklist))

    # 6. Document Upload / Simulation
    elif cust_page == "6. Document Upload / Simulation":
        st.markdown("### Document Upload Desk")
        st.markdown("Simulate document uploads to overwrite registry values and update case verification checks.")
        
        doc_type_sel = st.selectbox("Select Document Type", ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"])
        st.file_uploader("Upload Image File", type=["png", "jpg", "jpeg", "pdf"])
        
        if st.button("Simulate Upload & OCR Check"):
            # Update Document Registry to Passed
            df_docs_all = load_kyc_documents()
            
            # Find and update
            mask = (df_docs_all["customer_id"] == cust_id) & (df_docs_all["document_type"] == doc_type_sel)
            if not df_docs_all[mask].empty:
                df_docs_all.loc[mask, "document_status"] = "Passed"
                df_docs_all.loc[mask, "confidence_score"] = 0.95
                df_docs_all.loc[mask, "quality_status"] = "Passed"
                df_docs_all.loc[mask, "tampering_indicator"] = "Not Detected"
                save_kyc_documents(df_docs_all)
                
                # Log audit
                df_hist_all = load_case_history()
                new_event = {
                    "case_id": cust["case_id"],
                    "customer_id": cust_id,
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "current_status": cust["case_status"],
                    "assigned_queue": cust["assigned_queue"],
                    "sla_hours": int(cust["sla_hours"]),
                    "escalation_level": 0,
                    "last_action": f"Customer Portal: Overwrote / Simulated upload of {doc_type_sel} - status updated to Passed."
                }
                df_hist_all = pd.concat([df_hist_all, pd.DataFrame([new_event])], ignore_index=True)
                save_case_history(df_hist_all)
                
                st.success(f"Successfully simulated upload and parsed {doc_type_sel} Card OCR. Extracted demographics aligned. Status set to Passed.")
            else:
                st.error("Document record not found in system template.")

    # 7. Additional Document Request
    elif cust_page == "7. Additional Document Request":
        st.markdown("### Additional Document Desk")
        
        # Check if case status is More Documents Required
        if cust["case_status"] == "More Documents Required":
            st.error("⚠️ ALERT: Compliance managers have requested an additional address proof utility slip or bank statement.")
            st.text_area("Reviewer Requests Comments", "Please upload a recent electricity bill issued within the last 30 days to verify local residency address.", disabled=True)
        else:
            st.info("No active additional document requests are registered for this case profile.")

    # 8. Customer Notifications
    elif cust_page == "8. Customer Notifications":
        st.markdown("### Customer Communications Drawer")
        
        # Generate notice strings based on status
        if cust["case_status"] == "Approved":
            st.markdown(f"""
            **From: Compliance Board**  
            *Subject: Verification Completed (Case {cust['case_id']})*  
            Dear Customer, your identity validation checks have passed. Your retail portal is fully unlocked.
            """)
        elif cust["case_status"] == "Rejected":
            st.markdown(f"""
            **From: Compliance Board**  
            *Subject: Application Status (Case {cust['case_id']})*  
            Dear Customer, we regret that we are unable to process your onboarding application. Details have been logged.
            """)
        elif cust["case_status"] == "Document Pending":
            st.markdown(f"""
            **From: Support Center**  
            *Subject: Actions Required for Verification (Case {cust['case_id']})*  
            Please upload your remaining verification items to complete KYC.
            """)
        else:
            st.markdown(f"""
            **From: System Operations**  
            *Subject: Processing Application (Case {cust['case_id']})*  
            Your profile validation check is in progress. Review status is pending.
            """)

    # 9. Final Status
    elif cust_page == "9. Final Status":
        st.markdown("### KYC Verification Determination")
        
        if cust["case_status"] == "Approved":
            st.success("✅ APPROVED - COMPLIANT PROFILE")
            st.markdown("Your onboarding audit is successful. Welcome as a verified account holder.")
        elif cust["case_status"] == "Rejected":
            st.error("❌ REJECTED - NON-COMPLIANT")
            st.markdown("Onboarding checks failed due to identity discrepancy or watchlist flags.")
        else:
            st.info("⏳ PENDING VERIFICATION")
            st.markdown("Your case is currently under analysis by compliance auditors.")

# ----------------- STAFF PORTAL PAGES -----------------
elif st.session_state["portal_view"] == "Staff":
    role = st.session_state["user_role"]
    username = st.session_state["username"]
    
    # Sidebar
    st.sidebar.markdown(f"#### Staff Portal")
    st.sidebar.markdown(f"**User:** {username} ({role})")
    
    staff_page = st.sidebar.radio("Navigation Sidebar", [
        "1. Executive Dashboard",
        "2. Customer Registration",
        "3. Document Upload & Checklist",
        "4. Customer Photo & Document Preview",
        "5. KYC Case Queue",
        "6. Multi-Agent Review",
        "7. Risk & Guardrail Intelligence",
        "8. Human Review Workflow",
        "9. Notification & Email Center",
        "10. Audit Evidence Pack",
        "11. Case Closure"
    ])
    
    # Optional Gemini Key Input
    st.sidebar.markdown("---")
    st.sidebar.markdown("⚙️ **Gemini API Key Setup**")
    st.session_state["gemini_api_key"] = st.sidebar.text_input("Enter GOOGLE_API_KEY", value=st.session_state["gemini_api_key"], type="password")
    
    if st.sidebar.button("Logout"):
        logout()
        
    # Role-Based Permissions Enforcement
    permissions = load_compliance_rules()["role_permissions"]
    allowed_pages = {
        "Admin": ["1. Executive Dashboard", "2. Customer Registration", "3. Document Upload & Checklist", "4. Customer Photo & Document Preview", "5. KYC Case Queue", "6. Multi-Agent Review", "7. Risk & Guardrail Intelligence", "8. Human Review Workflow", "9. Notification & Email Center", "10. Audit Evidence Pack", "11. Case Closure"],
        "Operations User": ["1. Executive Dashboard", "2. Customer Registration", "3. Document Upload & Checklist", "4. Customer Photo & Document Preview"],
        "Compliance Reviewer": ["1. Executive Dashboard", "3. Document Upload & Checklist", "4. Customer Photo & Document Preview", "5. KYC Case Queue", "6. Multi-Agent Review", "7. Risk & Guardrail Intelligence", "8. Human Review Workflow", "9. Notification & Email Center", "10. Audit Evidence Pack"],
        "Fraud Analyst": ["1. Executive Dashboard", "5. KYC Case Queue", "6. Multi-Agent Review", "7. Risk & Guardrail Intelligence", "8. Human Review Workflow", "9. Notification & Email Center"],
        "Auditor": ["1. Executive Dashboard", "4. Customer Photo & Document Preview", "10. Audit Evidence Pack", "11. Case Closure"]
    }
    
    role_allowed = allowed_pages.get(role, [])
    if staff_page not in role_allowed:
        st.error(f"⛔ Access Denied: Role '{role}' does not have permission to access the '{staff_page}' module.")
        st.stop()

    # 1. Executive Dashboard
    if staff_page == "1. Executive Dashboard":
        st.markdown("## 🛡️ TrustShield AI Compliance Dashboard")
        
        df_c_all = load_customers()
        
        # Calculate dynamic metrics
        total_cases = len(df_c_all)
        approved_cases = len(df_c_all[df_c_all["case_status"] == "Approved"])
        rejected_cases = len(df_c_all[df_c_all["case_status"] == "Rejected"])
        escalated_cases = len(df_c_all[df_c_all["case_status"].str.contains("Escalated", na=False)])
        manual_review = len(df_c_all[df_c_all["case_status"] == "Manual Review Required"])
        pending_docs = len(df_c_all[df_c_all["case_status"] == "Document Pending"])
        new_cases = len(df_c_all[df_c_all["case_status"] == "New"])
        
        high_risk_cnt = len(df_c_all[df_c_all["synthetic_risk_profile"] == "High"])
        crit_risk_cnt = len(df_c_all[df_c_all["synthetic_risk_profile"] == "Critical"])
        
        # Risk profiles average
        risk_map = {"Low": 15, "Medium": 45, "High": 70, "Critical": 90}
        avg_risk = df_c_all["synthetic_risk_profile"].map(risk_map).mean()
        
        # SLA breach count (Critical + High where status is not approved or rejected)
        sla_breach = len(df_c_all[(df_c_all["synthetic_risk_profile"].isin(["High", "Critical"])) & (~df_c_all["case_status"].isin(["Approved", "Rejected", "Closed"]))])
        
        # Render Metrics Grid
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Total Onboarding Cases</div><div class="metric-value">{total_cases}</div></div>', unsafe_allow_html=True)
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown(f'<div class="metric-card"><div class="metric-label">Approved Accounts</div><div class="metric-value">{approved_cases}</div></div>', unsafe_allow_html=True)
        with col2:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Awaiting Reviews</div><div class="metric-value">{manual_review}</div></div>', unsafe_allow_html=True)
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown(f'<div class="metric-card"><div class="metric-label">Rejected Compliance</div><div class="metric-value">{rejected_cases}</div></div>', unsafe_allow_html=True)
        with col3:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Active Escalations</div><div class="metric-value">{escalated_cases}</div></div>', unsafe_allow_html=True)
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown(f'<div class="metric-card"><div class="metric-label">Average Risk Index</div><div class="metric-value">{avg_risk:.1f}%</div></div>', unsafe_allow_html=True)
        with col4:
            st.markdown(f'<div class="metric-card"><div class="metric-label">Escalated Risk (High/Crit)</div><div class="metric-value">{high_risk_cnt + crit_risk_cnt}</div></div>', unsafe_allow_html=True)
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown(f'<div class="metric-card"><div class="metric-label">SLA Warning Flags</div><div class="metric-value">{sla_breach}</div></div>', unsafe_allow_html=True)

        st.markdown("---")
        
        # Queues breakdown
        col_la, col_ra = st.columns(2)
        with col_la:
            st.markdown("#### Review Queue Status Distribution")
            df_status_chart = df_c_all["case_status"].value_counts().reset_index()
            df_status_chart.columns = ["Case Status", "Count"]
            st.bar_chart(df_status_chart.set_index("Case Status"))
            
        with col_ra:
            st.markdown("#### High-Severity Risk Alert Queue (Critical Risk / Escalated)")
            df_high_queue = df_c_all[df_c_all["synthetic_risk_profile"].isin(["High", "Critical"]) & (~df_c_all["case_status"].isin(["Approved", "Rejected", "Closed"]))].head(8)
            
            # Mask names for display
            display_high = df_high_queue.copy()
            display_high["full_name"] = display_high["full_name"].apply(lambda x: x.split()[0] + " *****")
            display_high["email"] = display_high["email"].apply(lambda x: x.split("@")[0][0] + "*****@" + x.split("@")[1] if "@" in x else "*****")
            
            st.table(display_high[["case_id", "customer_id", "full_name", "synthetic_risk_profile", "case_status", "sla_hours"]])

    # 2. Customer Registration
    elif staff_page == "2. Customer Registration":
        st.markdown("### Operations Room: Customer Onboarding Registration")
        
        col1, col2 = st.columns(2)
        with col1:
            full_name = st.text_input("Full Name (First and Last)")
            dob = st.date_input("Date of Birth", min_value=datetime(1930, 1, 1), max_value=datetime.today())
            gender = st.selectbox("Gender", ["Male", "Female", "Other"])
            email = st.text_input("Email Address")
            mobile = st.text_input("Mobile Number")
            address = st.text_area("Full Residential Address")
        with col2:
            city = st.text_input("City")
            state = st.text_input("State")
            country = st.text_input("Country", value="India")
            nationality = st.text_input("Nationality", value="Indian")
            occupation = st.selectbox("Occupation", ["Software Engineer", "Consultant", "Doctor", "Teacher", "Retired", "Student", "Other"])
            income_range = st.selectbox("Income Range", ["< 5 LPA", "5 - 10 LPA", "10 - 25 LPA", "25 - 50 LPA", "50 LPA+"])
            channel = st.selectbox("Application Channel", ["Branch", "Mobile App", "Web Portal", "Relationship Manager"])
            
        if st.button("Initialize KYC Case File"):
            if not full_name or not email or not mobile:
                st.error("Please complete Name, Email, and Mobile fields.")
            else:
                df_c_all = load_customers()
                new_idx = len(df_c_all) + 1
                cust_id = f"CUST{new_idx:05d}"
                case_id = f"CASE{new_idx:05d}"
                username = f"demo.new{new_idx}"
                
                # Append customer profile
                new_cust = {
                    "case_id": case_id,
                    "customer_id": cust_id,
                    "login_username": username,
                    "full_name": full_name,
                    "dob": dob.strftime("%Y-%m-%d"),
                    "gender": gender,
                    "email": email,
                    "mobile": mobile,
                    "address": address,
                    "city": city,
                    "state": state,
                    "country": country,
                    "nationality": nationality,
                    "occupation": occupation,
                    "income_range": income_range,
                    "application_channel": channel,
                    "application_date": datetime.today().strftime("%Y-%m-%d"),
                    "case_status": "Document Pending",
                    "assigned_queue": "Compliance Queue",
                    "sla_hours": 72,
                    "synthetic_risk_profile": "Medium",
                    "profile_image_path": f"uploads/demo_customer_docs/{cust_id}/customer_photo.png"
                }
                
                df_c_all = pd.concat([df_c_all, pd.DataFrame([new_cust])], ignore_index=True)
                save_customers(df_c_all)
                
                # Append selfie verification stub
                df_selfie = load_selfie_verification()
                new_selfie = {
                    "case_id": case_id,
                    "customer_id": cust_id,
                    "selfie_available": 0,
                    "selfie_file_path": f"uploads/demo_customer_docs/{cust_id}/selfie.png",
                    "selfie_quality": "Pending",
                    "selfie_match_score": 0.0,
                    "liveness_check": "Pending",
                    "face_match_status": "Pending"
                }
                df_selfie = pd.concat([df_selfie, pd.DataFrame([new_selfie])], ignore_index=True)
                save_selfie_verification(df_selfie)
                
                # Append documents stub (missing)
                df_docs_all = load_kyc_documents()
                doc_types = ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"]
                new_docs = []
                for dt in doc_types:
                    new_docs.append({
                        "case_id": case_id,
                        "customer_id": cust_id,
                        "document_type": dt,
                        "document_name": f"{dt} Card" if dt in ["PAN", "Aadhaar"] else dt,
                        "id_number": "Pending",
                        "document_name_value": "Pending",
                        "document_dob_value": "Pending",
                        "document_address_value": "Pending",
                        "document_age_days": 0,
                        "confidence_score": 0.0,
                        "file_type": "PNG",
                        "quality_status": "Pending",
                        "document_status": "Missing",
                        "tampering_indicator": "Pending",
                        "issue_date": "Pending",
                        "expiry_date": "Pending"
                    })
                df_docs_all = pd.concat([df_docs_all, pd.DataFrame(new_docs)], ignore_index=True)
                save_kyc_documents(df_docs_all)
                
                # Append history log
                df_hist_all = load_case_history()
                new_hist = {
                    "case_id": case_id,
                    "customer_id": cust_id,
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "current_status": "Document Pending",
                    "assigned_queue": "Compliance Queue",
                    "sla_hours": 72,
                    "escalation_level": 0,
                    "last_action": f"Operations User ({username}) initialized onboarding case file."
                }
                df_hist_all = pd.concat([df_hist_all, pd.DataFrame([new_hist])], ignore_index=True)
                save_case_history(df_hist_all)
                
                st.success(f"🎉 Successfully created case {case_id} for customer {cust_id}! Credentials: {username} / Trust@123. Initial status set to Document Pending.")

    # 3. Document Upload & Checklist
    elif staff_page == "3. Document Upload & Checklist":
        st.markdown("### Document checklist Management & Simulation")
        
        df_c_all = load_customers()
        case_options = df_c_all["case_id"].tolist()
        selected_case = st.selectbox("Select KYC Case Reference", case_options)
        
        st.session_state["current_case_id"] = selected_case
        
        # Load details
        details = get_case_details(selected_case)
        cust = details["customer"]
        docs = details["documents"]
        
        st.markdown(f"**Customer ID:** `{cust['customer_id']}` | **Risk profile:** `{cust['synthetic_risk_profile']}`")
        
        # Table of documents
        checklist_df = pd.DataFrame(docs)
        st.table(checklist_df[["document_type", "document_status", "confidence_score", "quality_status", "tampering_indicator"]])
        
        st.markdown("#### Simulate Document Upload")
        doc_to_upload = st.selectbox("Choose document type to simulate upload", ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"])
        if st.button("Complete / Reset Document Upload status to Passed"):
            df_docs_all = load_kyc_documents()
            mask = (df_docs_all["case_id"] == selected_case) & (df_docs_all["document_type"] == doc_to_upload)
            if not df_docs_all[mask].empty:
                df_docs_all.loc[mask, "document_status"] = "Passed"
                df_docs_all.loc[mask, "confidence_score"] = 0.96
                df_docs_all.loc[mask, "quality_status"] = "Passed"
                df_docs_all.loc[mask, "tampering_indicator"] = "Not Detected"
                save_kyc_documents(df_docs_all)
                st.success(f"Overwrote {doc_to_upload} status. OCR checklist is now Passed.")
                st.rerun()

    # 4. Customer Photo & Document Preview
    elif staff_page == "4. Customer Photo & Document Preview":
        st.markdown("### Customer Photo & Document Preview Room")
        
        df_c_all = load_customers()
        case_options = df_c_all["case_id"].tolist()
        selected_case = st.selectbox("Select Onboarding Case Profile", case_options)
        st.session_state["current_case_id"] = selected_case
        
        details = get_case_details(selected_case)
        cust_id = details["customer"]["customer_id"]
        
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("#### Onboarding Portrait")
            photo_file = DIRS["uploads"] / cust_id / "customer_photo.png"
            if photo_file.exists():
                st.image(Image.open(photo_file), use_container_width=True)
            else:
                st.warning("Portrait not created for this profile.")
        with col2:
            st.markdown("#### Captured Selfie")
            selfie_file = DIRS["uploads"] / cust_id / "selfie.png"
            if selfie_file.exists():
                st.image(Image.open(selfie_file), use_container_width=True)
            else:
                st.warning("Selfie not uploaded.")
                
        st.markdown("---")
        st.markdown("#### Extracted ID & Financial Statement Previews")
        doc_type_sel = st.selectbox("Select Uploaded Credential Document", ["PAN", "Aadhaar", "Bank Statement", "Salary Slip", "Address Proof"])
        
        doc_file = DIRS["uploads"] / cust_id / f"{doc_type_sel.lower().replace(' ', '_')}.png"
        if doc_file.exists():
            st.image(Image.open(doc_file), use_container_width=True)
        else:
            st.info(f"The {doc_type_sel} simulation file does not exist on disk for this customer.")

    # 5. KYC Case Queue
    elif staff_page == "5. KYC Case Queue":
        st.markdown("### Onboarding Queue Review Office")
        
        queue_sel = st.selectbox("Select Audit Queue", ["Auto Approval Queue", "Compliance Queue", "Fraud Queue"])
        
        df_c_all = load_customers()
        filtered_df = df_c_all[df_c_all["assigned_queue"] == queue_sel]
        
        # Mask Names for Safety
        display_df = filtered_df.copy()
        display_df["full_name"] = display_df["full_name"].apply(lambda x: x.split()[0] + " *****")
        display_df["email"] = display_df["email"].apply(lambda x: x.split("@")[0][0] + "*****@" + x.split("@")[1] if "@" in x else "*****")
        
        st.write(f"Total Cases in {queue_sel}: **{len(filtered_df)}**")
        st.table(display_df[["case_id", "customer_id", "full_name", "dob", "synthetic_risk_profile", "case_status", "sla_hours"]])
        
        st.markdown("---")
        st.markdown("#### Choose Case for AI Compliance audit")
        case_options = filtered_df["case_id"].tolist()
        if case_options:
            selected_case = st.selectbox("Select Case to Audit", case_options)
            if st.button("Set Selected Case as Active Case"):
                st.session_state["current_case_id"] = selected_case
                st.success(f"Case {selected_case} set as active case. Navigate to Multi-Agent Review page.")
        else:
            st.info("No active cases in this queue.")

    # 6. Multi-Agent Review
    elif staff_page == "6. Multi-Agent Review":
        st.markdown("### Multi-Agent Onboarding Analysis Desk")
        
        df_c_all = load_customers()
        active_case = st.selectbox("Active Case", df_c_all["case_id"].tolist(), index=df_c_all["case_id"].tolist().index(st.session_state["current_case_id"]) if st.session_state["current_case_id"] in df_c_all["case_id"].tolist() else 0)
        st.session_state["current_case_id"] = active_case
        
        details = get_case_details(active_case)
        cust_id = details["customer"]["customer_id"]
        st.markdown(f"**Customer ID:** `{cust_id}` | **Risk profile:** `{details['customer']['synthetic_risk_profile']}`")
        
        # Trigger button
        if st.button("Run Master Orchestrator Agent Pipeline"):
            with st.spinner("Invoking specialist compliance agents and validating security policy rules..."):
                res = run_master_orchestrator(active_case, st.session_state["gemini_api_key"])
                st.session_state["orchestrator_result"] = res
                st.success("Orchestration pipeline execution successful!")
                
        # Display results if present
        res = st.session_state["orchestrator_result"]
        if res and res["case_id"] == active_case:
            st.markdown("### Specialist Agent Findings Log")
            findings_data = []
            for f in res["agent_findings"]:
                findings_data.append({
                    "Agent Name": f["agent_name"],
                    "Status": f["status"],
                    "Finding Summary": f["finding"],
                    "Evidence Path": f["evidence"]
                })
            st.table(pd.DataFrame(findings_data))
            
            st.markdown("---")
            st.markdown("### Agent Action trace Details")
            st.json(res["agent_findings"])
        else:
            st.info("Please trigger the Orchestrator pipeline above to see findings.")

    # 7. Risk & Guardrail Intelligence
    elif staff_page == "7. Risk & Guardrail Intelligence":
        st.markdown("### Risk Engine & Compliance Guardrail Intelligence")
        
        active_case = st.session_state["current_case_id"]
        if not active_case:
            st.warning("Please select a case first in the queues or reviews.")
            st.stop()
            
        res = st.session_state["orchestrator_result"]
        if not res or res["case_id"] != active_case:
            st.info("Trigger the orchestrator in the Multi-Agent Review page first.")
            st.stop()
            
        risk = res["risk_result"]
        guardrail = res["guardrail_result"]
        
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("#### Quantitative Risk Scorecard")
            
            # Draw a visual risk indicator
            score = risk["risk_score"]
            risk_color = "red" if score > 80 else "orange" if score > 60 else "yellow" if score > 30 else "green"
            st.markdown(f"""
            <div style="background-color: #F8FAFC; border: 2px solid #E2E8F0; padding: 25px; border-radius: 12px; text-align: center;">
                <div style="font-size: 0.9rem; text-transform: uppercase; color: #64748B; font-weight: 600;">Automated Score</div>
                <div style="font-size: 3.5rem; font-weight: 700; color: {risk_color};">{score} / 100</div>
                <div style="font-size: 1.25rem; font-weight: 700; color: #0F172A; margin-top: 5px;">Risk Band: {risk['risk_level']}</div>
                <div style="font-size: 0.95rem; font-weight: 500; color: #475569; margin-top: 5px;">Decision: {risk['recommended_decision']}</div>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown("**Key Case Risk Drivers:**")
            for dr in risk["risk_drivers"]:
                st.markdown(f"- {dr}")
                
        with col2:
            st.markdown("#### Security Compliance Guardrail overrides")
            status = guardrail["status"]
            status_color = "#F87171" if status == "Blocked" else "#34D399"
            
            st.markdown(f"""
            <div style="background-color: #F8FAFC; border: 2px solid #E2E8F0; padding: 25px; border-radius: 12px;">
                <div style="font-size: 0.9rem; text-transform: uppercase; color: #64748B; font-weight: 600;">Guardrail Status</div>
                <div style="font-size: 2.2rem; font-weight: 700; color: {status_color}; margin-top: 5px;">{status}</div>
                <hr style="margin: 12px 0; border: 0; border-top: 1px solid #E2E8F0;"/>
                <div style="font-size: 0.95rem; color: #1E293B;"><b>Policy Reference:</b><br/>{guardrail['policy_reference']}</div>
                <div style="font-size: 0.95rem; color: #1E293B; margin-top: 10px;"><b>Required Analyst Action:</b><br/>{guardrail['required_human_action']}</div>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown("**Blocked triggers:**")
            for rb in guardrail["blocked_reasons"]:
                st.markdown(f"- 🔴 {rb}")

    # 8. Human Review Workflow
    elif staff_page == "8. Human Review Workflow":
        st.markdown("### Human Review and Override Decision Form")
        
        active_case = st.session_state["current_case_id"]
        if not active_case:
            st.warning("Please select a case first.")
            st.stop()
            
        res = st.session_state["orchestrator_result"]
        if not res or res["case_id"] != active_case:
            st.info("Trigger the orchestrator in the Multi-Agent Review page first.")
            st.stop()
            
        st.markdown(f"**Case Reference:** `{active_case}` | **Risk score:** `{res['risk_result']['risk_score']}` | **Guardrail:** `{res['guardrail_result']['status']}`")
        
        # Override warning panel
        if res["risk_result"]["risk_level"] in ["Critical", "High"] or res["guardrail_result"]["status"] == "Blocked":
            st.warning("⚠️ CRITICAL OVERRIDE NOTICE: The system has flagged this customer profile with safety blocks or elevated risk. Setting approval requires an override explanation comment.")
            
        # Form
        reviewer_action = st.selectbox("Select Decision Determination Action", [
            "Approve Onboarding", "Reject Onboarding", "Escalate to Compliance", "Escalate to Fraud Team", "Request More Documents"
        ])
        
        reviewer_comment = st.text_area("Reviewer Audit Comments (Mandatory)")
        override_reason = st.text_area("Override Policy Rationale (Mandatory if action differs from risk recommendation or guardrail status)")
        
        # Display Gemini reasoning snippet as helper
        st.info("💡 **Compliance Summary Recommendation Helper (Gemini / Fallback):**")
        st.text(res["gemini_reasoning"])
        
        if st.button("Finalize Decision Determination"):
            # Enforce reviewer comment
            if not reviewer_comment.strip():
                st.error("Please provide reviewer audit comments.")
                st.stop()
                
            # If guardrail status is Blocked or risk score is high, override explanation must be filled if trying to Approve
            if (res["guardrail_result"]["status"] == "Blocked" or res["risk_result"]["risk_level"] in ["Critical", "High"]) and reviewer_action == "Approve Onboarding":
                if not override_reason.strip():
                    st.error("Strict Policy Block: An override reason must be provided to approve this case.")
                    st.stop()
                    
            # Map status
            status_map = {
                "Approve Onboarding": "Approved",
                "Reject Onboarding": "Rejected",
                "Escalate to Compliance": "Escalated to Compliance",
                "Escalate to Fraud Team": "Escalated to Fraud Team",
                "Request More Documents": "More Documents Required"
            }
            new_status = status_map[reviewer_action]
            
            # Save final action to session state orchestrator result
            action_desc = f"{reviewer_action} by {username} ({role})"
            comments_field = f"Comment: {reviewer_comment}"
            if override_reason.strip():
                comments_field += f" | Override Reason: {override_reason}"
                
            update_case_status(active_case, new_status, action_desc, comments_field)
            
            # Update orchestrator cached action
            res["agent_findings"][-3]["status"] = "Passed" if "Approve" in reviewer_action else "Failed"
            res["agent_findings"][-3]["finding"] = f"Review Action: {reviewer_action}"
            res["agent_findings"][-3]["evidence"] = comments_field
            
            # Recompile ReportLab PDF evidence
            generate_evidence_pack_pdf(res)
            
            st.success(f"Finalized. Case status changed to {new_status}. ReportLab PDF compiled.")

    # 9. Notification & Email Center
    elif staff_page == "9. Notification & Email Center":
        st.markdown("### Communication Drawer & Notification Center")
        
        active_case = st.session_state["current_case_id"]
        if not active_case:
            st.warning("Please select a case.")
            st.stop()
            
        res = st.session_state["orchestrator_result"]
        if not res or res["case_id"] != active_case:
            st.info("Trigger the orchestrator in the Multi-Agent Review page first.")
            st.stop()
            
        drafts = res["notification_drafts"]
        
        st.markdown("#### Generated Notice Templates")
        draft_type = st.selectbox("Select draft channel", [
            "document_request", "kyc_approved", "kyc_rejected", "compliance_escalation", "fraud_escalation", "senior_approval", "case_closure", "evidence_pack_share"
        ])
        
        draft = drafts.get(draft_type, {"subject": "", "body": ""})
        
        st.text_input("Draft Email Subject Line", value=draft["subject"], disabled=True)
        st.text_area("Email Body Draft Editor", value=draft["body"], height=300)
        
        st.markdown("---")
        # Save as text download button
        txt_body = f"Subject: {draft['subject']}\n\n{draft['body']}"
        st.download_button("Download Email Draft as .txt File", data=txt_body, file_name=f"{active_case}_{draft_type}.txt", mime="text/plain")

    # 10. Audit Evidence Pack
    elif staff_page == "10. Audit Evidence Pack":
        st.markdown("### Compliance Audit & Evidence Pack generation")
        st.markdown("Compile, download, and review the ReportLab generated KYC PDF evidence packet.")
        
        active_case = st.session_state["current_case_id"]
        if not active_case:
            st.warning("Please select a case.")
            st.stop()
            
        res = st.session_state["orchestrator_result"]
        if not res or res["case_id"] != active_case:
            st.info("Trigger the orchestrator in the Multi-Agent Review page first.")
            st.stop()
            
        # Compile PDF button
        pdf_path = DIRS["evidence_packs"] / f"{active_case}_evidence_pack.pdf"
        
        if st.button("Generate Evidence PDF Pack"):
            with st.spinner("Generating ReportLab evidence document..."):
                pdf_path_str = generate_evidence_pack_pdf(res)
                st.success(f"ReportLab PDF compiled at path: {pdf_path_str}")
                
        if os.path.exists(pdf_path):
            with open(pdf_path, "rb") as f:
                st.download_button(
                    "Download PDF Onboarding Proof Pack",
                    data=f.read(),
                    file_name=f"{active_case}_audit_evidence.pdf",
                    mime="application/pdf"
                )
            st.info("ℹ️ Note: Demographic records and details in the document preview tables are masked in accordance with compliance security guardrails.")
        else:
            st.info("No PDF compiled yet. Click the button above to generate.")

    # 11. Case Closure
    elif staff_page == "11. Case Closure":
        st.markdown("### Archiving & Case Closure Audit Logs")
        
        # Select closed case
        df_c_all = load_customers()
        closed_cases = df_c_all[df_c_all["case_status"].isin(["Approved", "Rejected", "Closed"])]
        
        st.write(f"Total Cases Archived: **{len(closed_cases)}**")
        
        # Display audit logs
        st.markdown("#### System Activity Logs")
        audit_trail_path = DIRS["audit_logs"] / "audit_trail.json"
        if audit_trail_path.exists():
            try:
                with open(audit_trail_path, "r") as f:
                    audit_logs = json.load(f)
                st.write(pd.DataFrame(audit_logs))
            except Exception:
                st.info("Audit log JSON format is empty.")
        else:
            st.info("No audit logs recorded yet.")
            
        st.markdown("---")
        st.markdown("#### Closed Cases listing")
        st.table(closed_cases[["case_id", "customer_id", "full_name", "case_status", "assigned_queue"]])
