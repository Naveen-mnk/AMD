# TrustShield AI – Agentic Compliance Intelligence for KYC, AML Risk & Audit Automation

**TrustShield AI** is an enterprise-style compliance automation platform designed for customer onboarding, multi-agent KYC/AML analysis, rules-based risk assessment, safety guardrails, human review audit cycles, and automated ReportLab PDF evidence compilation.

Designed for the AMD + TCS Hackathon, this codebase represents a fully functioning technical implementation running inside the AMD Notebook environment.

---

## 🛠️ Main Features

1. **Dual Portals**: 
   * **Admin & Staff Portal**: Role-based access control supporting 5 roles (Admin, Compliance Reviewer, Fraud Analyst, Auditor, Operations User) to review queues, run multi-agent audits, override decisions, edit alerts, and compile PDFs.
   * **Customer Portal**: Onboarding dashboard featuring profile views, upload simulations, checklist reviews, and notification feeds, with all internal risks and developer logs strictly masked.
2. **17 Specialists Agents**: Formulated using Pydantic validation structures covering Document intelligence, Identity matching, Compliance rules RAG, PEP/Sanctions checks, financial profiling, transaction risk, guardrails, notification drafting, and governance.
3. **Resilient AI Reasoning**: Seamlessly integrates with Google Gemini API for natural language compliance summaries, with an automated fallback to a deterministic local rule-based compiler if the API key is not supplied or fails.
4. **Immutable Auditing**: Every event (uploads, OCR, agent outputs, risk scoring shifts, reviewer overrides, report compiles) is logged into an immutable database format (`case_history.csv` and `outputs/audit_logs/audit_trail.json`).
5. **PII Masking**: Masking functions sanitize sensitive data (PAN, Aadhaar, mobile numbers, bank accounts, emails) across UI rendering, log outputs, and PDF layers.

---

## 📁 Project Folder Structure

```
trustshield-ai/
├── app.py
├── requirements.txt
├── .gitignore
├── README.md
├── notebooks/
│   └── TrustShield_AI_Runbook.ipynb
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── constants.py
│   ├── data_generator.py
│   ├── data_loader.py
│   ├── pii_masking.py
│   ├── document_checks.py
│   ├── risk_engine.py
│   ├── guardrails.py
│   ├── gemini_reasoning.py
│   ├── agents.py
│   ├── orchestrator.py
│   ├── notification_generator.py
│   └── report_generator.py
├── data/
│   ├── customers.csv
│   ├── kyc_documents.csv
│   ├── transactions.csv
│   ├── fraud_watchlist.csv
│   ├── sanctions_watchlist.csv
│   ├── pep_watchlist.csv
│   ├── adverse_media.csv
│   ├── case_history.csv
│   ├── selfie_verification.csv
│   ├── document_file_registry.csv
│   ├── compliance_rules.json
│   └── kyc_policy_knowledge.txt
├── uploads/
│   └── demo_customer_docs/
├── outputs/
│   ├── agent_traces/
│   ├── decision_logs/
│   ├── notifications/
│   └── audit_logs/
├── reports/
│   ├── audit_reports/
│   └── evidence_packs/
└── assets/
    ├── images/
    └── styles/
```

---

## 🚀 Running on AMD Notebook Environment

Run the following commands inside your terminal to launch the Streamlit server:

```bash
cd /workspace/trustshield-ai
pip install -q -r requirements.txt
streamlit run app.py --server.port 8501 --server.headless true --server.enableCORS false --server.enableXsrfProtection false
```

### Accessing the Web Application:
To access the app outside the environment, use the proxy routing:
```
https://notebooks.amd.com/<pod-name>/proxy/8501/
```
*(Do not connect via localhost)*

---

## 🔐 System Credentials

### 👥 Staff Demo Profiles (Username / Password)
* **Admin**: `admin` / `Trust@123`
* **Compliance Reviewer**: `compliance` / `Trust@123`
* **Fraud Analyst**: `fraud` / `Trust@123`
* **Auditor**: `auditor` / `Trust@123`
* **Operations User**: `ops` / `Trust@123`

### 👤 Customer Onboarding Profiles (Username / Password)
* **Low Risk onboarding (CUST00001)**: `demo.low1` / `Trust@123`
* **Low Risk onboarding (CUST00002)**: `demo.low2` / `Trust@123`
* **Medium Risk, Expired Address (CUST02500)**: `demo.medium1` / `Trust@123`
* **Medium Risk, Low Image Conf (CUST02501)**: `demo.medium2` / `Trust@123`
* **Medium Risk, Partial Name Match (CUST02502)**: `demo.medium3` / `Trust@123`
* **High Risk, PEP Politician (CUST04999)**: `demo.high1` / `Trust@123`
* **High Risk, Country connection (CUST04998)**: `demo.high2` / `Trust@123`
* **Critical Risk, Sanctions match (CUST05000)**: `demo.critical1` / `Trust@123`
* **Critical Risk, Duplicate PAN (CUST05001)**: `demo.critical2` / `Trust@123`
* **Critical Risk, Selfie mismatch (CUST05002)**: `demo.critical3` / `Trust@123`

---

## 💡 How to Set GOOGLE_API_KEY & Run Without Gemini

1. **Option A (Environment Variable)**: Export the key inside the shell before launching the app:
   ```bash
   export GOOGLE_API_KEY="your-gemini-api-key"
   ```
2. **Option B (UI Input)**: You can paste the key directly in the staff portal's sidebar configuration drawer inside the Streamlit UI.
3. **No Gemini (Fallback Mode)**: If no key is set or the API fails, the orchestrator triggers a deterministic rule-based compliance report. No crash or disruption will occur during evaluations.

---

## 🎬 Verification & Onboarding Demo Flow

1. Open the TrustShield AI web URL.
2. Select **Customer Portal** and log in as `demo.low1`. Review the profile status details and checklist.
3. Log out and log in as **Staff** under the `compliance` or `ops` user role.
4. Open **Customer Registration** and create a new customer file.
5. Upload or simulate uploading documents, updating the checklist statuses.
6. Open **KYC Case Queue** and select critical-risk customer `CUST05000` (demo.critical1).
7. Navigate to **Multi-Agent Review** and trigger the agent pipeline.
8. Go to **Risk & Guardrail Intelligence** to review how the UN Sanctions match triggers a guardrail block overriding standard processing.
9. In **Human Review Workflow**, enter comments and submit a decision override determination.
10. Open **Notification Center** to check drafted notices, download a `.txt` email draft, then download the compiled ReportLab PDF evidence packet from the **Audit Evidence Pack** page.
